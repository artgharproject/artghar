-- ====================================================================
-- ART GHAR PRODUCTION DATABASE SCHEMA (POSTGRESQL & SUPABASE RLS)
-- "WHERE EVERY FRAME TELLS A TALE"
-- ====================================================================

-- 1. EXTENSIONS & ENUMS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Role enum
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('admin', 'editor');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Release type enum
DO $$ BEGIN
    CREATE TYPE release_type AS ENUM ('Single', 'EP', 'Album', 'Soundtrack', 'Original', 'Collaboration');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Status enums
DO $$ BEGIN
    CREATE TYPE upcoming_status AS ENUM ('Announced', 'Coming Soon', 'In Production', 'Post Production', 'Scheduled');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE message_status AS ENUM ('New', 'Read', 'In Progress', 'Resolved');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 2. TABLES

-- PROFILES (Admin / Editors)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    auth_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    avatar_url TEXT,
    role user_role NOT NULL DEFAULT 'editor',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ARTISTS
CREATE TABLE IF NOT EXISTS public.artists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    short_bio TEXT NOT NULL,
    biography TEXT NOT NULL,
    profile_image TEXT NOT NULL,
    cover_image TEXT NOT NULL,
    genre TEXT NOT NULL,
    location TEXT NOT NULL DEFAULT 'Kathmandu, Nepal',
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    sort_order INT NOT NULL DEFAULT 0,
    instagram_url TEXT,
    youtube_url TEXT,
    facebook_url TEXT,
    tiktok_url TEXT,
    spotify_url TEXT,
    website_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- RELEASES
CREATE TABLE IF NOT EXISTS public.releases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    artist_id UUID NOT NULL REFERENCES public.artists(id) ON DELETE CASCADE,
    release_type release_type NOT NULL DEFAULT 'Single',
    cover_image TEXT NOT NULL,
    description TEXT NOT NULL,
    release_date DATE NOT NULL,
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    spotify_url TEXT,
    apple_music_url TEXT,
    youtube_url TEXT,
    soundcloud_url TEXT,
    other_links JSONB DEFAULT '{}'::jsonb,
    credits TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- UPCOMING PROJECTS
CREATE TABLE IF NOT EXISTS public.upcoming_projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    artist_id UUID NOT NULL REFERENCES public.artists(id) ON DELETE CASCADE,
    project_type TEXT NOT NULL,
    artwork TEXT NOT NULL,
    description TEXT NOT NULL,
    announcement TEXT NOT NULL,
    expected_release_date TEXT NOT NULL,
    status upcoming_status NOT NULL DEFAULT 'Coming Soon',
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    trailer_url TEXT,
    pre_save_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- PRODUCTIONS
CREATE TABLE IF NOT EXISTS public.productions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL DEFAULT 'Music',
    cover_image TEXT NOT NULL,
    hero_image TEXT NOT NULL,
    description TEXT NOT NULL,
    content TEXT NOT NULL,
    client_name TEXT,
    production_date DATE NOT NULL,
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- VIDEOS
CREATE TABLE IF NOT EXISTS public.videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    thumbnail TEXT NOT NULL,
    video_url TEXT,
    youtube_url TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Music Video',
    description TEXT NOT NULL,
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    release_date DATE NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- GALLERY
CREATE TABLE IF NOT EXISTS public.gallery (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    image_url TEXT NOT NULL,
    caption TEXT,
    category TEXT NOT NULL DEFAULT 'Studio',
    featured BOOLEAN NOT NULL DEFAULT false,
    published BOOLEAN NOT NULL DEFAULT true,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- BLOG POSTS (JOURNAL)
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    excerpt TEXT NOT NULL,
    content TEXT NOT NULL,
    cover_image TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Story',
    author_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    published BOOLEAN NOT NULL DEFAULT true,
    featured BOOLEAN NOT NULL DEFAULT false,
    published_at TIMESTAMPTZ,
    seo_title TEXT,
    seo_description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- TIMELINE
CREATE TABLE IF NOT EXISTS public.timeline (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    year TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    image TEXT,
    sort_order INT NOT NULL DEFAULT 0,
    published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- CONTACT MESSAGES
CREATE TABLE IF NOT EXISTS public.contact_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    organization TEXT,
    project_type TEXT NOT NULL,
    message TEXT NOT NULL,
    status message_status NOT NULL DEFAULT 'New',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- SITE SETTINGS
CREATE TABLE IF NOT EXISTS public.site_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key TEXT UNIQUE NOT NULL,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. ROW LEVEL SECURITY (RLS) POLICIES

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.releases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.upcoming_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.productions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Helper function to check admin / editor status
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE auth_user_id = auth.uid() AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_staff()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE auth_user_id = auth.uid() AND role IN ('admin', 'editor')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- PUBLIC READ POLICIES (Only published items)
CREATE POLICY "Public can view published artists" ON public.artists FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published releases" ON public.releases FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published upcoming" ON public.upcoming_projects FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published productions" ON public.productions FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published videos" ON public.videos FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published gallery" ON public.gallery FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published posts" ON public.blog_posts FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view published timeline" ON public.timeline FOR SELECT USING (published = true OR public.is_staff());
CREATE POLICY "Public can view site settings" ON public.site_settings FOR SELECT USING (true);

-- CONTACT MESSAGES: Public can insert, only staff can read/update
CREATE POLICY "Anyone can submit contact message" ON public.contact_messages FOR INSERT WITH CHECK (true);
CREATE POLICY "Only staff can view contact messages" ON public.contact_messages FOR SELECT USING (public.is_staff());
CREATE POLICY "Only staff can update contact messages" ON public.contact_messages FOR UPDATE USING (public.is_staff());

-- STAFF (ADMIN / EDITOR) MANAGEMENT POLICIES
CREATE POLICY "Staff can manage artists" ON public.artists FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage releases" ON public.releases FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage upcoming" ON public.upcoming_projects FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage productions" ON public.productions FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage videos" ON public.videos FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage gallery" ON public.gallery FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage blog posts" ON public.blog_posts FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage timeline" ON public.timeline FOR ALL USING (public.is_staff());
CREATE POLICY "Staff can manage site settings" ON public.site_settings FOR ALL USING (public.is_staff());

-- ADMIN ONLY: profiles management
CREATE POLICY "Staff can view profiles" ON public.profiles FOR SELECT USING (public.is_staff());
CREATE POLICY "Admins can manage profiles" ON public.profiles FOR ALL USING (public.is_admin());

-- 4. STORAGE BUCKETS SETUP
INSERT INTO storage.buckets (id, name, public) VALUES 
('artist-images', 'artist-images', true),
('release-artwork', 'release-artwork', true),
('upcoming-artwork', 'upcoming-artwork', true),
('production-media', 'production-media', true),
('video-thumbnails', 'video-thumbnails', true),
('gallery', 'gallery', true),
('blog-images', 'blog-images', true),
('site-assets', 'site-assets', true)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS: Public read, Staff upload/delete
CREATE POLICY "Public read bucket items" ON storage.objects FOR SELECT USING (bucket_id IN ('artist-images', 'release-artwork', 'upcoming-artwork', 'production-media', 'video-thumbnails', 'gallery', 'blog-images', 'site-assets'));
CREATE POLICY "Staff upload bucket items" ON storage.objects FOR INSERT WITH CHECK (public.is_staff());
CREATE POLICY "Staff update bucket items" ON storage.objects FOR UPDATE USING (public.is_staff());
CREATE POLICY "Staff delete bucket items" ON storage.objects FOR DELETE USING (public.is_staff());
