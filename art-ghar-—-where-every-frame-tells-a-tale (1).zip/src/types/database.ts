export type UserRole = 'admin' | 'editor';

export type ArtistCollaborationStatus = 'current' | 'worked' | 'upcoming';

export interface Profile {
  id: string;
  auth_user_id: string;
  full_name: string;
  email: string;
  avatar_url?: string;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Artist {
  id: string;
  name: string;
  slug: string;
  short_bio: string;
  biography: string;
  profile_image: string;
  cover_image: string;
  genre: string;
  location: string;
  collaboration_status: ArtistCollaborationStatus;
  featured: boolean;
  published: boolean;
  sort_order: number;
  instagram_url?: string;
  youtube_url?: string;
  facebook_url?: string;
  tiktok_url?: string;
  spotify_url?: string;
  website_url?: string;
  created_at: string;
  updated_at: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  image: string;
  address: string;
  email: string;
  phone?: string;
  instagram_url?: string;
  linkedin_url?: string;
  sort_order: number;
  published: boolean;
  created_at: string;
  updated_at: string;
}

export type ReleaseType = 'Single' | 'EP' | 'Album' | 'Soundtrack' | 'Original' | 'Collaboration';

export interface Release {
  id: string;
  title: string;
  slug: string;
  artist_id: string;
  artist?: Artist;
  release_type: ReleaseType;
  cover_image: string;
  description: string;
  release_date: string;
  featured: boolean;
  published: boolean;
  spotify_url?: string;
  apple_music_url?: string;
  youtube_url?: string;
  soundcloud_url?: string;
  other_links?: Record<string, string>;
  credits?: string;
  created_at: string;
  updated_at: string;
}

export type UpcomingStatus = 'Announced' | 'Coming Soon' | 'In Production' | 'Post Production' | 'Scheduled';

export interface UpcomingProject {
  id: string;
  title: string;
  slug: string;
  artist_id: string;
  artist?: Artist;
  project_type: string;
  artwork: string;
  description: string;
  announcement: string;
  expected_release_date: string;
  status: UpcomingStatus;
  featured: boolean;
  published: boolean;
  trailer_url?: string;
  pre_save_url?: string;
  created_at: string;
  updated_at: string;
}

export type ProductionCategory = 'Music' | 'Film' | 'Commercial' | 'Visual' | 'Documentary' | 'Original' | 'Other';

export interface Production {
  id: string;
  title: string;
  slug: string;
  category: ProductionCategory;
  cover_image: string;
  hero_image: string;
  description: string;
  content: string;
  client_name?: string;
  production_date: string;
  featured: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
}

export interface Video {
  id: string;
  title: string;
  slug: string;
  thumbnail: string;
  video_url?: string;
  youtube_url: string;
  category: string;
  description: string;
  featured: boolean;
  published: boolean;
  release_date: string;
  created_at: string;
  updated_at: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  image_url: string;
  caption: string;
  category: string;
  featured: boolean;
  published: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  cover_image: string;
  category: string;
  author_id: string;
  author?: Profile;
  published: boolean;
  featured: boolean;
  published_at?: string;
  seo_title?: string;
  seo_description?: string;
  created_at: string;
  updated_at: string;
}

export interface TimelineItem {
  id: string;
  year: string;
  title: string;
  description: string;
  image?: string;
  sort_order: number;
  published: boolean;
  created_at: string;
  updated_at: string;
}

export type MessageStatus = 'New' | 'Read' | 'In Progress' | 'Resolved';

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  organization?: string;
  project_type: string;
  message: string;
  status: MessageStatus;
  created_at: string;
}

export type CollaborationCategory =
  | 'Program & Festival'
  | 'Company & Studio'
  | 'Cultural Institution'
  | 'Broadcast & Media'
  | 'Brand Partnership'
  | 'Community & NGO';

export interface Collaboration {
  id: string;
  partner_name: string;
  program_name: string;
  category: CollaborationCategory;
  logo: string;
  banner_image?: string;
  year: string;
  description: string;
  outcomes?: string;
  website_url?: string;
  featured: boolean;
  published: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export type TheaterShowStatus = 'Staged' | 'Archived' | 'Currently Running' | 'Touring' | 'Upcoming';

export interface TheaterShow {
  id: string;
  title: string;
  slug: string;
  playwright?: string;
  director: string;
  venue: string;
  city: string;
  dates_staged: string;
  year: string;
  status: TheaterShowStatus;
  poster_image: string;
  stage_photos?: string[];
  synopsis: string;
  cast_and_crew?: string;
  press_quote?: string;
  press_outlet?: string;
  duration?: string;
  ticket_link?: string;
  featured: boolean;
  published: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface SiteSettings {
  id: string;
  key: string;
  value: any;
  updated_at: string;
}

export interface DatabaseState {
  profiles: Profile[];
  artists: Artist[];
  team_members: TeamMember[];
  releases: Release[];
  upcoming_projects: UpcomingProject[];
  productions: Production[];
  videos: Video[];
  collaborations: Collaboration[];
  theater_shows: TheaterShow[];
  gallery: GalleryItem[];
  blog_posts: BlogPost[];
  timeline: TimelineItem[];
  contact_messages: ContactMessage[];
  site_settings: Record<string, any>;
}
