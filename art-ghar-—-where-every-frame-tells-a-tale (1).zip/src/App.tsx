/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { RouterProvider, useRouter, matchRoute } from './lib/router';
import { store } from './lib/store';

// Public Components & Pages
import { PublicHeader } from './components/public/PublicHeader';
import { PublicFooter } from './components/public/PublicFooter';
import { HomePage } from './pages/public/HomePage';
import { ArtistsPage } from './pages/public/ArtistsPage';
import { ArtistDetailPage } from './pages/public/ArtistDetailPage';
import { ReleasesPage } from './pages/public/ReleasesPage';
import { ReleaseDetailPage } from './pages/public/ReleaseDetailPage';
import { UpcomingPage } from './pages/public/UpcomingPage';
import { UpcomingDetailPage } from './pages/public/UpcomingDetailPage';
import { ProductionsPage } from './pages/public/ProductionsPage';
import { ProductionDetailPage } from './pages/public/ProductionDetailPage';
import { VideosPage } from './pages/public/VideosPage';
import { TeamPage } from './pages/public/TeamPage';
import { GalleryPage } from './pages/public/GalleryPage';
import { JournalPage } from './pages/public/JournalPage';
import { JournalDetailPage } from './pages/public/JournalDetailPage';
import { AboutPage } from './pages/public/AboutPage';
import { ContactPage } from './pages/public/ContactPage';

// Admin Pages
import { AdminLoginPage } from './pages/admin/AdminLoginPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminArtistsPage } from './pages/admin/AdminArtistsPage';
import { AdminTeamPage } from './pages/admin/AdminTeamPage';
import { AdminReleasesPage } from './pages/admin/AdminReleasesPage';
import { AdminUpcomingPage } from './pages/admin/AdminUpcomingPage';
import { AdminProductionsPage } from './pages/admin/AdminProductionsPage';
import { AdminVideosPage } from './pages/admin/AdminVideosPage';
import { AdminGalleryPage } from './pages/admin/AdminGalleryPage';
import { AdminJournalPage } from './pages/admin/AdminJournalPage';
import { AdminTimelinePage } from './pages/admin/AdminTimelinePage';
import { AdminMessagesPage } from './pages/admin/AdminMessagesPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';
import { AdminUsersPage } from './pages/admin/AdminUsersPage';

function AppContent() {
  const { path, navigate } = useRouter();
  const [, setTick] = useState(0);

  // Subscribe to database changes to trigger real-time updates across the app
  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsubscribe;
  }, []);

  const currentUser = store.getCurrentUser();

  // 1. ADMIN ROUTING
  if (path.startsWith('/admin')) {
    // Only typing /admin/login explicitly opens the login portal
    if (path === '/admin/login') {
      if (currentUser) {
        return <AdminDashboardPage />;
      }
      return <AdminLoginPage />;
    }

    // Direct /admin or /admin/* without authenticated session is completely blocked
    // Unauthenticated visitors receive a standard 404 Frame Not Found
    if (!currentUser) {
      return (
        <div className="min-h-screen flex flex-col bg-[#0A0A0A] text-[#F4F1EA]">
          <PublicHeader />
          <main className="flex-1">
            <div className="pt-40 pb-32 text-center min-h-[70vh] flex flex-col items-center justify-center space-y-4 px-4">
              <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
                Error 404
              </span>
              <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA]">
                Frame Not Found
              </h1>
              <p className="text-sm text-[#8E8B82] max-w-md font-light">
                The story or file you are seeking may have been archived or moved inside the house.
              </p>
              <button
                onClick={() => navigate('/')}
                className="px-6 py-2.5 bg-[#E5A93C] text-black text-xs font-bold uppercase tracking-wider rounded mt-4"
              >
                Return to Art Ghar
              </button>
            </div>
          </main>
          <PublicFooter />
        </div>
      );
    }

    if (path === '/admin' || path === '/admin/') {
      return <AdminDashboardPage />;
    }
    if (path === '/admin/artists') {
      return <AdminArtistsPage />;
    }
    if (path === '/admin/team') {
      return <AdminTeamPage />;
    }
    if (path === '/admin/releases') {
      return <AdminReleasesPage />;
    }
    if (path === '/admin/upcoming') {
      return <AdminUpcomingPage />;
    }
    if (path === '/admin/productions') {
      return <AdminProductionsPage />;
    }
    if (path === '/admin/videos') {
      return <AdminVideosPage />;
    }
    if (path === '/admin/gallery') {
      return <AdminGalleryPage />;
    }
    if (path === '/admin/journal') {
      return <AdminJournalPage />;
    }
    if (path === '/admin/timeline') {
      return <AdminTimelinePage />;
    }
    if (path === '/admin/messages') {
      return <AdminMessagesPage />;
    }
    if (path === '/admin/settings') {
      return <AdminSettingsPage />;
    }
    if (path === '/admin/admin-users') {
      return <AdminUsersPage />;
    }

    // Fallback within admin
    return <AdminDashboardPage />;
  }

  // 2. PUBLIC ROUTING WITH HEADER & FOOTER
  let pageComponent: React.ReactNode = null;

  if (path === '/' || path === '') {
    pageComponent = <HomePage />;
  } else if (path === '/artists') {
    pageComponent = <ArtistsPage />;
  } else if (path.startsWith('/artists/')) {
    const match = matchRoute('/artists/:slug', path);
    pageComponent = <ArtistDetailPage slug={match.params.slug || ''} />;
  } else if (path === '/releases') {
    pageComponent = <ReleasesPage />;
  } else if (path.startsWith('/releases/')) {
    const match = matchRoute('/releases/:slug', path);
    pageComponent = <ReleaseDetailPage slug={match.params.slug || ''} />;
  } else if (path === '/upcoming') {
    pageComponent = <UpcomingPage />;
  } else if (path.startsWith('/upcoming/')) {
    const match = matchRoute('/upcoming/:slug', path);
    pageComponent = <UpcomingDetailPage slug={match.params.slug || ''} />;
  } else if (path === '/productions') {
    pageComponent = <ProductionsPage />;
  } else if (path.startsWith('/productions/')) {
    const match = matchRoute('/productions/:slug', path);
    pageComponent = <ProductionDetailPage slug={match.params.slug || ''} />;
  } else if (path === '/videos') {
    pageComponent = <VideosPage />;
  } else if (path === '/team') {
    pageComponent = <TeamPage />;
  } else if (path === '/gallery') {
    pageComponent = <GalleryPage />;
  } else if (path === '/journal') {
    pageComponent = <JournalPage />;
  } else if (path.startsWith('/journal/')) {
    const match = matchRoute('/journal/:slug', path);
    pageComponent = <JournalDetailPage slug={match.params.slug || ''} />;
  } else if (path === '/about') {
    pageComponent = <AboutPage />;
  } else if (path === '/contact') {
    pageComponent = <ContactPage />;
  } else {
    // 404 Fallback
    pageComponent = (
      <div className="pt-40 pb-32 text-center min-h-[70vh] flex flex-col items-center justify-center space-y-4">
        <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
          Error 404
        </span>
        <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA]">
          Frame Not Found
        </h1>
        <p className="text-sm text-[#8E8B82] max-w-md font-light">
          The story or file you are seeking may have been archived or moved inside the house.
        </p>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-2.5 bg-[#E5A93C] text-black text-xs font-bold uppercase tracking-wider rounded mt-4"
        >
          Return to Art Ghar
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#0A0A0A] text-[#F4F1EA]">
      <PublicHeader />
      <main className="flex-1">{pageComponent}</main>
      <PublicFooter />
    </div>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}
