import React from 'react';
import { useRouter } from '../../lib/router';
import { Production } from '../../types/database';
import { ArrowRight, ArrowUpRight } from 'lucide-react';

interface SelectedWorkSectionProps {
  productions: Production[];
}

export const SelectedWorkSection: React.FC<SelectedWorkSectionProps> = ({ productions }) => {
  const { navigate } = useRouter();

  return (
    <section className="py-24 sm:py-32 bg-[#0A0A0A] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              05 · Cinema & Narrative
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              SELECTED WORK
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Motion picture, visual art, and documentary productions from Art Ghar.
            </p>
          </div>

          <button
            onClick={() => navigate('/productions')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>Explore All Work</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Visual Composition Layout (Different aspect ratios) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {productions.slice(0, 3).map((prod, index) => {
            const isWide = index === 0;
            return (
              <div
                key={prod.id}
                onClick={() => navigate(`/productions/${prod.slug}`)}
                className={`group cursor-pointer bg-[#121212] border border-white/5 rounded-lg overflow-hidden flex flex-col justify-between hover:border-[#E5A93C]/40 transition-all duration-300 ${
                  isWide ? 'md:col-span-12 lg:col-span-7' : 'md:col-span-6 lg:col-span-5'
                }`}
              >
                <div
                  className={`relative overflow-hidden bg-black/60 ${
                    isWide ? 'aspect-[16/9]' : 'aspect-[4/3]'
                  }`}
                >
                  <img
                    src={prod.cover_image}
                    alt={prod.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80" />

                  {/* Category Pill */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider bg-black/70 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                      {prod.category}
                    </span>
                  </div>

                  <div className="absolute bottom-4 right-4 w-9 h-9 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#71717A] font-mono">
                    <span>{prod.client_name || 'Art Ghar Production'}</span>
                    <span>{prod.production_date}</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                    {prod.title}
                  </h3>

                  <p className="text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-2">
                    {prod.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
