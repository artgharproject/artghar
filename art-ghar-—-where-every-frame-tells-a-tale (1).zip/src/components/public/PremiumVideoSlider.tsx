import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from '../../lib/router';
import { Video } from '../../types/database';
import { extractYoutubeId, getYoutubeEmbedUrl, getYoutubeThumbnail } from '../../lib/youtube';
import {
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Volume2,
  Maximize2,
  X,
  Youtube,
  Film,
  Sparkles,
} from 'lucide-react';

interface PremiumVideoSliderProps {
  videos: Video[];
}

export const PremiumVideoSlider: React.FC<PremiumVideoSliderProps> = ({ videos }) => {
  const { navigate } = useRouter();
  
  // Default to first video or sample real videos if list is empty
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlayingInPlace, setIsPlayingInPlace] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAutoPlayTimerActive, setIsAutoPlayTimerActive] = useState(true);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const activeVideos = videos.length > 0 ? videos : [];
  const activeVideo = activeVideos[currentIndex] || null;

  // Handle Autoplay Slider progress
  useEffect(() => {
    if (!isAutoPlayTimerActive || isPlayingInPlace || isModalOpen || activeVideos.length <= 1) {
      setProgress(0);
      return;
    }

    const interval = 80; // ms
    const duration = 7000; // 7 seconds per slide
    const increment = (interval / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentIndex((idx) => (idx + 1) % activeVideos.length);
          return 0;
        }
        return prev + increment;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [currentIndex, isAutoPlayTimerActive, isPlayingInPlace, isModalOpen, activeVideos.length]);

  const handleNext = () => {
    setIsPlayingInPlace(false);
    setProgress(0);
    setCurrentIndex((prev) => (prev + 1) % activeVideos.length);
  };

  const handlePrev = () => {
    setIsPlayingInPlace(false);
    setProgress(0);
    setCurrentIndex((prev) => (prev - 1 + activeVideos.length) % activeVideos.length);
  };

  const handleSelectSlide = (idx: number) => {
    if (idx === currentIndex) return;
    setIsPlayingInPlace(false);
    setProgress(0);
    setCurrentIndex(idx);
  };

  if (!activeVideo) {
    return null;
  }

  const youtubeId = extractYoutubeId(activeVideo.youtube_url);
  const thumbnail = activeVideo.thumbnail || getYoutubeThumbnail(activeVideo.youtube_url);

  return (
    <section id="released-videos-slider" className="py-24 sm:py-32 bg-[#090909] relative border-t border-white/5 overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full max-w-5xl h-96 bg-[#E5A93C]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#E5A93C] animate-ping" />
              <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
                03 · Released Visuals & Cinema
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              RELEASED STORIES
            </h2>
            <p className="text-sm sm:text-base text-[#8E8B82] font-light max-w-xl">
              Official cinematic visual releases, live courtyard sessions, and narrative motion pictures directed and produced inside Art Ghar.
            </p>
          </div>

          {/* Controls: Prev / Next / Counter / All Videos */}
          <div className="flex items-center gap-4 self-start md:self-end">
            {/* Slide Index Counter */}
            <div className="text-xs font-mono text-[#A3A099] tracking-widest px-3 py-1.5 rounded-full bg-white/5 border border-white/10">
              <span className="text-[#E5A93C] font-bold">
                {String(currentIndex + 1).padStart(2, '0')}
              </span>
              <span className="mx-1 text-white/30">/</span>
              <span>{String(activeVideos.length).padStart(2, '0')}</span>
            </div>

            {/* Prev / Next Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                aria-label="Previous Video"
                className="w-10 h-10 rounded-full border border-white/10 hover:border-[#E5A93C] bg-[#121212] hover:bg-[#1A1A1A] text-[#F4F1EA] hover:text-[#E5A93C] flex items-center justify-center transition-all duration-200 active:scale-90"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                aria-label="Next Video"
                className="w-10 h-10 rounded-full border border-white/10 hover:border-[#E5A93C] bg-[#121212] hover:bg-[#1A1A1A] text-[#F4F1EA] hover:text-[#E5A93C] flex items-center justify-center transition-all duration-200 active:scale-90"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            <button
              onClick={() => navigate('/videos')}
              className="hidden sm:inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors ml-2"
            >
              <span>Video Vault</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Premium Progress Bar (Slide Bar) */}
        <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden mb-8 relative">
          <div
            className="h-full bg-gradient-to-r from-[#E5A93C] to-[#F3C065] transition-all duration-100 ease-linear rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Main Cinema Stage */}
        <div className="relative w-full aspect-[16/9] lg:aspect-[21/9] rounded-2xl overflow-hidden bg-black border border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.8)] group">
          {isPlayingInPlace ? (
            <div className="w-full h-full relative bg-black">
              <iframe
                src={getYoutubeEmbedUrl(activeVideo.youtube_url, true)}
                title={activeVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
              <button
                onClick={() => setIsPlayingInPlace(false)}
                className="absolute top-4 right-4 z-20 px-3 py-1.5 rounded-full bg-black/80 hover:bg-black text-white text-xs font-mono border border-white/20 flex items-center gap-1.5 backdrop-blur-md transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                <span>Exit Player</span>
              </button>
            </div>
          ) : (
            <div className="relative w-full h-full">
              {/* High-res Thumbnail & Film Grain */}
              <img
                src={thumbnail}
                alt={activeVideo.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/30" />
              <div className="absolute inset-0 film-grain opacity-40 pointer-events-none" />

              {/* Top Meta Tag & Fullscreen Trigger */}
              <div className="absolute top-6 left-6 right-6 flex items-center justify-between z-10">
                <div className="flex items-center gap-2.5">
                  <span className="px-3 py-1 bg-black/70 backdrop-blur-md border border-[#E5A93C]/40 text-[#E5A93C] text-[11px] font-mono uppercase tracking-widest rounded-full font-semibold">
                    {activeVideo.category || 'Official Release'}
                  </span>
                  <span className="hidden sm:inline-block text-xs font-mono text-[#A3A099] bg-black/50 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10">
                    {activeVideo.release_date}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsModalOpen(true)}
                    aria-label="Theater Mode"
                    className="p-2.5 rounded-full bg-black/60 hover:bg-black/90 backdrop-blur-md text-white/80 hover:text-white border border-white/10 transition-colors"
                    title="Open in Theater Mode"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Big Center Golden Play Button */}
              <div className="absolute inset-0 flex items-center justify-center z-10">
                <button
                  onClick={() => setIsPlayingInPlace(true)}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center shadow-[0_0_50px_rgba(229,169,60,0.6)] hover:scale-110 active:scale-95 transition-all duration-300 group-hover:bg-[#F3C065]"
                  aria-label={`Play ${activeVideo.title}`}
                >
                  <Play className="w-8 h-8 sm:w-9 sm:h-9 fill-current ml-1" />
                </button>
              </div>

              {/* Bottom Video Info Card */}
              <div className="absolute bottom-6 left-6 right-6 sm:bottom-8 sm:left-8 sm:right-8 z-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div className="space-y-2 max-w-2xl">
                  <span className="text-[11px] font-mono uppercase tracking-[0.25em] text-[#E5A93C] block">
                    Now Playing Preview
                  </span>
                  <h3 className="text-xl sm:text-3xl lg:text-4xl font-display font-extrabold text-[#F4F1EA] leading-tight">
                    {activeVideo.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#C8C5BC] font-light line-clamp-2 leading-relaxed">
                    {activeVideo.description || 'Directed, captured, and mastered inside Art Ghar Studios, Kathmandu, Nepal.'}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <a
                    href={activeVideo.youtube_url}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded bg-black/60 hover:bg-black/90 backdrop-blur-md text-xs font-mono uppercase tracking-wider text-[#F4F1EA] hover:text-[#E5A93C] border border-white/10 flex items-center gap-2 transition-colors"
                  >
                    <Youtube className="w-4 h-4 text-red-500" />
                    <span>Watch on YouTube</span>
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Premium Thumbnail Slide Bar / Ribbon */}
        <div className="mt-8 pt-6 border-t border-white/5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#A3A099]">
              Featured Cinema Ribbon ({activeVideos.length} Titles)
            </span>
            <div className="flex items-center gap-2 text-[11px] font-mono text-[#71717A]">
              <span>Click to switch cinema frame</span>
            </div>
          </div>

          {/* Interactive Slide Ribbon */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {activeVideos.map((video, idx) => {
              const isCurrent = idx === currentIndex;
              const itemThumb = video.thumbnail || getYoutubeThumbnail(video.youtube_url);
              return (
                <button
                  key={video.id}
                  onClick={() => handleSelectSlide(idx)}
                  className={`text-left p-3 rounded-xl border transition-all duration-300 flex items-center gap-3.5 group relative overflow-hidden ${
                    isCurrent
                      ? 'bg-[#181818] border-[#E5A93C] shadow-[0_0_20px_rgba(229,169,60,0.15)] ring-1 ring-[#E5A93C]/50'
                      : 'bg-[#111111] border-white/5 hover:border-white/20 hover:bg-[#161616]'
                  }`}
                >
                  {/* Miniature Thumbnail */}
                  <div className="relative w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-black border border-white/10">
                    <img
                      src={itemThumb}
                      alt={video.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {isCurrent && (
                      <div className="absolute inset-0 bg-[#E5A93C]/20 flex items-center justify-center">
                        <Play className="w-4 h-4 fill-[#E5A93C] text-[#E5A93C]" />
                      </div>
                    )}
                  </div>

                  {/* Title & Metadata */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-[#E5A93C]">
                        {video.category || 'Release'}
                      </span>
                      <span className="text-[10px] font-mono text-[#71717A]">·</span>
                      <span className="text-[10px] font-mono text-[#71717A] truncate">
                        {video.release_date}
                      </span>
                    </div>
                    <h4 className={`text-xs font-display font-bold truncate transition-colors ${
                      isCurrent ? 'text-white' : 'text-[#C8C5BC] group-hover:text-white'
                    }`}>
                      {video.title}
                    </h4>
                  </div>

                  {/* Active Indicator Accent */}
                  {isCurrent && (
                    <div className="absolute right-0 top-0 bottom-0 w-1 bg-[#E5A93C]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Theater Mode Fullscreen Modal */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-8 animate-in fade-in"
        >
          <div className="relative w-full max-w-5xl aspect-[16/9] bg-black rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 z-30 p-2.5 rounded-full bg-black/70 hover:bg-black text-white/80 hover:text-white border border-white/10 backdrop-blur-md transition-colors"
              aria-label="Close Theater Mode"
            >
              <X className="w-5 h-5" />
            </button>
            <iframe
              src={getYoutubeEmbedUrl(activeVideo.youtube_url, true)}
              title={activeVideo.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          </div>
        </div>
      )}
    </section>
  );
};
