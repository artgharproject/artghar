import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { GalleryItem } from '../../types/database';
import { MediaLightbox } from '../common/MediaLightbox';
import { ArrowRight, Maximize2 } from 'lucide-react';

interface ArtGharWallSectionProps {
  items: GalleryItem[];
}

export const ArtGharWallSection: React.FC<ArtGharWallSectionProps> = ({ items }) => {
  const { navigate } = useRouter();
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);

  const handleOpenLightbox = (index: number) => {
    setActivePhotoIndex(index);
    setLightboxOpen(true);
  };

  return (
    <section className="py-24 sm:py-32 bg-[#0A0A0A] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              07 · Visual Archive
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              THE ART GHAR WALL
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Behind the scenes, acoustic chambers, mountain sets, and creative moments.
            </p>
          </div>

          <button
            onClick={() => navigate('/gallery')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>Complete Wall Gallery</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Asymmetric Masonry / Bento Visual Wall */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-5">
          {items.slice(0, 5).map((item, index) => {
            // Asymmetric sizing
            const colSpan =
              index === 0
                ? 'lg:col-span-8'
                : index === 1
                ? 'lg:col-span-4'
                : index === 2
                ? 'lg:col-span-4'
                : index === 3
                ? 'lg:col-span-4'
                : 'lg:col-span-4';

            const heightClass = index === 0 ? 'aspect-[16/10]' : 'aspect-square';

            return (
              <div
                key={item.id}
                onClick={() => handleOpenLightbox(index)}
                className={`group relative overflow-hidden rounded-lg bg-[#141414] border border-white/5 cursor-pointer ${colSpan} ${heightClass} hover:border-[#E5A93C]/50 transition-all duration-300`}
              >
                <img
                  src={item.image_url}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6">
                  <div className="flex justify-end">
                    <span className="p-2 rounded-full bg-black/60 text-white/90 backdrop-blur-md">
                      <Maximize2 className="w-4 h-4" />
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[11px] font-mono text-[#E5A93C] uppercase tracking-wider block">
                      {item.category}
                    </span>
                    <h4 className="text-base font-display font-bold text-white">
                      {item.title}
                    </h4>
                    {item.caption && (
                      <p className="text-xs text-[#C8C5BC] font-light line-clamp-1">
                        {item.caption}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lightbox for visual immersion */}
      <MediaLightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        items={items}
        currentIndex={activePhotoIndex}
        onNavigate={(newIdx) => setActivePhotoIndex(newIdx)}
      />
    </section>
  );
};
