import React from 'react';
import { useRouter } from '../../lib/router';
import { ArrowRight } from 'lucide-react';

export const AboutStorySection: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <section className="py-24 sm:py-36 bg-[#0A0A0A] relative border-t border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual Composition with Art Ghar Atmosphere */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/5] rounded-xl overflow-hidden bg-[#141414] border border-white/10 shadow-2xl">
              <img
                src="/src/assets/images/art_ghar_studio_session_1790823237699.jpg"
                alt="Inside Art Ghar Creative House"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />

              {/* Bottom Quote Badge */}
              <div className="absolute bottom-6 left-6 right-6 p-6 bg-[#0A0A0A]/90 backdrop-blur-md rounded border border-white/10">
                <p className="text-sm font-display italic text-[#F4F1EA]">
                  "The house is the sanctuary; what we create inside is what goes out into the world."
                </p>
                <span className="text-[11px] font-mono uppercase tracking-widest text-[#E5A93C] mt-2 block">
                  Art Ghar House Principle
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Narrative */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block">
              09 · The Manifesto
            </span>

            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight leading-[1.1]">
              A HOUSE FOR<br />
              <span className="text-[#E5A93C]">ART + STORIES.</span>
            </h2>

            <p className="text-base sm:text-lg text-[#C8C5BC] font-light leading-relaxed">
              In Nepali, <span className="text-white font-medium">Ghar</span> means home. Art Ghar was founded on the belief that genuine cinematic and musical storytelling cannot be manufactured in sterile corporate factories.
            </p>

            <p className="text-sm sm:text-base text-[#8E8B82] font-light leading-relaxed">
              It requires a physical place of warmth—where composers, cinematographers, folk instrumentalists, and writers sit around the same table, share tea, test microphones, study light on brick walls, and let ideas incubate with human dignity.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => navigate('/about')}
                className="px-6 py-3.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-all duration-200 self-start inline-flex items-center gap-2 active:scale-95"
              >
                <span>Read Full Chronicle & Timeline</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
