import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    project_type: 'Music Production',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const projectTypes = [
    'Music Production',
    'Video Production',
    'Artist Collaboration',
    'Film',
    'Brand Collaboration',
    'Original Project',
    'Other',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setErrorMessage('Please provide your name, valid email, and project brief.');
      return;
    }

    setErrorMessage('');
    setIsSubmitting(true);

    try {
      store.submitContactMessage({
        name: formData.name,
        email: formData.email,
        organization: formData.organization,
        project_type: formData.project_type,
        message: formData.message,
      });

      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        organization: '',
        project_type: 'Music Production',
        message: '',
      });
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage('Unable to dispatch message at this moment. Please email directly.');
    }
  };

  return (
    <section id="contact" className="py-24 sm:py-36 bg-[#0E0E0E] relative border-t border-white/5">
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        <div className="text-center space-y-4 mb-14">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            10 · Dialogue
          </span>
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight leading-[1.08]">
            LET'S CREATE<br />
            <span className="text-[#E5A93C]">SOMETHING.</span>
          </h2>
          <p className="text-sm sm:text-base text-[#8E8B82] max-w-xl mx-auto font-light">
            Share your film, soundtrack, artist or visual vision. Every great frame begins with a single conversation.
          </p>
        </div>

        {submitted ? (
          <div className="bg-[#121212] border border-[#E5A93C]/40 rounded-xl p-8 sm:p-12 text-center space-y-4 animate-in fade-in duration-300">
            <CheckCircle2 className="w-12 h-12 text-[#E5A93C] mx-auto" />
            <h3 className="text-2xl font-display font-bold text-[#F4F1EA]">
              Message Received by Art Ghar
            </h3>
            <p className="text-sm text-[#A3A099] max-w-md mx-auto font-light leading-relaxed">
              Thank you for reaching out to the house. Our producers will review your project brief and respond to your email shortly.
            </p>
            <button
              onClick={() => setSubmitted(false)}
              className="mt-4 px-6 py-2 text-xs font-mono uppercase tracking-wider text-[#E5A93C] border border-[#E5A93C]/30 rounded hover:bg-[#E5A93C]/10 transition-colors"
            >
              Send Another Inquiry
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-[#121212] border border-white/5 rounded-xl p-6 sm:p-10 space-y-6"
          >
            {errorMessage && (
              <div className="p-3 bg-red-900/30 border border-red-500/40 rounded text-red-200 text-xs font-mono">
                {errorMessage}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Suman Shakya"
                  className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@domain.com"
                  className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C] transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                  Organization / Studio (Optional)
                </label>
                <input
                  type="text"
                  value={formData.organization}
                  onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                  placeholder="e.g. Himalayan Cinema Arts"
                  className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C] transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                  Project Classification *
                </label>
                <select
                  value={formData.project_type}
                  onChange={(e) => setFormData({ ...formData, project_type: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] focus:outline-none focus:border-[#E5A93C] transition-colors"
                >
                  {projectTypes.map((pt) => (
                    <option key={pt} value={pt} className="bg-[#181818] text-white">
                      {pt}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                Project Narrative & Timeline *
              </label>
              <textarea
                required
                rows={4}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Describe your vision, musical/visual needs, target delivery, and expectations..."
                className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C] transition-colors resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-8 py-3.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-all duration-200 inline-flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isSubmitting ? (
                  <span>Transmitting...</span>
                ) : (
                  <>
                    <span>Submit Inquiry to Art Ghar</span>
                    <Send className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};
