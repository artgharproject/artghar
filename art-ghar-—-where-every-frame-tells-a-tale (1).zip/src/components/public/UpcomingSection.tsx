import React from 'react';
import { useRouter } from '../../lib/router';
import { UpcomingProject } from '../../types/database';
import { ArrowRight, Play, Calendar, Bell } from 'lucide-react';

interface UpcomingSectionProps {
  projects: UpcomingProject[];
  onOpenTrailer?: (url: string, title: string) => void;
}

export const UpcomingSection: React.FC<UpcomingSectionProps> = ({ projects, onOpenTrailer }) => {
  const { navigate } = useRouter();

  return (
    <section className="py-24 sm:py-32 bg-[#0E0E0E] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] mb-2">
              <span>02 · Forthcoming Works</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              UPCOMING
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              What's coming next from the house of Art Ghar.
            </p>
          </div>

          <button
            onClick={() => navigate('/upcoming')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>View All Upcoming</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Content Presentation */}
        {projects.length === 0 ? (
          <div className="border border-white/5 rounded-lg p-16 text-center max-w-xl mx-auto space-y-4">
            <Calendar className="w-8 h-8 text-[#E5A93C] mx-auto opacity-60" />
            <h3 className="text-lg font-display text-[#F4F1EA]">New Odysseys in Incubation</h3>
            <p className="text-sm text-[#8E8B82] font-light">
              Our producers and artists are currently secluded in studio sessions and high-altitude locations. Announcements will be unveiled shortly.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Primary Highlight Project */}
            {projects[0] && (
              <div className="lg:col-span-7 group flex flex-col justify-between bg-[#121212] border border-white/5 rounded-lg overflow-hidden transition-all duration-300 hover:border-[#E5A93C]/40">
                <div className="relative aspect-[16/10] overflow-hidden bg-black">
                  <img
                    src={projects[0].artwork}
                    alt={projects[0].title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-black/30" />

                  {/* Status Indicator */}
                  <div className="absolute top-4 left-4">
                    <span className="inline-block px-3 py-1 text-[11px] font-mono uppercase tracking-wider bg-black/70 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                      {projects[0].status}
                    </span>
                  </div>

                  {projects[0].trailer_url && onOpenTrailer && (
                    <button
                      onClick={() => onOpenTrailer(projects[0].trailer_url!, projects[0].title)}
                      className="absolute bottom-4 right-4 p-3 rounded-full bg-[#E5A93C] text-[#0A0A0A] hover:bg-[#F3C065] transition-all duration-200 shadow-lg active:scale-95 group/btn"
                      title="Play Preview Trailer"
                    >
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </button>
                  )}
                </div>

                <div className="p-6 sm:p-8 space-y-4">
                  <div className="flex items-center gap-3 text-xs text-[#A3A099]">
                    <span className="text-[#E5A93C] font-mono uppercase tracking-wider">{projects[0].project_type}</span>
                    <span aria-hidden="true">·</span>
                    <span>Expected {projects[0].expected_release_date}</span>
                  </div>

                  <h3
                    onClick={() => navigate(`/upcoming/${projects[0].slug}`)}
                    className="text-2xl sm:text-3xl font-display font-bold text-[#F4F1EA] hover:text-[#E5A93C] transition-colors cursor-pointer"
                  >
                    {projects[0].title}
                  </h3>

                  {projects[0].artist && (
                    <p className="text-sm text-[#C8C5BC] font-medium">
                      By{' '}
                      <button
                        onClick={() => navigate(`/artists/${projects[0].artist?.slug}`)}
                        className="text-[#F4F1EA] hover:text-[#E5A93C] underline-offset-4 hover:underline"
                      >
                        {projects[0].artist.name}
                      </button>
                    </p>
                  )}

                  <p className="text-sm text-[#8E8B82] leading-relaxed font-light line-clamp-3">
                    {projects[0].description}
                  </p>

                  <div className="pt-2 flex items-center gap-4">
                    <button
                      onClick={() => navigate(`/upcoming/${projects[0].slug}`)}
                      className="text-xs font-mono uppercase tracking-widest text-[#E5A93C] hover:text-[#F3C065] flex items-center gap-1.5"
                    >
                      <span>Explore Project File</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {projects[0].pre_save_url && (
                      <a
                        href={projects[0].pre_save_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider px-3 py-1.5 border border-white/10 rounded hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                      >
                        <Bell className="w-3 h-3" />
                        <span>Pre-Save</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Secondary Upcoming Projects List */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              {projects.slice(1, 3).map((item) => (
                <div
                  key={item.id}
                  className="group bg-[#121212] border border-white/5 rounded-lg p-5 flex flex-col sm:flex-row gap-5 hover:border-[#E5A93C]/40 transition-colors"
                >
                  <div className="sm:w-36 aspect-square sm:aspect-auto shrink-0 rounded overflow-hidden relative bg-black">
                    <img
                      src={item.artwork}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-2 left-2">
                      <span className="px-2 py-0.5 text-[9px] font-mono uppercase tracking-wider bg-black/80 text-[#E5A93C] rounded">
                        {item.status}
                      </span>
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col justify-between space-y-2">
                    <div className="space-y-1">
                      <span className="text-[11px] font-mono text-[#E5A93C] uppercase tracking-wider block">
                        {item.project_type}
                      </span>
                      <h4
                        onClick={() => navigate(`/upcoming/${item.slug}`)}
                        className="text-lg font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors cursor-pointer"
                      >
                        {item.title}
                      </h4>
                      {item.artist && (
                        <p className="text-xs text-[#A3A099]">With {item.artist.name}</p>
                      )}
                    </div>

                    <div className="pt-2 flex items-center justify-between text-xs text-[#71717A] border-t border-white/5">
                      <span>{item.expected_release_date}</span>
                      <button
                        onClick={() => navigate(`/upcoming/${item.slug}`)}
                        className="text-[#E5A93C] hover:underline uppercase font-mono text-[11px] tracking-wider"
                      >
                        Details →
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
