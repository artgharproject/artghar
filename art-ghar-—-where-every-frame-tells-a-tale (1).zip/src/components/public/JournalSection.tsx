import React from 'react';
import { useRouter } from '../../lib/router';
import { BlogPost } from '../../types/database';
import { ArrowRight } from 'lucide-react';

interface JournalSectionProps {
  posts: BlogPost[];
}

export const JournalSection: React.FC<JournalSectionProps> = ({ posts }) => {
  const { navigate } = useRouter();

  return (
    <section className="py-24 sm:py-32 bg-[#0E0E0E] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              08 · Editorial & Thought
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              FROM THE JOURNAL
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Essays on acoustic architecture, visual philosophy, and craft.
            </p>
          </div>

          <button
            onClick={() => navigate('/journal')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>Read The Journal</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Editorial Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {posts.slice(0, 3).map((post) => (
            <article
              key={post.id}
              onClick={() => navigate(`/journal/${post.slug}`)}
              className="group cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Cover Image */}
                <div className="relative aspect-[16/10] overflow-hidden rounded-lg bg-[#141414] border border-white/5 group-hover:border-[#E5A93C]/40 transition-colors">
                  <img
                    src={post.cover_image}
                    alt={post.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>

                {/* Metadata */}
                <div className="flex items-center gap-2 text-xs text-[#A3A099]">
                  <span className="text-[#E5A93C] font-mono uppercase tracking-wider">{post.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{new Date(post.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors leading-snug">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-white/5">
                <span className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#E5A93C] group-hover:text-[#F3C065]">
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
