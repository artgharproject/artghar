import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { Collaboration, CollaborationCategory } from '../../types/database';
import { Handshake, ExternalLink, ArrowRight, Award, Sparkles, Building, Globe } from 'lucide-react';

export const CollaborationsSection: React.FC = () => {
  const { navigate } = useRouter();
  const collaborations = store.getCollaborations();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories: { label: string; value: string }[] = [
    { label: 'All Partnerships', value: 'all' },
    { label: 'Programs & Festivals', value: 'Program & Festival' },
    { label: 'Cultural Institutions', value: 'Cultural Institution' },
    { label: 'Studios & Companies', value: 'Company & Studio' },
    { label: 'Brand Alliances', value: 'Brand Partnership' },
  ];

  const filtered = selectedCategory === 'all'
    ? collaborations
    : collaborations.filter((c) => c.category === selectedCategory);

  return (
    <section className="py-24 sm:py-32 bg-[#0B0B0B] border-t border-white/5 relative overflow-hidden">
      {/* Subtle gold ambient glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-[#E5A93C]/5 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#E5A93C]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#E5A93C]/10 border border-[#E5A93C]/20 text-[#E5A93C] text-xs font-mono uppercase tracking-[0.25em]">
              <Handshake className="w-3.5 h-3.5" />
              <span>Institutional Alliances & Programs</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              COLLABORATIONS & ALLIANCES
            </h2>
            <p className="text-sm sm:text-base text-[#8E8B82] font-light leading-relaxed">
              Partnering with international film festivals, cultural heritage bodies, academic conservatories, and forward-thinking studios to expand the horizons of Himalayan storytelling.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/collaborations')}
              className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#E5A93C] hover:text-[#F3C065] group transition-colors"
            >
              <span>Explore All Alliances</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-10 pb-2 border-b border-white/5">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded transition-all duration-200 ${
                selectedCategory === cat.value
                  ? 'bg-[#E5A93C] text-[#0A0A0A] font-bold shadow-lg shadow-[#E5A93C]/20'
                  : 'bg-[#141414] text-[#A3A099] hover:text-white hover:bg-[#1A1A1A] border border-white/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Collaborations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="group bg-[#121212] border border-white/5 rounded-2xl p-6 sm:p-7 flex flex-col justify-between hover:border-[#E5A93C]/40 hover:bg-[#161616] transition-all duration-300 relative overflow-hidden"
            >
              <div className="space-y-5">
                {/* Header row with logo & year badge */}
                <div className="flex items-start justify-between gap-4">
                  <div className="w-14 h-14 rounded-xl overflow-hidden bg-black/60 border border-white/10 p-1.5 flex items-center justify-center shrink-0 group-hover:border-[#E5A93C]/40 transition-colors">
                    <img
                      src={item.logo}
                      alt={item.partner_name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform"
                    />
                  </div>

                  <div className="flex flex-col items-end gap-1.5">
                    <span className="px-2.5 py-0.5 text-[10px] font-mono uppercase bg-white/5 text-[#E5A93C] rounded border border-white/10">
                      {item.year}
                    </span>
                    <span className="text-[10px] font-mono text-[#71717A] uppercase tracking-wider">
                      {item.category}
                    </span>
                  </div>
                </div>

                {/* Partner Name & Program */}
                <div className="space-y-1.5">
                  <h3 className="text-lg font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors leading-snug">
                    {item.partner_name}
                  </h3>
                  <p className="text-xs font-mono text-[#E5A93C]/90 font-medium">
                    {item.program_name}
                  </p>
                </div>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed">
                  {item.description}
                </p>

                {/* Key Outcomes / Impact */}
                {item.outcomes && (
                  <div className="p-3 rounded-lg bg-black/40 border border-white/5 space-y-1">
                    <div className="flex items-center gap-1.5 text-[11px] font-mono text-[#A3A099] uppercase tracking-wider">
                      <Award className="w-3 h-3 text-[#E5A93C]" />
                      <span>Impact & Deliverables</span>
                    </div>
                    <p className="text-xs text-[#C8C5BC] font-light">
                      {item.outcomes}
                    </p>
                  </div>
                )}
              </div>

              {/* Footer link */}
              {item.website_url && (
                <div className="pt-5 mt-5 border-t border-white/5 flex items-center justify-between">
                  <a
                    href={item.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-mono text-[#8E8B82] hover:text-[#E5A93C] inline-flex items-center gap-1.5 transition-colors group/link"
                  >
                    <span>Visit Partner Initiative</span>
                    <ExternalLink className="w-3 h-3 transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" />
                  </a>
                  <span className="w-2 h-2 rounded-full bg-emerald-500/80 animate-pulse" title="Active Collaboration" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
