import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { Artist, ArtistCollaborationStatus } from '../../types/database';
import { ArrowRight, ArrowUpRight } from 'lucide-react';

interface ArtistsSectionProps {
  artists: Artist[];
}

export const ArtistsSection: React.FC<ArtistsSectionProps> = ({ artists }) => {
  const { navigate } = useRouter();
  const [activeTab, setActiveTab] = useState<'all' | ArtistCollaborationStatus>('all');

  const filteredArtists = artists.filter((a) => {
    if (activeTab === 'all') return true;
    return a.collaboration_status === activeTab;
  });

  const getStatusLabel = (status: ArtistCollaborationStatus) => {
    switch (status) {
      case 'worked':
        return 'Worked With Us';
      case 'upcoming':
        return 'Working Soon';
      default:
        return 'Current Roster';
    }
  };

  return (
    <section className="py-24 sm:py-32 bg-[#0E0E0E] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              04 · The Roster & Collaborators
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              THE ARTISTS
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Voices behind the stories: our active roster, esteemed collaborators, and upcoming talents.
            </p>
          </div>

          <button
            onClick={() => navigate('/artists')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>View All Artists</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Status Filter Segmented Controls */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 border-b border-white/10 scrollbar-none">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
              activeTab === 'all'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            All Artists ({artists.length})
          </button>

          <button
            onClick={() => setActiveTab('current')}
            className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
              activeTab === 'current'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Current Roster ({artists.filter((a) => a.collaboration_status === 'current').length})
          </button>

          <button
            onClick={() => setActiveTab('worked')}
            className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
              activeTab === 'worked'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Worked With Art Ghar ({artists.filter((a) => a.collaboration_status === 'worked').length})
          </button>

          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
              activeTab === 'upcoming'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Working Soon ({artists.filter((a) => a.collaboration_status === 'upcoming').length})
          </button>
        </div>

        {/* Editorial Artists Showcase: Large Photography & Refined Typography */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredArtists.slice(0, 6).map((artist) => (
            <div
              key={artist.id}
              onClick={() => navigate(`/artists/${artist.slug}`)}
              className="group cursor-pointer flex flex-col justify-between"
            >
              {/* Image Frame */}
              <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-[#141414] border border-white/5 group-hover:border-[#E5A93C]/40 transition-all duration-500 shadow-xl">
                <img
                  src={artist.profile_image}
                  alt={artist.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover grayscale contrast-110 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0E0E0E] via-transparent to-transparent opacity-90 group-hover:opacity-60 transition-opacity" />

                {/* Collaboration Status Pill & Genre */}
                <div className="absolute top-4 left-4">
                  <span
                    className={`px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider rounded backdrop-blur-md border ${
                      artist.collaboration_status === 'worked'
                        ? 'bg-amber-950/70 text-amber-300 border-amber-600/30'
                        : artist.collaboration_status === 'upcoming'
                        ? 'bg-blue-950/70 text-blue-300 border-blue-600/30'
                        : 'bg-black/70 text-[#E5A93C] border-[#E5A93C]/30'
                    }`}
                  >
                    {getStatusLabel(artist.collaboration_status)}
                  </span>
                </div>

                {/* Genre Tag on image corner */}
                <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between z-10">
                  <span className="text-[11px] font-mono text-[#E5A93C] uppercase tracking-wider bg-black/60 backdrop-blur-md px-2.5 py-1 rounded">
                    {artist.genre}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>
              </div>

              {/* Minimal Textual Profile */}
              <div className="mt-5 space-y-1.5">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                    {artist.name}
                  </h3>
                  <span className="text-xs text-[#71717A] font-mono">
                    {artist.location}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-2">
                  {artist.short_bio}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
