import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { TeamMember } from '../../types/database';
import {
  Mail,
  Phone,
  MapPin,
  ArrowRight,
  ArrowUpRight,
  Instagram,
  Linkedin,
  Shield,
  X,
  Sparkles,
} from 'lucide-react';

interface TeamSectionProps {
  members: TeamMember[];
}

export const TeamSection: React.FC<TeamSectionProps> = ({ members }) => {
  const { navigate } = useRouter();
  const [activeModalMember, setActiveModalMember] = useState<TeamMember | null>(null);

  const displayMembers = members.filter((m) => m.published);

  return (
    <section id="creative-team-section" className="py-24 sm:py-32 bg-[#0B0B0B] relative border-t border-white/5 overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 right-10 w-96 h-96 bg-[#E5A93C]/5 blur-[100px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block">
              05 · The Creative Architecture
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              MEET THE TEAM
            </h2>
            <p className="text-sm sm:text-base text-[#8E8B82] font-light max-w-xl">
              The visionary directors, sound architects, cinematographers, and producers who sculpt every Art Ghar narrative.
            </p>
          </div>

          <button
            onClick={() => navigate('/team')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>All Team Profiles</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Team Grid with Animated Images & Complete Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayMembers.map((member) => (
            <div
              key={member.id}
              className="group relative bg-[#121212] rounded-2xl border border-white/5 hover:border-[#E5A93C]/40 transition-all duration-500 overflow-hidden flex flex-col justify-between shadow-xl hover:shadow-[0_10px_30px_rgba(229,169,60,0.1)]"
            >
              {/* Animated Image Container */}
              <div
                onClick={() => setActiveModalMember(member)}
                className="relative aspect-[4/5] overflow-hidden cursor-pointer bg-[#1A1A1A]"
              >
                <img
                  src={member.image}
                  alt={member.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-108 group-hover:contrast-105"
                />

                {/* Ambient Shimmer / Vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/30 to-transparent opacity-90 group-hover:opacity-60 transition-opacity duration-500" />

                {/* Animated Gold Glow Border on Hover */}
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 group-hover:ring-[#E5A93C]/60 rounded-t-2xl transition-all duration-500" />

                {/* Role Badge in Top Corner */}
                <div className="absolute top-4 left-4 z-10">
                  <span className="px-3 py-1 bg-black/70 backdrop-blur-md border border-[#E5A93C]/40 text-[#E5A93C] text-[10px] font-mono uppercase tracking-wider rounded-full font-semibold">
                    {member.role.split('&')[0].trim()}
                  </span>
                </div>

                {/* Hover Quick View Trigger */}
                <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-8 h-8 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center shadow-lg">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Name Overlay in Image */}
                <div className="absolute bottom-4 left-4 right-4 z-10">
                  <h3 className="text-xl sm:text-2xl font-display font-bold text-white group-hover:text-[#E5A93C] transition-colors leading-tight">
                    {member.name}
                  </h3>
                  <p className="text-xs text-[#E5A93C]/90 font-mono tracking-wide mt-0.5">
                    {member.role}
                  </p>
                </div>
              </div>

              {/* Information & Contact Details Card */}
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                {/* Short Bio */}
                <p className="text-xs text-[#8E8B82] font-light leading-relaxed line-clamp-3">
                  {member.bio}
                </p>

                {/* Details Section: Address & Direct Contact */}
                <div className="pt-3 border-t border-white/5 space-y-2.5 text-xs text-[#C8C5BC]">
                  {/* Address */}
                  <div className="flex items-center gap-2.5">
                    <MapPin className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                    <span className="truncate">{member.address || 'Kathmandu Valley, Nepal'}</span>
                  </div>

                  {/* Email */}
                  {member.email && (
                    <div className="flex items-center gap-2.5">
                      <Mail className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                      <a
                        href={`mailto:${member.email}`}
                        className="truncate hover:text-[#E5A93C] transition-colors"
                      >
                        {member.email}
                      </a>
                    </div>
                  )}

                  {/* Phone */}
                  {member.phone && (
                    <div className="flex items-center gap-2.5">
                      <Phone className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                      <a
                        href={`tel:${member.phone}`}
                        className="truncate hover:text-[#E5A93C] transition-colors"
                      >
                        {member.phone}
                      </a>
                    </div>
                  )}
                </div>

                {/* Action Footer: Social links & Profile Button */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {member.instagram_url && (
                      <a
                        href={member.instagram_url}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-full hover:bg-white/10 text-[#A3A099] hover:text-[#E5A93C] transition-colors"
                        aria-label={`${member.name} on Instagram`}
                      >
                        <Instagram className="w-3.5 h-3.5" />
                      </a>
                    )}
                    {member.linkedin_url && (
                      <a
                        href={member.linkedin_url}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-full hover:bg-white/10 text-[#A3A099] hover:text-[#E5A93C] transition-colors"
                        aria-label={`${member.name} on LinkedIn`}
                      >
                        <Linkedin className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>

                  <button
                    onClick={() => setActiveModalMember(member)}
                    className="text-[11px] font-mono uppercase tracking-wider text-[#E5A93C] hover:text-[#F3C065] transition-colors flex items-center gap-1 group-hover:underline"
                  >
                    <span>Full Profile</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Member Details Modal */}
      {activeModalMember && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
        >
          <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 relative shadow-2xl animate-in zoom-in-95">
            <button
              onClick={() => setActiveModalMember(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors"
              aria-label="Close Profile"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col sm:flex-row gap-6 items-start">
              <img
                src={activeModalMember.image}
                alt={activeModalMember.name}
                referrerPolicy="no-referrer"
                className="w-32 h-40 sm:w-40 sm:h-52 object-cover object-top rounded-xl border border-white/10 shadow-lg shrink-0"
              />

              <div className="space-y-3">
                <span className="px-3 py-1 bg-[#E5A93C]/10 border border-[#E5A93C]/30 text-[#E5A93C] text-[10px] font-mono uppercase tracking-widest rounded-full">
                  Art Ghar Creative Core
                </span>
                <h3 className="text-2xl font-display font-extrabold text-white">
                  {activeModalMember.name}
                </h3>
                <p className="text-xs text-[#E5A93C] font-mono tracking-wider">
                  {activeModalMember.role}
                </p>
                <div className="flex items-center gap-2 text-xs text-[#8E8B82] pt-1">
                  <MapPin className="w-3.5 h-3.5 text-[#E5A93C]" />
                  <span>{activeModalMember.address}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-2 border-t border-white/5">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#E5A93C]">
                Artistic Statement & Role
              </h4>
              <p className="text-sm text-[#C8C5BC] font-light leading-relaxed whitespace-pre-line">
                {activeModalMember.bio}
              </p>
            </div>

            <div className="space-y-3 pt-2 border-t border-white/5">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#E5A93C]">
                Direct Contact & Credentials
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-[#E5A93C]" />
                  <a
                    href={`mailto:${activeModalMember.email}`}
                    className="text-[#F4F1EA] hover:text-[#E5A93C] truncate"
                  >
                    {activeModalMember.email}
                  </a>
                </div>
                {activeModalMember.phone && (
                  <div className="p-3 rounded-lg bg-white/5 border border-white/5 flex items-center gap-2.5">
                    <Phone className="w-4 h-4 text-[#E5A93C]" />
                    <a
                      href={`tel:${activeModalMember.phone}`}
                      className="text-[#F4F1EA] hover:text-[#E5A93C] truncate"
                    >
                      {activeModalMember.phone}
                    </a>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-4 flex justify-between items-center border-t border-white/5">
              <button
                onClick={() => {
                  setActiveModalMember(null);
                  navigate('/contact');
                }}
                className="px-5 py-2.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors"
              >
                Inquire With Team
              </button>
              <button
                onClick={() => setActiveModalMember(null)}
                className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
