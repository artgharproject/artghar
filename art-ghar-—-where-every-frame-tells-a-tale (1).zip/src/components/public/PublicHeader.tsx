import React, { useState, useEffect } from 'react';
import { useRouter } from '../../lib/router';
import { ArtGharLogo } from '../common/ArtGharLogo';
import { Menu, X, ArrowUpRight } from 'lucide-react';

export const PublicHeader: React.FC = () => {
  const { path, navigate } = useRouter();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Work', href: '/productions' },
    { label: 'Releases', href: '/releases' },
    { label: 'Artists', href: '/artists' },
    { label: 'Upcoming', href: '/upcoming' },
    { label: 'Team', href: '/team' },
    { label: 'Wall', href: '/gallery' },
    { label: 'Journal', href: '/journal' },
    { label: 'About', href: '/about' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/5 py-3.5 shadow-2xl'
            : 'bg-gradient-to-b from-[#0A0A0A]/80 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center">
            <button
              onClick={() => {
                navigate('/');
                setMobileMenuOpen(false);
              }}
              className="group flex items-center focus:outline-none focus-visible:ring-1 focus-visible:ring-[#E5A93C]"
              aria-label="Art Ghar Homepage"
            >
              <ArtGharLogo variant="compact" size="md" withGlow={isScrolled} />
            </button>
          </div>

          {/* Zone 2: 4-6 clean text navigation links (desktop) */}
          <nav className="hidden lg:flex items-center gap-7 text-[13px] tracking-[0.14em] uppercase font-medium text-[#A3A099]">
            {navLinks.map((link) => {
              const active = path === link.href || (link.href !== '/' && path.startsWith(link.href));
              return (
                <button
                  key={link.href}
                  onClick={() => navigate(link.href)}
                  className={`relative py-1 transition-colors whitespace-nowrap hover:text-[#F4F1EA] ${
                    active ? 'text-[#E5A93C] font-semibold' : ''
                  }`}
                >
                  {link.label}
                  {active && (
                    <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#E5A93C]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/contact')}
              className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-[#0A0A0A] bg-[#E5A93C] rounded hover:bg-[#F3C065] transition-all duration-200 tracking-wider uppercase whitespace-nowrap active:scale-[0.98]"
            >
              Contact
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#A3A099] hover:text-white focus:outline-none"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fullscreen Navigation Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#0A0A0A] flex flex-col justify-between p-8 pt-28 lg:hidden animate-in fade-in duration-200">
          <div className="flex flex-col space-y-5">
            <span className="text-[11px] font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Navigation
            </span>
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => {
                  navigate(link.href);
                  setMobileMenuOpen(false);
                }}
                className="text-left text-2xl font-display font-bold text-[#F4F1EA] hover:text-[#E5A93C] transition-colors py-1 flex items-center justify-between group"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity text-[#E5A93C]" />
              </button>
            ))}
          </div>

          <div className="border-t border-white/10 pt-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#A3A099]">Kathmandu, Nepal</span>
              <span className="text-xs text-[#71717A] uppercase font-mono">Creative Production</span>
            </div>
            <p className="text-[11px] text-[#71717A] tracking-wider uppercase font-mono">
              Where Every Frame Tells a Tale
            </p>
          </div>
        </div>
      )}
    </>
  );
};
