import React from 'react';
import { useRouter } from '../../lib/router';
import { ArtGharLogo } from '../common/ArtGharLogo';
import { ArrowDown, Play } from 'lucide-react';

interface HeroSectionProps {
  onWatchReel?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onWatchReel }) => {
  const { navigate } = useRouter();

  const scrollToContent = () => {
    const el = document.getElementById('story-intro');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0A0A0A]">
      {/* Background Cinematic Visual with Vignette & Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_cinematic_production_1790823187023.jpg"
          alt="Art Ghar Cinematic Production"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 animate-pulse duration-[10000ms] opacity-40"
        />
        {/* Deep cinematic grading scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/60 to-[#0A0A0A]/70" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#0A0A0A]/40 to-[#0A0A0A]" />
        <div className="absolute inset-0 film-grain opacity-60" />
      </div>

      {/* Main Content Box */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center pt-24 pb-16 flex flex-col items-center">
        {/* Real Art Ghar Logo Presentation */}
        <div className="mb-6 transform hover:scale-105 transition-transform duration-500">
          <ArtGharLogo variant="icon-only" size="xl" withGlow />
        </div>

        {/* Brand Headline */}
        <div className="space-y-3 max-w-4xl">
          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-extrabold tracking-tight text-[#F4F1EA] uppercase">
            ART <span className="text-[#E5A93C] gold-glow">GHAR</span>
          </h1>

          <p className="font-mono text-xs sm:text-sm md:text-base uppercase tracking-[0.35em] text-[#C8C5BC] font-medium pt-1">
            WHERE EVERY FRAME TELLS A TALE
          </p>
        </div>

        {/* Narrative Statement */}
        <p className="mt-8 text-base sm:text-lg md:text-xl text-[#A3A099] max-w-2xl font-light leading-relaxed">
          A creative house for music, stories, artists and visual experiences.
        </p>

        {/* Action Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
          <button
            onClick={() => navigate('/productions')}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold tracking-[0.2em] uppercase rounded transition-all duration-300 shadow-[0_0_25px_rgba(229,169,60,0.3)] hover:shadow-[0_0_35px_rgba(229,169,60,0.5)] active:scale-95"
          >
            Explore Our Work
          </button>

          <button
            onClick={() => navigate('/artists')}
            className="w-full sm:w-auto px-8 py-3.5 bg-white/5 hover:bg-white/10 text-[#F4F1EA] hover:text-white border border-white/15 hover:border-[#E5A93C]/50 text-xs font-medium tracking-[0.2em] uppercase rounded transition-all duration-300 active:scale-95 flex items-center justify-center gap-2"
          >
            <span>Discover Artists</span>
          </button>

          {onWatchReel && (
            <button
              onClick={onWatchReel}
              className="w-full sm:w-auto px-6 py-3.5 text-xs text-[#A3A099] hover:text-[#E5A93C] transition-colors uppercase tracking-[0.2em] flex items-center justify-center gap-2"
            >
              <Play className="w-3.5 h-3.5 fill-[#E5A93C] text-[#E5A93C]" />
              <span>Watch Reel</span>
            </button>
          )}
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
        <button
          onClick={scrollToContent}
          className="text-[#71717A] hover:text-[#E5A93C] transition-colors p-2 flex flex-col items-center gap-2 group focus:outline-none"
          aria-label="Scroll to content"
        >
          <span className="text-[10px] font-mono uppercase tracking-[0.25em] opacity-70 group-hover:opacity-100">
            Scroll
          </span>
          <ArrowDown className="w-4 h-4 animate-bounce text-[#E5A93C]" />
        </button>
      </div>
    </section>
  );
};
