import React from 'react';
import { useRouter } from '../../lib/router';
import { Release } from '../../types/database';
import { ArrowRight, Disc, ExternalLink } from 'lucide-react';

interface LatestReleasesSectionProps {
  releases: Release[];
}

export const LatestReleasesSection: React.FC<LatestReleasesSectionProps> = ({ releases }) => {
  const { navigate } = useRouter();

  const featuredRelease = releases.find((r) => r.featured) || releases[0];
  const otherReleases = releases.filter((r) => r.id !== featuredRelease?.id).slice(0, 3);

  return (
    <section className="py-24 sm:py-32 bg-[#0A0A0A] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              03 · Discography
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              LATEST RELEASES
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Stories already released into the world.
            </p>
          </div>

          <button
            onClick={() => navigate('/releases')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>View All Releases</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Layout Grid */}
        {releases.length === 0 ? (
          <div className="border border-white/5 rounded p-12 text-center text-[#8E8B82]">
            No releases published yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            {/* Major Featured Release Showcase */}
            {featuredRelease && (
              <div className="lg:col-span-6 flex flex-col justify-between bg-[#121212] border border-white/5 rounded-lg overflow-hidden group hover:border-[#E5A93C]/40 transition-all duration-300">
                <div className="relative aspect-square overflow-hidden bg-black/60">
                  <img
                    src={featuredRelease.cover_image}
                    alt={featuredRelease.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80" />

                  {/* Vinyl Record Icon overlay */}
                  <div className="absolute top-4 right-4 p-2 rounded-full bg-black/70 backdrop-blur-md text-[#E5A93C] border border-white/10">
                    <Disc className="w-5 h-5 animate-spin duration-[12000ms]" />
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-4">
                  <div className="flex items-center gap-2 text-xs text-[#A3A099] font-mono uppercase tracking-wider">
                    <span className="text-[#E5A93C]">{featuredRelease.release_type}</span>
                    <span>·</span>
                    <span>{featuredRelease.release_date}</span>
                  </div>

                  <h3
                    onClick={() => navigate(`/releases/${featuredRelease.slug}`)}
                    className="text-2xl sm:text-3xl font-display font-bold text-[#F4F1EA] hover:text-[#E5A93C] transition-colors cursor-pointer"
                  >
                    {featuredRelease.title}
                  </h3>

                  {featuredRelease.artist && (
                    <p className="text-sm text-[#C8C5BC]">
                      Performed by{' '}
                      <button
                        onClick={() => navigate(`/artists/${featuredRelease.artist?.slug}`)}
                        className="text-[#E5A93C] hover:underline"
                      >
                        {featuredRelease.artist.name}
                      </button>
                    </p>
                  )}

                  <p className="text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-3">
                    {featuredRelease.description}
                  </p>

                  <div className="pt-2 flex items-center justify-between border-t border-white/5">
                    <button
                      onClick={() => navigate(`/releases/${featuredRelease.slug}`)}
                      className="text-xs font-mono uppercase tracking-widest text-[#E5A93C] hover:text-[#F3C065] flex items-center gap-1.5"
                    >
                      <span>Listen & Credits</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {featuredRelease.spotify_url && (
                      <a
                        href={featuredRelease.spotify_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-[#A3A099] hover:text-[#F4F1EA] flex items-center gap-1"
                      >
                        <span>Spotify</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Supporting Releases List */}
            <div className="lg:col-span-6 flex flex-col justify-between gap-6">
              {otherReleases.map((item) => (
                <div
                  key={item.id}
                  className="group bg-[#121212] border border-white/5 rounded-lg p-5 flex flex-col sm:flex-row gap-5 hover:border-[#E5A93C]/40 transition-all duration-300"
                >
                  <div className="w-full sm:w-32 aspect-square shrink-0 rounded overflow-hidden relative bg-black/60">
                    <img
                      src={item.cover_image}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>

                  <div className="flex-1 flex flex-col justify-between space-y-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-[11px] text-[#A3A099] font-mono uppercase tracking-wider">
                        <span className="text-[#E5A93C]">{item.release_type}</span>
                        <span>·</span>
                        <span>{item.release_date}</span>
                      </div>
                      <h4
                        onClick={() => navigate(`/releases/${item.slug}`)}
                        className="text-lg font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors cursor-pointer"
                      >
                        {item.title}
                      </h4>
                      {item.artist && (
                        <p className="text-xs text-[#8E8B82] font-medium">{item.artist.name}</p>
                      )}
                    </div>

                    <div className="pt-2 flex items-center justify-between text-xs text-[#71717A] border-t border-white/5">
                      <button
                        onClick={() => navigate(`/releases/${item.slug}`)}
                        className="text-[#E5A93C] hover:underline uppercase font-mono text-[11px] tracking-wider"
                      >
                        Listen Now →
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
