import React from 'react';

export const IntroSection: React.FC = () => {
  return (
    <section id="story-intro" className="py-28 sm:py-36 bg-[#0A0A0A] relative border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Monolithic Editorial Headline */}
          <div className="lg:col-span-7">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-4">
              01 · The Purpose
            </span>
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-display font-extrabold tracking-tight text-[#F4F1EA] uppercase leading-[1.08] text-balance">
              WE CREATE<br />
              WHAT PEOPLE<br />
              <span className="text-[#E5A93C]">REMEMBER.</span>
            </h2>
          </div>

          {/* Right Column: Thoughtful Prose */}
          <div className="lg:col-span-5 space-y-6 pt-2">
            <p className="text-lg sm:text-xl text-[#C8C5BC] font-light leading-relaxed">
              Art Ghar is a creative production house bringing together music, visual storytelling, artists and original ideas.
            </p>
            <p className="text-sm sm:text-base text-[#8E8B82] leading-relaxed font-light">
              Rooted in the cultural depth of the Kathmandu Valley and expanding across global horizons, we construct every soundscape and visual frame with architectural patience. We do not chase fleeting internet noise; we build enduring art.
            </p>

            <div className="pt-4 border-t border-white/10 flex items-center gap-8 text-xs font-mono text-[#A3A099] uppercase tracking-wider">
              <div>
                <span className="text-white block font-bold text-base">Nepal</span>
                <span className="text-[11px] text-[#71717A]">Heritage & Future</span>
              </div>
              <div className="w-[1px] h-8 bg-white/10" />
              <div>
                <span className="text-[#E5A93C] block font-bold text-base">Cinema</span>
                <span className="text-[11px] text-[#71717A]">Analog & Digital</span>
              </div>
              <div className="w-[1px] h-8 bg-white/10" />
              <div>
                <span className="text-white block font-bold text-base">Audio</span>
                <span className="text-[11px] text-[#71717A]">Acoustic Soul</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
