import React from 'react';
import { useRouter } from '../../lib/router';
import { ArtGharLogo } from '../common/ArtGharLogo';
import { store } from '../../lib/store';
import { Instagram, Youtube, Music2, Facebook, ArrowUpRight } from 'lucide-react';

export const PublicFooter: React.FC = () => {
  const { navigate } = useRouter();
  const settings = store.getSiteSettings();

  return (
    <footer className="bg-[#070707] border-t border-white/5 pt-20 pb-12 text-[#A3A099]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-white/5">
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-6">
            <button
              onClick={() => navigate('/')}
              className="text-left focus:outline-none focus-visible:ring-1 focus-visible:ring-[#E5A93C]"
            >
              <ArtGharLogo variant="full" size="lg" withGlow />
            </button>
            <p className="text-sm text-[#8E8B82] max-w-sm leading-relaxed font-light">
              A creative production house in Kathmandu bringing together music, visual storytelling, artists, and original cinematic narratives.
            </p>
            <div className="pt-2 flex items-center gap-3.5 text-[#F4F1EA]">
              <a
                href={settings.youtube_url || 'https://www.youtube.com/@artgharofficial'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                aria-label="YouTube"
                title="YouTube: @artgharofficial"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href={settings.facebook_url || 'https://www.facebook.com/artgharofficial'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                aria-label="Facebook"
                title="Facebook: @artgharofficial"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={settings.tiktok_url || 'https://www.tiktok.com/@artghar_official'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors font-bold text-xs"
                aria-label="TikTok"
                title="TikTok: @artghar_official"
              >
                <span>TT</span>
              </a>
              <a
                href={settings.instagram_url || 'https://instagram.com/artghar'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={settings.spotify_url || 'https://spotify.com'}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                aria-label="Spotify"
              >
                <Music2 className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Directory
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => navigate('/productions')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  Selected Productions
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/releases')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  Music Releases
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/artists')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  Artist Roster
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/upcoming')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  Upcoming Projects
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/team')}
                  className="hover:text-[#F4F1EA] transition-colors text-[#E5A93C]"
                >
                  Creative Team
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/videos')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  Watch Videos
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/gallery')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  The Art Ghar Wall
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('/journal')}
                  className="hover:text-[#F4F1EA] transition-colors"
                >
                  The Journal
                </button>
              </li>
            </ul>
          </div>

          {/* Studio Location & Inquiries */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Studio Inquiries
            </h4>
            <p className="text-sm text-[#C8C5BC] leading-relaxed">
              Jhamsikhel, Lalitpur<br />
              Kathmandu Valley, Nepal
            </p>
            <div className="space-y-1 text-sm">
              <div>
                <span className="text-xs text-[#71717A] uppercase tracking-wider block">Email</span>
                <a
                  href={`mailto:${settings.contact_email || 'artgharproject@gmail.com'}`}
                  className="text-[#F4F1EA] hover:text-[#E5A93C] transition-colors underline-offset-4 hover:underline"
                >
                  {settings.contact_email || 'artgharproject@gmail.com'}
                </a>
              </div>
              <div className="pt-2">
                <span className="text-xs text-[#71717A] uppercase tracking-wider block">Telephone</span>
                <span className="text-[#C8C5BC]">{settings.phone || '+977 1 552 4981'}</span>
              </div>
            </div>
            <div className="pt-2">
              <button
                onClick={() => navigate('/contact')}
                className="inline-flex items-center gap-1.5 text-xs text-[#E5A93C] hover:text-[#F3C065] transition-colors font-medium uppercase tracking-wider"
              >
                <span>Initiate A Collaboration</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#71717A] gap-4">
          <p>© 2026 Art Ghar Creative House. All rights reserved.</p>

          <div className="flex items-center gap-6">
            <button
              onClick={() => navigate('/team')}
              className="hover:text-[#A3A099] transition-colors"
            >
              Creative Team
            </button>
            <button
              onClick={() => navigate('/about')}
              className="hover:text-[#A3A099] transition-colors"
            >
              About House
            </button>
            <button
              onClick={() => navigate('/contact')}
              className="hover:text-[#A3A099] transition-colors"
            >
              Contact
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
