import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { Video } from '../../types/database';
import { Play, ChevronLeft, ChevronRight, ExternalLink, ArrowRight } from 'lucide-react';

interface VideoSliderSectionProps {
  videos: Video[];
}

export const VideoSliderSection: React.FC<VideoSliderSectionProps> = ({ videos }) => {
  const { navigate } = useRouter();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  // If no videos, return null
  if (!videos || videos.length === 0) return null;

  const currentVideo = videos[currentSlideIndex] || videos[0];

  const handleNext = () => {
    setIsPlaying(false);
    setCurrentSlideIndex((prev) => (prev + 1) % videos.length);
  };

  const handlePrev = () => {
    setIsPlaying(false);
    setCurrentSlideIndex((prev) => (prev - 1 + videos.length) % videos.length);
  };

  const extractYouTubeId = (url: string) => {
    if (!url) return '9ik9froFIHs';
    if (url.includes('youtu.be/')) {
      return url.split('youtu.be/')[1]?.split('?')[0];
    }
    if (url.includes('v=')) {
      return url.split('v=')[1]?.split('&')[0];
    }
    return url;
  };

  const videoId = extractYouTubeId(currentVideo.youtube_url);

  return (
    <section className="py-24 sm:py-32 bg-[#080808] relative border-t border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              Featured Premieres & Releases
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              RELEASED VIDEO REEL
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Official Art Ghar music videos and cinematic motion pictures available to watch right now.
            </p>
          </div>

          <div className="flex items-center gap-3 self-start md:self-end">
            <button
              onClick={handlePrev}
              className="p-3 rounded-full bg-[#141414] border border-white/10 text-white/80 hover:text-white hover:border-[#E5A93C] transition-colors focus:outline-none"
              aria-label="Previous Video Slide"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="p-3 rounded-full bg-[#141414] border border-white/10 text-white/80 hover:text-white hover:border-[#E5A93C] transition-colors focus:outline-none"
              aria-label="Next Video Slide"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Cinema Slider Stage */}
        <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-black border border-white/10 shadow-2xl group">
          {isPlaying ? (
            <div className="w-full h-full">
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`}
                title={currentVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>
          ) : (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={
                  currentVideo.thumbnail.startsWith('http')
                    ? currentVideo.thumbnail
                    : `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
                }
                onError={(e) => {
                  // Fallback to hqdefault if maxres not available on YT
                  (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                }}
                alt={currentVideo.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-black/50" />

              {/* Play Action */}
              <button
                onClick={() => setIsPlaying(true)}
                className="relative z-10 w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center shadow-[0_0_40px_rgba(229,169,60,0.5)] hover:scale-110 active:scale-95 transition-all duration-300 group-hover:bg-[#F3C065]"
                aria-label={`Play ${currentVideo.title}`}
              >
                <Play className="w-8 h-8 fill-current ml-1" />
              </button>

              {/* Metadata Overlay */}
              <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4 z-10">
                <div className="space-y-1.5 max-w-2xl">
                  <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
                    <span>{currentVideo.category}</span>
                    <span>·</span>
                    <span>Official Release</span>
                  </div>
                  <h3 className="text-xl sm:text-3xl font-display font-bold text-white">
                    {currentVideo.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#C8C5BC] font-light line-clamp-2">
                    {currentVideo.description}
                  </p>
                </div>

                <a
                  href={currentVideo.youtube_url}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 bg-white/10 hover:bg-[#E5A93C] text-white hover:text-black rounded text-xs font-mono uppercase tracking-wider transition-colors inline-flex items-center gap-1.5 self-start sm:self-auto shrink-0"
                >
                  <span>Watch On YouTube</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Thumbnail Selector Bar below main slide */}
        <div className="mt-6 grid grid-cols-3 gap-4">
          {videos.slice(0, 3).map((v, idx) => {
            const vId = extractYouTubeId(v.youtube_url);
            const active = idx === currentSlideIndex;
            return (
              <div
                key={v.id}
                onClick={() => {
                  setIsPlaying(false);
                  setCurrentSlideIndex(idx);
                }}
                className={`group cursor-pointer rounded-xl overflow-hidden bg-[#121212] border transition-all duration-300 p-2 sm:p-3 flex items-center gap-3 ${
                  active ? 'border-[#E5A93C] bg-[#1a1710]' : 'border-white/5 hover:border-white/20'
                }`}
              >
                <div className="relative w-16 sm:w-24 aspect-[16/9] rounded overflow-hidden bg-black shrink-0">
                  <img
                    src={`https://img.youtube.com/vi/${vId}/hqdefault.jpg`}
                    alt={v.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <Play className="w-3 h-3 text-[#E5A93C] fill-current" />
                  </div>
                </div>

                <div className="truncate">
                  <span className="text-[10px] font-mono text-[#E5A93C] uppercase block">
                    Track 0{idx + 1}
                  </span>
                  <h4 className="text-xs sm:text-sm font-semibold text-white truncate">
                    {v.title}
                  </h4>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
