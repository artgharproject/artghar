import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { Video } from '../../types/database';
import { extractYoutubeId, getYoutubeEmbedUrl, getYoutubeThumbnail } from '../../lib/youtube';
import { Play, Volume2, ArrowRight } from 'lucide-react';

interface VideoSectionProps {
  videos: Video[];
}

export const VideoSection: React.FC<VideoSectionProps> = ({ videos }) => {
  const { navigate } = useRouter();
  const [isPlaying, setIsPlaying] = useState(false);

  const featuredVideo = videos.find((v) => v.featured) || videos[0];

  return (
    <section className="py-24 sm:py-32 bg-[#0E0E0E] relative border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block mb-2">
              06 · Cinema Screen
            </span>
            <h2 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
              WATCH THE STORY
            </h2>
            <p className="mt-2 text-base text-[#8E8B82] font-light">
              Cinematic visual motion crafted inside the house.
            </p>
          </div>

          <button
            onClick={() => navigate('/videos')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C] hover:text-[#F3C065] transition-colors group self-start md:self-end"
          >
            <span>Video Vault</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Video Cinema Player Canvas */}
        {featuredVideo && (
          <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-black border border-white/10 shadow-2xl group">
            {isPlaying ? (
              <div className="w-full h-full">
                <iframe
                  src={getYoutubeEmbedUrl(featuredVideo.youtube_url, true)}
                  title={featuredVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full border-0"
                />
              </div>
            ) : (
              <div className="relative w-full h-full flex items-center justify-center">
                <img
                  src={featuredVideo.thumbnail || getYoutubeThumbnail(featuredVideo.youtube_url)}
                  alt={featuredVideo.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-70"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/40" />

                {/* Big Center Play Button */}
                <button
                  onClick={() => setIsPlaying(true)}
                  className="relative z-10 w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center shadow-[0_0_40px_rgba(229,169,60,0.5)] hover:scale-110 active:scale-95 transition-all duration-300 group-hover:bg-[#F3C065]"
                  aria-label="Play Featured Video"
                >
                  <Play className="w-8 h-8 fill-current ml-1" />
                </button>

                {/* Sound Notice & Title */}
                <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4 z-10">
                  <div className="space-y-1">
                    <span className="text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
                      {featuredVideo.category} · {featuredVideo.release_date}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-display font-bold text-white max-w-2xl">
                      {featuredVideo.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-[#A3A099] font-mono">
                    <Volume2 className="w-4 h-4 text-[#E5A93C]" />
                    <span>Click to initialize playback with sound</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
