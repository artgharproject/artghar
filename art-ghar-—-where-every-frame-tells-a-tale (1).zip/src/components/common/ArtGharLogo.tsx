import React from 'react';

interface ArtGharLogoProps {
  className?: string;
  variant?: 'full' | 'compact' | 'icon-only' | 'badge';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  withGlow?: boolean;
}

export const ArtGharLogo: React.FC<ArtGharLogoProps> = ({
  className = '',
  variant = 'full',
  size = 'md',
  withGlow = false,
}) => {
  // Size dimensions
  const iconSize = {
    sm: 32,
    md: 46,
    lg: 64,
    xl: 88,
  }[size];

  const titleSize = {
    sm: 'text-sm tracking-wider',
    md: 'text-lg tracking-widest',
    lg: 'text-2xl tracking-[0.25em]',
    xl: 'text-3xl tracking-[0.3em]',
  }[size];

  const taglineSize = {
    sm: 'text-[7px] tracking-[0.2em]',
    md: 'text-[9px] tracking-[0.28em]',
    lg: 'text-[11px] tracking-[0.35em]',
    xl: 'text-xs tracking-[0.4em]',
  }[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* SVG Icon of the house + bird + film-strip + glowing window */}
      <div className={`relative shrink-0 flex items-center justify-center ${withGlow ? 'drop-shadow-[0_0_16px_rgba(229,169,60,0.6)]' : ''}`}>
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 120 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="transition-transform duration-300 group-hover:scale-105"
        >
          {/* Subtle warm golden ambient aura */}
          <circle cx="60" cy="62" r="48" fill="url(#goldAura)" opacity="0.25" />

          {/* Golden outline glow path */}
          <path
            d="M24 84L24 74L35 74L35 48L44 48L44 65L60 48L96 84H24Z"
            stroke="#E5A93C"
            strokeWidth="3"
            strokeLinejoin="round"
            opacity="0.85"
          />

          {/* House Main Silhouette (Dark with Warm Glow Border) */}
          <g filter="url(#goldRimFilter)">
            {/* Chimney */}
            <rect x="35" y="44" width="9" height="24" fill="#0A0A0A" stroke="#E5A93C" strokeWidth="1.5" />
            
            {/* House Body & Roof */}
            <polygon
              points="18,84 60,44 102,84 18,84"
              fill="#0A0A0A"
              stroke="#E5A93C"
              strokeWidth="2.5"
            />
            {/* Base lower sill */}
            <rect x="15" y="83" width="90" height="3" rx="1.5" fill="#E5A93C" />
          </g>

          {/* Film Strip Roof detail on right roof slope */}
          <g transform="rotate(43 60 44)">
            {/* Film border strip */}
            <rect x="58" y="44" width="38" height="11" rx="1.5" fill="#0A0A0A" stroke="#E5A93C" strokeWidth="1.5" />
            {/* Perforations */}
            <rect x="62" y="46.5" width="4" height="6" rx="0.5" fill="#F4F1EA" />
            <rect x="70" y="46.5" width="4" height="6" rx="0.5" fill="#F4F1EA" />
            <rect x="78" y="46.5" width="4" height="6" rx="0.5" fill="#F4F1EA" />
            <rect x="86" y="46.5" width="4" height="6" rx="0.5" fill="#F4F1EA" />
          </g>

          {/* Arched Window glowing in the center of the house */}
          <g filter="url(#windowGlow)">
            {/* Arch Top Left */}
            <path d="M54 67C54 63.5 56 62 58.5 62V69H54V67Z" fill="#F5C451" />
            {/* Arch Top Right */}
            <path d="M66 67C66 63.5 64 62 61.5 62V69H66V67Z" fill="#F5C451" />
            {/* Bottom Left Pane */}
            <rect x="54" y="70.5" width="4.5" height="5.5" fill="#E5A93C" />
            {/* Bottom Right Pane */}
            <rect x="61.5" y="70.5" width="4.5" height="5.5" fill="#E5A93C" />
          </g>

          {/* Songbird perched atop the roof apex */}
          <g id="birdSilhouette" fill="#0A0A0A" stroke="#E5A93C" strokeWidth="1">
            {/* Bird body, head and beak */}
            <path
              d="M51 43.5C53.5 42 57 40.5 59.5 42.5C61 40 64.5 40 66.5 41.5C68.5 41 70 41.5 71 42C69 43 68 44 67.5 45C66.5 46.5 64 47 62 46.5C57.5 46 54 45.5 51 43.5Z"
              fill="#0A0A0A"
            />
            {/* Bird tail */}
            <path d="M50 43.5L44 41L45.5 44.5L50 45Z" fill="#0A0A0A" />
            {/* Bird eye point */}
            <circle cx="66" cy="42" r="0.8" fill="#F5C451" />
            {/* Legs standing on apex */}
            <line x1="59" y1="46" x2="59" y2="48" stroke="#E5A93C" strokeWidth="1.2" />
            <line x1="62" y1="46" x2="62" y2="48" stroke="#E5A93C" strokeWidth="1.2" />
          </g>

          {/* SVG Definitions */}
          <defs>
            <radialGradient id="goldAura" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#E5A93C" stopOpacity="0.8" />
              <stop offset="60%" stopColor="#D4952B" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#0A0A0A" stopOpacity="0" />
            </radialGradient>
            <filter id="windowGlow" x="48" y="56" width="24" height="26" filterUnits="userSpaceOnUse">
              <feGaussianBlur stdDeviation="1.5" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
            <filter id="goldRimFilter" x="10" y="38" width="100" height="55" filterUnits="userSpaceOnUse">
              <feDropShadow dx="0" dy="0" stdDeviation="2.5" floodColor="#E5A93C" floodOpacity="0.45" />
            </filter>
          </defs>
        </svg>
      </div>

      {/* Typography Lockup */}
      {variant !== 'icon-only' && (
        <div className="flex flex-col">
          <div className={`font-extrabold text-[#F4F1EA] font-display uppercase tracking-widest ${titleSize} flex items-center gap-1`}>
            <span>ART</span>
            <span className="text-[#E5A93C]">GHAR</span>
          </div>

          {variant === 'full' && (
            <span className={`font-mono text-[#A3A099] uppercase font-medium mt-0.5 tracking-[0.25em] ${taglineSize}`}>
              WHERE EVERY FRAME TELLS A TALE
            </span>
          )}
        </div>
      )}
    </div>
  );
};
