import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface MediaLightboxProps {
  isOpen: boolean;
  onClose: () => void;
  items: Array<{
    title: string;
    image_url: string;
    caption?: string;
    category?: string;
  }>;
  currentIndex: number;
  onNavigate: (newIndex: number) => void;
}

export const MediaLightbox: React.FC<MediaLightboxProps> = ({
  isOpen,
  onClose,
  items,
  currentIndex,
  onNavigate,
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight') {
        onNavigate((currentIndex + 1) % items.length);
      } else if (e.key === 'ArrowLeft') {
        onNavigate((currentIndex - 1 + items.length) % items.length);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, currentIndex, items.length, onClose, onNavigate]);

  if (!isOpen || !items[currentIndex]) return null;

  const currentItem = items[currentIndex];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-[#0A0A0A]/95 backdrop-blur-xl flex flex-col justify-between p-4 sm:p-8 animate-in fade-in duration-200"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-[#E5A93C] uppercase tracking-widest">
            Art Ghar Gallery
          </span>
          <span className="text-xs text-[#71717A] font-mono">
            {currentIndex + 1} / {items.length}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-[#A3A099] hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-colors focus:outline-none"
          aria-label="Close Lightbox"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Main Image Display */}
      <div className="relative flex-1 flex items-center justify-center py-4 max-h-[82vh]">
        {/* Previous Button */}
        {items.length > 1 && (
          <button
            onClick={() => onNavigate((currentIndex - 1 + items.length) % items.length)}
            className="absolute left-2 sm:left-6 z-10 p-3 rounded-full bg-black/60 border border-white/10 text-white/80 hover:text-white hover:border-[#E5A93C] transition-colors focus:outline-none"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Current Image */}
        <div className="relative max-h-full max-w-full flex items-center justify-center">
          <img
            src={currentItem.image_url}
            alt={currentItem.title}
            referrerPolicy="no-referrer"
            className="max-h-[75vh] max-w-full object-contain rounded shadow-2xl transition-all duration-300"
          />
        </div>

        {/* Next Button */}
        {items.length > 1 && (
          <button
            onClick={() => onNavigate((currentIndex + 1) % items.length)}
            className="absolute right-2 sm:right-6 z-10 p-3 rounded-full bg-black/60 border border-white/10 text-white/80 hover:text-white hover:border-[#E5A93C] transition-colors focus:outline-none"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Info Bar */}
      <div className="max-w-3xl mx-auto w-full text-center space-y-1 z-10 pb-2">
        <div className="flex items-center justify-center gap-2 text-xs text-[#E5A93C] font-mono uppercase tracking-wider">
          {currentItem.category && <span>{currentItem.category}</span>}
        </div>
        <h3 className="text-lg font-display font-semibold text-[#F4F1EA]">
          {currentItem.title}
        </h3>
        {currentItem.caption && (
          <p className="text-xs sm:text-sm text-[#A3A099] font-light max-w-xl mx-auto">
            {currentItem.caption}
          </p>
        )}
      </div>
    </div>
  );
};
