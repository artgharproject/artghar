import React, { useRef, useState } from 'react';
import { Upload, X, Image as ImageIcon, Link as LinkIcon, RefreshCw, CheckCircle2 } from 'lucide-react';

interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  aspectRatio?: 'square' | 'video' | 'portrait' | 'wide' | 'auto';
  helperText?: string;
}

export const ImageUploadField: React.FC<ImageUploadFieldProps> = ({
  label,
  value,
  onChange,
  required = false,
  aspectRatio = 'auto',
  helperText,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // Client-side image compression and resizing using canvas
  const processFile = (file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      alert('Please select a valid image file (JPG, PNG, WEBP, GIF).');
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Max dimension 1600px for high definition and fast saving
        const maxDim = 1600;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          // Export high quality JPEG or PNG
          const mimeType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
          const quality = mimeType === 'image/jpeg' ? 0.88 : undefined;
          const compressedDataUrl = canvas.toDataURL(mimeType, quality);
          onChange(compressedDataUrl);
          setIsProcessing(false);
          setUploadSuccess(true);
          setTimeout(() => setUploadSuccess(false), 2500);
        } else {
          // Fallback to raw data url
          onChange(e.target?.result as string);
          setIsProcessing(false);
          setUploadSuccess(true);
          setTimeout(() => setUploadSuccess(false), 2500);
        }
      };

      img.onerror = () => {
        setIsProcessing(false);
        alert('Failed to process image file.');
      };

      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const getAspectRatioClass = () => {
    switch (aspectRatio) {
      case 'square':
        return 'aspect-square';
      case 'video':
        return 'aspect-[16/9]';
      case 'portrait':
        return 'aspect-[3/4]';
      case 'wide':
        return 'aspect-[21/9]';
      default:
        return 'aspect-[16/9] sm:aspect-[2/1] max-h-48';
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] flex items-center gap-1.5">
          <span>{label}</span>
          {required && <span className="text-[#E5A93C]">*</span>}
        </label>
        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] font-mono text-[#71717A] hover:text-[#E5A93C] transition-colors flex items-center gap-1"
        >
          <LinkIcon className="w-3 h-3" />
          <span>{showUrlInput ? 'Direct Computer Upload' : 'Enter URL instead'}</span>
        </button>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {showUrlInput ? (
        /* Alternative URL Input */
        <div className="space-y-2">
          <input
            type="text"
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://... or /src/assets/..."
            className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C] text-sm"
          />
          {value && (
            <div className="relative w-24 h-16 rounded overflow-hidden border border-white/10 bg-black">
              <img src={value} alt="Preview" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </div>
          )}
        </div>
      ) : (
        /* Direct Computer Upload Zone */
        <div className="space-y-2">
          {value ? (
            /* Uploaded Preview State */
            <div className="relative group bg-[#161616] border border-white/10 hover:border-[#E5A93C]/40 rounded-xl overflow-hidden p-3 flex flex-col sm:flex-row items-center gap-4 transition-all">
              <div className={`relative w-28 sm:w-36 h-24 rounded-lg overflow-hidden border border-white/10 bg-black shrink-0 ${getAspectRatioClass()}`}>
                <img
                  src={value}
                  alt="Uploaded poster"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 min-w-0 space-y-1.5 w-full">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-mono font-semibold text-white">
                    Image Loaded & Ready
                  </span>
                  {uploadSuccess && (
                    <span className="text-[10px] font-mono text-emerald-400 animate-pulse">
                      (Uploaded from computer)
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-[#8E8B82] font-mono truncate">
                  {value.startsWith('data:') ? 'Computer local upload (stored)' : value}
                </p>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isProcessing}
                    className="px-3 py-1 bg-white/10 hover:bg-[#E5A93C] hover:text-[#0A0A0A] text-[#F4F1EA] text-xs font-mono uppercase tracking-wider rounded transition-all flex items-center gap-1.5 active:scale-95"
                  >
                    <RefreshCw className={`w-3 h-3 ${isProcessing ? 'animate-spin' : ''}`} />
                    <span>Change File</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onChange('')}
                    className="px-2.5 py-1 text-xs text-[#8E8B82] hover:text-red-400 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Dropzone / Upload Trigger Button */
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`cursor-pointer border-2 border-dashed rounded-xl p-6 sm:p-8 text-center transition-all duration-200 flex flex-col items-center justify-center gap-3 ${
                isDragging
                  ? 'border-[#E5A93C] bg-[#E5A93C]/10 scale-[0.99]'
                  : 'border-white/15 hover:border-[#E5A93C]/60 bg-[#161616] hover:bg-[#1A1A1A]'
              }`}
            >
              <div className="w-12 h-12 rounded-full bg-[#E5A93C]/10 border border-[#E5A93C]/30 flex items-center justify-center text-[#E5A93C]">
                {isProcessing ? (
                  <RefreshCw className="w-6 h-6 animate-spin text-[#E5A93C]" />
                ) : (
                  <Upload className="w-6 h-6" />
                )}
              </div>

              <div className="space-y-1">
                <p className="text-xs sm:text-sm font-semibold text-white">
                  {isProcessing
                    ? 'Processing and compressing image...'
                    : 'Click to upload from computer or drag & drop'}
                </p>
                <p className="text-[11px] font-mono text-[#71717A]">
                  Direct file upload · Supports JPG, PNG, WEBP, GIF · Auto-optimized
                </p>
              </div>

              <button
                type="button"
                className="mt-1 px-4 py-1.5 bg-[#E5A93C] text-[#0A0A0A] hover:bg-[#F3C065] text-xs font-mono uppercase font-bold tracking-wider rounded transition-all"
              >
                Browse Computer Files
              </button>
            </div>
          )}
        </div>
      )}

      {helperText && (
        <p className="text-[11px] font-mono text-[#71717A]">{helperText}</p>
      )}
    </div>
  );
};
