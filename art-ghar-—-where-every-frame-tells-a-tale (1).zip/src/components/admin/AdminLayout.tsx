import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArtGharLogo } from '../common/ArtGharLogo';
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Disc,
  Clock,
  Film,
  Video,
  Image,
  BookOpen,
  Milestone,
  Mail,
  Settings,
  ShieldCheck,
  LogOut,
  ExternalLink,
  Search,
  Menu,
  X,
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children, title }) => {
  const { path, navigate } = useRouter();
  const currentUser = store.getCurrentUser();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');

  // Unread messages count
  const unreadMessagesCount = store.getContactMessages().filter((m) => m.status === 'New').length;

  const navItems = [
    { label: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { label: 'Artists', href: '/admin/artists', icon: Users },
    { label: 'Creative Team', href: '/admin/team', icon: UserCheck },
    { label: 'Releases', href: '/admin/releases', icon: Disc },
    { label: 'Upcoming', href: '/admin/upcoming', icon: Clock },
    { label: 'Productions', href: '/admin/productions', icon: Film },
    { label: 'Videos', href: '/admin/videos', icon: Video },
    { label: 'Gallery Wall', href: '/admin/gallery', icon: Image },
    { label: 'Journal CMS', href: '/admin/journal', icon: BookOpen },
    { label: 'Timeline', href: '/admin/timeline', icon: Milestone },
    {
      label: 'Messages',
      href: '/admin/messages',
      icon: Mail,
      badge: unreadMessagesCount > 0 ? unreadMessagesCount : undefined,
    },
    { label: 'Settings', href: '/admin/settings', icon: Settings },
  ];

  if (currentUser?.role === 'admin') {
    navItems.push({ label: 'Admin Users', href: '/admin/admin-users', icon: ShieldCheck });
  }

  // Global search filtering
  const allArtists = store.getArtists(true);
  const allReleases = store.getReleases(true);
  const allUpcoming = store.getUpcomingProjects(true);
  const allProductions = store.getProductions(true);
  const allPosts = store.getBlogPosts(true);

  const searchResults = globalSearchTerm.trim().length > 1
    ? {
        artists: allArtists.filter((a) => a.name.toLowerCase().includes(globalSearchTerm.toLowerCase())),
        releases: allReleases.filter((r) => r.title.toLowerCase().includes(globalSearchTerm.toLowerCase())),
        upcoming: allUpcoming.filter((u) => u.title.toLowerCase().includes(globalSearchTerm.toLowerCase())),
        productions: allProductions.filter((p) => p.title.toLowerCase().includes(globalSearchTerm.toLowerCase())),
        posts: allPosts.filter((p) => p.title.toLowerCase().includes(globalSearchTerm.toLowerCase())),
      }
    : null;

  return (
    <div className="min-h-screen bg-[#0E0E0E] text-[#F4F1EA] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col justify-between bg-[#121212] border-r border-white/5 p-5 shrink-0 fixed inset-y-0 left-0 z-30">
        <div className="space-y-6">
          {/* Logo / CMS Brand */}
          <div className="pb-4 border-b border-white/5 flex items-center justify-between">
            <button onClick={() => navigate('/admin')} className="text-left focus:outline-none">
              <ArtGharLogo variant="compact" size="sm" />
            </button>
            <span className="text-[10px] font-mono px-2 py-0.5 bg-[#E5A93C]/10 text-[#E5A93C] rounded border border-[#E5A93C]/20 uppercase">
              CMS
            </span>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const active = path === item.href;
              const Icon = item.icon;
              return (
                <button
                  key={item.href}
                  onClick={() => navigate(item.href)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded transition-colors ${
                    active
                      ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                      : 'text-[#A3A099] hover:text-[#F4F1EA] hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-[#E5A93C] text-black rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* User & Live Website Links */}
        <div className="pt-4 border-t border-white/5 space-y-3">
          <button
            onClick={() => navigate('/')}
            className="w-full flex items-center justify-between px-3 py-2 text-xs text-[#8E8B82] hover:text-[#E5A93C] transition-colors rounded hover:bg-white/5"
          >
            <span className="flex items-center gap-2">
              <ExternalLink className="w-3.5 h-3.5" />
              <span>View Public Site</span>
            </span>
          </button>

          <div className="p-3 bg-[#181818] rounded border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-[#E5A93C]/20 border border-[#E5A93C]/40 flex items-center justify-center text-xs font-bold text-[#E5A93C] shrink-0">
                {currentUser?.full_name?.charAt(0) || 'A'}
              </div>
              <div className="truncate">
                <span className="text-xs font-semibold block text-white truncate">
                  {currentUser?.full_name || 'Staff User'}
                </span>
                <span className="text-[10px] text-[#E5A93C] font-mono uppercase tracking-wider">
                  {currentUser?.role || 'editor'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                store.logout();
                navigate('/admin/login');
              }}
              title="Sign Out"
              className="text-[#71717A] hover:text-red-400 p-1.5 transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Pane */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="h-16 bg-[#121212] border-b border-white/5 px-6 sm:px-8 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 text-[#A3A099] hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-lg font-display font-bold uppercase tracking-wider text-[#F4F1EA]">
              {title}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {/* Global Search Button */}
            <button
              onClick={() => setGlobalSearchOpen(true)}
              className="px-3 py-1.5 text-xs text-[#A3A099] bg-[#181818] border border-white/10 rounded flex items-center gap-2 hover:border-[#E5A93C] transition-colors"
            >
              <Search className="w-3.5 h-3.5 text-[#E5A93C]" />
              <span className="hidden sm:inline">Search CMS (Cmd+K)...</span>
              <span className="sm:hidden">Search</span>
            </button>

            <button
              onClick={() => navigate('/')}
              className="hidden sm:inline-flex items-center gap-1.5 text-xs text-[#A3A099] hover:text-white"
            >
              <span>Public Site</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </header>

        {/* Content area */}
        <main className="flex-1 p-6 sm:p-8">{children}</main>
      </div>

      {/* Mobile Sidebar Drawer */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setMobileSidebarOpen(false)}
          />
          <div className="relative w-72 bg-[#121212] border-r border-white/10 p-6 flex flex-col justify-between z-10">
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <ArtGharLogo variant="compact" size="sm" />
                <button
                  onClick={() => setMobileSidebarOpen(false)}
                  className="p-1 text-[#71717A] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="space-y-1">
                {navItems.map((item) => (
                  <button
                    key={item.href}
                    onClick={() => {
                      navigate(item.href);
                      setMobileSidebarOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded ${
                      path === item.href ? 'bg-[#E5A93C] text-black font-semibold' : 'text-[#A3A099]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </div>
                  </button>
                ))}
              </nav>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-2">
              <button
                onClick={() => {
                  store.logout();
                  navigate('/admin/login');
                }}
                className="w-full py-2 text-xs text-red-400 font-mono flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Search Dialog Modal */}
      {globalSearchOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center p-4 sm:p-12 animate-in fade-in"
        >
          <div className="w-full max-w-2xl bg-[#141414] border border-white/10 rounded-xl overflow-hidden shadow-2xl space-y-4">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <Search className="w-4 h-4 text-[#E5A93C]" />
                <input
                  type="text"
                  autoFocus
                  value={globalSearchTerm}
                  onChange={(e) => setGlobalSearchTerm(e.target.value)}
                  placeholder="Search artists, releases, upcoming, productions, articles..."
                  className="w-full bg-transparent border-0 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none"
                />
              </div>
              <button
                onClick={() => {
                  setGlobalSearchOpen(false);
                  setGlobalSearchTerm('');
                }}
                className="p-1 text-[#71717A] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Results Grouped By Category */}
            <div className="p-4 max-h-[60vh] overflow-y-auto space-y-6 text-sm">
              {searchResults ? (
                <>
                  {searchResults.artists.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono uppercase text-[#E5A93C] block mb-2">
                        Artists
                      </span>
                      {searchResults.artists.map((a) => (
                        <div
                          key={a.id}
                          onClick={() => {
                            navigate('/admin/artists');
                            setGlobalSearchOpen(false);
                          }}
                          className="p-2 hover:bg-white/5 rounded cursor-pointer flex justify-between items-center"
                        >
                          <span className="font-semibold">{a.name}</span>
                          <span className="text-xs text-[#71717A]">{a.genre}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {searchResults.releases.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono uppercase text-[#E5A93C] block mb-2">
                        Releases
                      </span>
                      {searchResults.releases.map((r) => (
                        <div
                          key={r.id}
                          onClick={() => {
                            navigate('/admin/releases');
                            setGlobalSearchOpen(false);
                          }}
                          className="p-2 hover:bg-white/5 rounded cursor-pointer flex justify-between items-center"
                        >
                          <span className="font-semibold">{r.title}</span>
                          <span className="text-xs text-[#71717A]">{r.release_type}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {searchResults.productions.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono uppercase text-[#E5A93C] block mb-2">
                        Productions
                      </span>
                      {searchResults.productions.map((p) => (
                        <div
                          key={p.id}
                          onClick={() => {
                            navigate('/admin/productions');
                            setGlobalSearchOpen(false);
                          }}
                          className="p-2 hover:bg-white/5 rounded cursor-pointer flex justify-between items-center"
                        >
                          <span className="font-semibold">{p.title}</span>
                          <span className="text-xs text-[#71717A]">{p.category}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {searchResults.posts.length > 0 && (
                    <div>
                      <span className="text-[10px] font-mono uppercase text-[#E5A93C] block mb-2">
                        Journal Dispatches
                      </span>
                      {searchResults.posts.map((post) => (
                        <div
                          key={post.id}
                          onClick={() => {
                            navigate('/admin/journal');
                            setGlobalSearchOpen(false);
                          }}
                          className="p-2 hover:bg-white/5 rounded cursor-pointer flex justify-between items-center"
                        >
                          <span className="font-semibold">{post.title}</span>
                          <span className="text-xs text-[#71717A]">{post.category}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="py-8 text-center text-xs text-[#71717A] font-mono">
                  Type at least 2 characters to search across all Art Ghar records.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
