import React, { useEffect } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowLeft, Calendar, User, Share2 } from 'lucide-react';

interface JournalDetailPageProps {
  slug: string;
}

export const JournalDetailPage: React.FC<JournalDetailPageProps> = ({ slug }) => {
  const { navigate } = useRouter();
  const post = store.getBlogPostBySlug(slug);

  useEffect(() => {
    if (post) {
      document.title = `${post.seo_title || post.title} — Art Ghar`;
    }
    return () => {
      document.title = 'Art Ghar — Where Every Frame Tells a Tale';
    };
  }, [post]);

  if (!post) {
    return (
      <div className="pt-36 pb-24 text-center min-h-screen bg-[#0A0A0A]">
        <h1 className="text-2xl font-display text-white">Article not found</h1>
        <button
          onClick={() => navigate('/journal')}
          className="mt-4 text-xs font-mono uppercase text-[#E5A93C] underline"
        >
          Return to Journal
        </button>
      </div>
    );
  }

  const allPosts = store.getBlogPosts();
  const relatedPosts = allPosts.filter((p) => p.id !== post.id).slice(0, 2);

  return (
    <article className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-4xl mx-auto px-6 sm:px-8">
        <button
          onClick={() => navigate('/journal')}
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#A3A099] hover:text-[#E5A93C] transition-colors mb-10"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>All Dispatches</span>
        </button>

        {/* Article Header */}
        <header className="space-y-6 mb-12">
          <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
            <span>{post.category}</span>
            <span>·</span>
            <span>{new Date(post.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] leading-tight">
            {post.title}
          </h1>

          <p className="text-lg sm:text-xl text-[#C8C5BC] font-light leading-relaxed border-l-2 border-[#E5A93C] pl-4">
            {post.excerpt}
          </p>

          {post.author && (
            <div className="flex items-center gap-3 pt-2">
              {post.author.avatar_url && (
                <img
                  src={post.author.avatar_url}
                  alt={post.author.full_name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-white/10"
                />
              )}
              <div>
                <span className="text-xs uppercase font-mono text-[#71717A] block">Written By</span>
                <span className="text-sm font-semibold text-white">{post.author.full_name}</span>
              </div>
            </div>
          )}
        </header>

        {/* Feature Cover Image */}
        <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-black/80 border border-white/10 shadow-2xl mb-12">
          <img
            src={post.cover_image}
            alt={post.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Rich Body Content */}
        <div className="prose prose-invert max-w-none text-[#C8C5BC] font-light text-base sm:text-lg leading-relaxed space-y-6">
          {post.content.split('\n\n').map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </div>

        {/* Related Dispatches */}
        {relatedPosts.length > 0 && (
          <div className="mt-20 pt-12 border-t border-white/10">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C] mb-8">
              Related Dispatches
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {relatedPosts.map((r) => (
                <div
                  key={r.id}
                  onClick={() => navigate(`/journal/${r.slug}`)}
                  className="group cursor-pointer bg-[#121212] border border-white/5 rounded-lg p-5 space-y-3 hover:border-[#E5A93C]/40 transition-colors"
                >
                  <span className="text-[10px] font-mono text-[#E5A93C] uppercase">{r.category}</span>
                  <h4 className="text-base font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                    {r.title}
                  </h4>
                  <p className="text-xs text-[#8E8B82] line-clamp-2">{r.excerpt}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </article>
  );
};
