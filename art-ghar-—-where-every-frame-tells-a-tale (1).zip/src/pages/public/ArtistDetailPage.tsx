import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowLeft, Instagram, Youtube, Music2, Facebook, Globe, ArrowRight } from 'lucide-react';

interface ArtistDetailPageProps {
  slug: string;
}

export const ArtistDetailPage: React.FC<ArtistDetailPageProps> = ({ slug }) => {
  const { navigate } = useRouter();
  const artist = store.getArtistBySlug(slug);

  if (!artist) {
    return (
      <div className="pt-36 pb-24 text-center min-h-screen bg-[#0A0A0A]">
        <h1 className="text-2xl font-display text-white">Artist not found</h1>
        <button
          onClick={() => navigate('/artists')}
          className="mt-4 text-xs font-mono uppercase text-[#E5A93C] underline"
        >
          Return to Artists Directory
        </button>
      </div>
    );
  }

  const allReleases = store.getReleases();
  const artistReleases = allReleases.filter((r) => r.artist_id === artist.id);
  const artistUpcoming = store.getUpcomingProjects().filter((u) => u.artist_id === artist.id);

  return (
    <div className="min-h-screen bg-[#0A0A0A] pt-24 pb-24">
      {/* Artist Hero Header with Cover Image & Portrait */}
      <div className="relative min-h-[50vh] flex items-end pb-12 bg-black border-b border-white/5">
        <div className="absolute inset-0 z-0">
          <img
            src={artist.cover_image || artist.profile_image}
            alt={artist.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/70 to-[#0A0A0A]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 w-full">
          <button
            onClick={() => navigate('/artists')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#A3A099] hover:text-[#E5A93C] transition-colors mb-8"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>All Artists</span>
          </button>

          <div className="flex flex-col md:flex-row md:items-end gap-8">
            <div className="w-36 sm:w-44 aspect-square rounded-lg overflow-hidden border-2 border-[#E5A93C]/40 shadow-2xl shrink-0">
              <img
                src={artist.profile_image}
                alt={artist.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
                <span>{artist.genre}</span>
                <span>·</span>
                <span className="text-[#A3A099]">{artist.location}</span>
              </div>
              <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA]">
                {artist.name}
              </h1>
              <p className="text-sm sm:text-base text-[#C8C5BC] font-light max-w-2xl">
                {artist.short_bio}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content: Biography & Discography */}
      <div className="max-w-7xl mx-auto px-6 sm:px-8 pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Left Column: Extended Biography & Socials */}
          <div className="lg:col-span-7 space-y-8">
            <div>
              <h2 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C] mb-4">
                The Narrative
              </h2>
              <div className="prose prose-invert prose-p:text-[#A3A099] prose-p:leading-relaxed prose-p:font-light">
                {artist.biography.split('\n\n').map((para, i) => (
                  <p key={i} className="mb-4 text-base leading-relaxed text-[#C8C5BC] font-light">
                    {para}
                  </p>
                ))}
              </div>
            </div>

            {/* Social & Streaming Links */}
            <div className="pt-6 border-t border-white/10 space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#71717A]">
                Follow & Stream
              </h3>
              <div className="flex items-center gap-4 text-[#F4F1EA]">
                {artist.spotify_url && (
                  <a
                    href={artist.spotify_url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-full bg-white/5 border border-white/10 hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                    title="Spotify"
                  >
                    <Music2 className="w-5 h-5" />
                  </a>
                )}
                {artist.youtube_url && (
                  <a
                    href={artist.youtube_url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-full bg-white/5 border border-white/10 hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                    title="YouTube"
                  >
                    <Youtube className="w-5 h-5" />
                  </a>
                )}
                {artist.instagram_url && (
                  <a
                    href={artist.instagram_url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-full bg-white/5 border border-white/10 hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                    title="Instagram"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {artist.facebook_url && (
                  <a
                    href={artist.facebook_url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-full bg-white/5 border border-white/10 hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                    title="Facebook"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                {artist.website_url && (
                  <a
                    href={artist.website_url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-full bg-white/5 border border-white/10 hover:border-[#E5A93C] hover:text-[#E5A93C] transition-colors"
                    title="Official Website"
                  >
                    <Globe className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Releases & Forthcoming Works */}
          <div className="lg:col-span-5 space-y-12">
            {/* Releases */}
            <div>
              <h2 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C] mb-6">
                Releases & Works ({artistReleases.length})
              </h2>
              {artistReleases.length === 0 ? (
                <p className="text-sm text-[#71717A]">No published releases recorded.</p>
              ) : (
                <div className="space-y-4">
                  {artistReleases.map((rel) => (
                    <div
                      key={rel.id}
                      onClick={() => navigate(`/releases/${rel.slug}`)}
                      className="group cursor-pointer bg-[#121212] border border-white/5 rounded p-4 flex gap-4 hover:border-[#E5A93C]/40 transition-colors"
                    >
                      <img
                        src={rel.cover_image}
                        alt={rel.title}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded object-cover shrink-0"
                      />
                      <div className="flex-1 space-y-1">
                        <span className="text-[10px] font-mono uppercase text-[#E5A93C] block">
                          {rel.release_type} · {rel.release_date}
                        </span>
                        <h4 className="text-base font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                          {rel.title}
                        </h4>
                        <span className="text-xs text-[#71717A] flex items-center gap-1">
                          <span>View Credits</span>
                          <ArrowRight className="w-3 h-3 text-[#E5A93C]" />
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Upcoming Projects */}
            {artistUpcoming.length > 0 && (
              <div>
                <h2 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C] mb-6">
                  In Production
                </h2>
                <div className="space-y-4">
                  {artistUpcoming.map((up) => (
                    <div
                      key={up.id}
                      onClick={() => navigate(`/upcoming/${up.slug}`)}
                      className="group cursor-pointer bg-[#121212] border border-white/5 rounded p-4 flex gap-4 hover:border-[#E5A93C]/40 transition-colors"
                    >
                      <img
                        src={up.artwork}
                        alt={up.title}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded object-cover shrink-0"
                      />
                      <div className="flex-1 space-y-1">
                        <span className="text-[10px] font-mono uppercase text-[#E5A93C] block">
                          {up.status} · Expected {up.expected_release_date}
                        </span>
                        <h4 className="text-base font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                          {up.title}
                        </h4>
                        <p className="text-xs text-[#8E8B82] line-clamp-1">{up.announcement}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
