import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowLeft, Music2, Youtube, ExternalLink, Disc, Share2 } from 'lucide-react';

interface ReleaseDetailPageProps {
  slug: string;
}

export const ReleaseDetailPage: React.FC<ReleaseDetailPageProps> = ({ slug }) => {
  const { navigate } = useRouter();
  const release = store.getReleaseBySlug(slug);

  if (!release) {
    return (
      <div className="pt-36 pb-24 text-center min-h-screen bg-[#0A0A0A]">
        <h1 className="text-2xl font-display text-white">Release not found</h1>
        <button
          onClick={() => navigate('/releases')}
          className="mt-4 text-xs font-mono uppercase text-[#E5A93C] underline"
        >
          Return to Discography
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        <button
          onClick={() => navigate('/releases')}
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#A3A099] hover:text-[#E5A93C] transition-colors mb-12"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>All Releases</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Cover Artwork & Streaming Actions */}
          <div className="lg:col-span-5 space-y-6">
            <div className="relative aspect-square rounded-xl overflow-hidden bg-black/80 border border-white/10 shadow-2xl">
              <img
                src={release.cover_image}
                alt={release.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 p-2.5 rounded-full bg-black/70 backdrop-blur-md text-[#E5A93C] border border-white/10">
                <Disc className="w-5 h-5 animate-spin duration-[16000ms]" />
              </div>
            </div>

            {/* Streaming Links */}
            <div className="p-6 bg-[#121212] border border-white/5 rounded-xl space-y-4">
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C]">
                Available On Platforms
              </h3>
              <div className="space-y-2">
                {release.spotify_url && (
                  <a
                    href={release.spotify_url}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 px-4 bg-white/5 hover:bg-white/10 text-white rounded text-xs font-mono uppercase tracking-wider flex items-center justify-between transition-colors border border-white/5 hover:border-[#E5A93C]/40"
                  >
                    <span className="flex items-center gap-2">
                      <Music2 className="w-4 h-4 text-[#1DB954]" />
                      <span>Spotify</span>
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#71717A]" />
                  </a>
                )}
                {release.apple_music_url && (
                  <a
                    href={release.apple_music_url}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 px-4 bg-white/5 hover:bg-white/10 text-white rounded text-xs font-mono uppercase tracking-wider flex items-center justify-between transition-colors border border-white/5 hover:border-[#E5A93C]/40"
                  >
                    <span className="flex items-center gap-2">
                      <Music2 className="w-4 h-4 text-[#FA2D48]" />
                      <span>Apple Music</span>
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#71717A]" />
                  </a>
                )}
                {release.youtube_url && (
                  <a
                    href={release.youtube_url}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 px-4 bg-white/5 hover:bg-white/10 text-white rounded text-xs font-mono uppercase tracking-wider flex items-center justify-between transition-colors border border-white/5 hover:border-[#E5A93C]/40"
                  >
                    <span className="flex items-center gap-2">
                      <Youtube className="w-4 h-4 text-[#FF0000]" />
                      <span>YouTube Music</span>
                    </span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#71717A]" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Title, Artist, Narrative & Detailed Credits */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
                <span>{release.release_type}</span>
                <span>·</span>
                <span>{release.release_date}</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA] leading-tight">
                {release.title}
              </h1>

              {release.artist && (
                <div className="pt-1">
                  <span className="text-xs text-[#71717A] uppercase font-mono tracking-wider block">
                    Artist / Ensemble
                  </span>
                  <button
                    onClick={() => navigate(`/artists/${release.artist?.slug}`)}
                    className="text-lg font-display text-[#E5A93C] hover:underline"
                  >
                    {release.artist.name}
                  </button>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="space-y-4">
              <h2 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
                Album Note & Story
              </h2>
              <p className="text-base text-[#C8C5BC] font-light leading-relaxed">
                {release.description}
              </p>
            </div>

            {/* Credits Section */}
            {release.credits && (
              <div className="p-6 bg-[#121212] border border-white/5 rounded-xl space-y-3">
                <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C]">
                  Production Credits
                </h3>
                <div className="text-xs sm:text-sm text-[#8E8B82] font-mono leading-relaxed space-y-1">
                  {release.credits.split('·').map((cred, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-[#E5A93C]">•</span>
                      <span>{cred.trim()}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
