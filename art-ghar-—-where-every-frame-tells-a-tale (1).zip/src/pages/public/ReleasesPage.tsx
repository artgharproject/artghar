import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { Disc, Search } from 'lucide-react';

export const ReleasesPage: React.FC = () => {
  const { navigate } = useRouter();
  const allReleases = store.getReleases();
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const types = ['all', 'Single', 'EP', 'Album', 'Soundtrack', 'Original'];

  const filteredReleases = allReleases.filter((r) => {
    const matchesType = selectedType === 'all' || r.release_type === selectedType;
    const matchesQuery =
      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (r.artist?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesQuery;
  });

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Art Ghar Discography
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            RELEASES
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Original soundtracks, acoustic studio albums, and singles mastered with cinematic precision.
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-10 border-b border-white/10">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {types.map((t) => (
              <button
                key={t}
                onClick={() => setSelectedType(t)}
                className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                  selectedType === t
                    ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                    : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
                }`}
              >
                {t === 'all' ? 'All Releases' : t}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#71717A]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search release..."
              className="w-full bg-[#141414] border border-white/10 rounded pl-9 pr-4 py-1.5 text-xs text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
            />
          </div>
        </div>

        {/* Releases Grid */}
        {filteredReleases.length === 0 ? (
          <div className="py-20 text-center text-[#71717A] font-light">
            No releases match your selection.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredReleases.map((rel) => (
              <div
                key={rel.id}
                onClick={() => navigate(`/releases/${rel.slug}`)}
                className="group cursor-pointer bg-[#121212] border border-white/5 rounded-lg overflow-hidden flex flex-col justify-between hover:border-[#E5A93C]/40 transition-all duration-300"
              >
                <div className="relative aspect-square overflow-hidden bg-black/60">
                  <img
                    src={rel.cover_image}
                    alt={rel.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80" />

                  <div className="absolute top-3 right-3 p-2 rounded-full bg-black/70 backdrop-blur-md text-[#E5A93C] border border-white/10">
                    <Disc className="w-4 h-4" />
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <div className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                    <span className="text-[#E5A93C]">{rel.release_type}</span>
                    <span>{rel.release_date}</span>
                  </div>

                  <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors leading-snug">
                    {rel.title}
                  </h3>

                  {rel.artist && (
                    <p className="text-xs text-[#8E8B82] font-medium">{rel.artist.name}</p>
                  )}

                  <p className="text-xs sm:text-sm text-[#8E8B82] font-light line-clamp-2">
                    {rel.description}
                  </p>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs font-mono text-[#E5A93C]">
                    <span>Listen & Credits</span>
                    <span>→</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
