import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArtGharLogo } from '../../components/common/ArtGharLogo';
import { ArrowDown, Sparkles } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigate } = useRouter();
  const timelineItems = store.getTimeline();

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-6xl mx-auto px-6 sm:px-8 space-y-24">
        {/* Editorial Story Header */}
        <div className="space-y-6 max-w-4xl">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C] block">
            The Chronicle of The House
          </span>
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight leading-[1.05]">
            A HOUSE FOR<br />
            <span className="text-[#E5A93C]">ART + STORIES.</span>
          </h1>
          <p className="text-lg sm:text-xl text-[#C8C5BC] font-light leading-relaxed">
            Where every frame tells a tale. Art Ghar was established in the Kathmandu Valley to preserve the soul of organic storytelling in an age of automated noise.
          </p>
        </div>

        {/* Large Cinematic Atmosphere Image */}
        <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-black/80 border border-white/10 shadow-2xl">
          <img
            src="/src/assets/images/hero_cinematic_production_1790823187023.jpg"
            alt="Art Ghar Studio in Kathmandu"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70" />
        </div>

        {/* Three Pillar Philosophy */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 border-y border-white/10 py-16">
          <div className="space-y-3">
            <span className="text-xs font-mono text-[#E5A93C] uppercase tracking-wider">01 · Acoustic Reverence</span>
            <h3 className="text-xl font-display font-bold text-[#F4F1EA]">The Organic Instrument</h3>
            <p className="text-sm text-[#8E8B82] leading-relaxed font-light">
              We record indigenous Sarangis, Tungnas, bamboo Bansuris, and classical voices in live timber rooms. We refuse artificial compression that strips away the human breath.
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-xs font-mono text-[#E5A93C] uppercase tracking-wider">02 · Cinematic Discipline</span>
            <h3 className="text-xl font-display font-bold text-[#F4F1EA]">Every Frame Tells A Tale</h3>
            <p className="text-sm text-[#8E8B82] leading-relaxed font-light">
              We shoot on anamorphic lenses, natural mountain light, and real historical locations across Nepal. Every camera movement carries emotional purpose.
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-xs font-mono text-[#E5A93C] uppercase tracking-wider">03 · The Communal House</span>
            <h3 className="text-xl font-display font-bold text-[#F4F1EA]">Sanctuary for Creators</h3>
            <p className="text-sm text-[#8E8B82] leading-relaxed font-light">
              Art Ghar is not a transactional agency. It is a home where artists reside, compose over months, test ideas without commercial pressure, and hone masterworks.
            </p>
          </div>
        </div>

        {/* Interactive Visual Timeline */}
        <div className="space-y-12">
          <div className="text-center space-y-2">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
              Chronological Path
            </span>
            <h2 className="text-3xl sm:text-4xl font-display font-extrabold uppercase text-[#F4F1EA]">
              THE ART GHAR TIMELINE
            </h2>
            <p className="text-sm text-[#8E8B82] font-light max-w-md mx-auto">
              How a quiet idea in Patan grew into an internationally acclaimed creative house.
            </p>
          </div>

          {/* Timeline Nodes */}
          <div className="relative border-l border-[#E5A93C]/40 ml-4 sm:ml-32 space-y-12 pl-6 sm:pl-10">
            {timelineItems.map((item, idx) => (
              <div key={item.id} className="relative group">
                {/* Node Dot */}
                <div className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-3.5 h-3.5 rounded-full bg-[#E5A93C] border-4 border-[#0A0A0A] group-hover:scale-125 transition-transform" />

                {/* Content */}
                <div className="space-y-2">
                  <span className="inline-block px-2.5 py-0.5 text-xs font-mono font-bold bg-[#E5A93C]/10 text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                    {item.year}
                  </span>
                  <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#8E8B82] font-light leading-relaxed max-w-xl">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Closing CTA */}
        <div className="p-10 bg-[#121212] border border-white/10 rounded-2xl text-center space-y-4">
          <h3 className="text-2xl font-display font-bold text-[#F4F1EA]">
            Ready to shape an unforgettable story?
          </h3>
          <p className="text-sm text-[#8E8B82] font-light max-w-md mx-auto">
            Our doors in Jhamsikhel are always open to artists, filmmakers, composers, and storytellers.
          </p>
          <div className="pt-2">
            <button
              onClick={() => navigate('/contact')}
              className="px-8 py-3 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-colors"
            >
              Get In Touch
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
