import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowLeft, Calendar, User, Film } from 'lucide-react';

interface ProductionDetailPageProps {
  slug: string;
}

export const ProductionDetailPage: React.FC<ProductionDetailPageProps> = ({ slug }) => {
  const { navigate } = useRouter();
  const prod = store.getProductionBySlug(slug);

  if (!prod) {
    return (
      <div className="pt-36 pb-24 text-center min-h-screen bg-[#0A0A0A]">
        <h1 className="text-2xl font-display text-white">Production not found</h1>
        <button
          onClick={() => navigate('/productions')}
          className="mt-4 text-xs font-mono uppercase text-[#E5A93C] underline"
        >
          Return to Selected Productions
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] pt-24 pb-24">
      {/* Full-bleed Hero Visual */}
      <div className="relative min-h-[55vh] flex items-end pb-12 bg-black border-b border-white/5">
        <div className="absolute inset-0 z-0">
          <img
            src={prod.hero_image || prod.cover_image}
            alt={prod.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-45"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/60 to-[#0A0A0A]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 w-full">
          <button
            onClick={() => navigate('/productions')}
            className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#A3A099] hover:text-[#E5A93C] transition-colors mb-8"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>All Productions</span>
          </button>

          <div className="space-y-4 max-w-4xl">
            <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
              <span>{prod.category}</span>
              <span>·</span>
              <span className="text-[#A3A099]">{prod.production_date}</span>
            </div>

            <h1 className="text-3xl sm:text-5xl md:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] leading-tight">
              {prod.title}
            </h1>

            {prod.client_name && (
              <p className="text-sm font-mono text-[#C8C5BC]">
                Client / Commission:{' '}
                <span className="text-white font-semibold">{prod.client_name}</span>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Narrative & Case Study Content */}
      <div className="max-w-4xl mx-auto px-6 sm:px-8 pt-16 space-y-12">
        <div className="space-y-4">
          <h2 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
            Synopsis
          </h2>
          <p className="text-xl sm:text-2xl text-[#F4F1EA] font-light leading-relaxed">
            {prod.description}
          </p>
        </div>

        <div className="border-t border-white/10 pt-8 space-y-6">
          <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
            Behind The Frame & Process
          </h3>
          <div className="prose prose-invert max-w-none text-[#C8C5BC] font-light text-base leading-relaxed space-y-4">
            {prod.content.split('\n\n').map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>

        {/* Secondary image embed */}
        <div className="rounded-xl overflow-hidden border border-white/10 shadow-2xl">
          <img
            src={prod.cover_image}
            alt={prod.title}
            referrerPolicy="no-referrer"
            className="w-full h-auto object-cover"
          />
        </div>

        <div className="pt-8 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => navigate('/contact')}
            className="px-6 py-3 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors"
          >
            Commission Art Ghar for Your Film
          </button>
        </div>
      </div>
    </div>
  );
};
