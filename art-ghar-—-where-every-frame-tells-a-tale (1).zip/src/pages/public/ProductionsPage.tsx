import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ProductionCategory } from '../../types/database';
import { ArrowUpRight, Search } from 'lucide-react';

export const ProductionsPage: React.FC = () => {
  const { navigate } = useRouter();
  const allProductions = store.getProductions();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['all', 'Film', 'Music', 'Visual', 'Documentary', 'Commercial', 'Original'];

  const filteredProductions = allProductions.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesQuery =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.client_name || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Cinematic Portfolio
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            PRODUCTIONS
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Films, documentaries, music videos, and sensory commercials produced under the Art Ghar banner.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-10 border-b border-white/10">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCategory(c)}
                className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                  selectedCategory === c
                    ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                    : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
                }`}
              >
                {c === 'all' ? 'All Productions' : c}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#71717A]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search work..."
              className="w-full bg-[#141414] border border-white/10 rounded pl-9 pr-4 py-1.5 text-xs text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
            />
          </div>
        </div>

        {/* Productions Grid */}
        {filteredProductions.length === 0 ? (
          <div className="py-20 text-center text-[#71717A] font-light">
            No productions match your selection.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredProductions.map((prod) => (
              <div
                key={prod.id}
                onClick={() => navigate(`/productions/${prod.slug}`)}
                className="group cursor-pointer bg-[#121212] border border-white/5 rounded-lg overflow-hidden flex flex-col justify-between hover:border-[#E5A93C]/40 transition-all duration-300"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-black/60">
                  <img
                    src={prod.cover_image}
                    alt={prod.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80" />

                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider bg-black/70 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                      {prod.category}
                    </span>
                  </div>

                  <div className="absolute bottom-4 right-4 w-9 h-9 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#71717A] font-mono">
                    <span>{prod.client_name || 'Art Ghar Originals'}</span>
                    <span>{prod.production_date}</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                    {prod.title}
                  </h3>

                  <p className="text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-2">
                    {prod.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
