import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { extractYoutubeId, getYoutubeEmbedUrl, getYoutubeThumbnail } from '../../lib/youtube';
import { Play, X, Youtube } from 'lucide-react';

export const VideosPage: React.FC = () => {
  const { navigate } = useRouter();
  const videos = store.getVideos();
  const [activeVideo, setActiveVideo] = useState<{ url: string; title: string } | null>(null);

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-14 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Motion Picture Archive
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            VIDEO VAULT
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Music videos, acoustic chamber live takes, and behind-the-scenes cinema craft from Nepal.
          </p>
        </div>

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {videos.map((vid) => (
            <div
              key={vid.id}
              className="group bg-[#121212] border border-white/5 rounded-xl overflow-hidden flex flex-col justify-between hover:border-[#E5A93C]/40 transition-all duration-300"
            >
              <div
                onClick={() => setActiveVideo({ url: vid.youtube_url, title: vid.title })}
                className="relative aspect-[16/9] overflow-hidden bg-black/80 cursor-pointer"
              >
                <img
                  src={vid.thumbnail || getYoutubeThumbnail(vid.youtube_url)}
                  alt={vid.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors" />

                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center shadow-2xl group-hover:scale-110 active:scale-95 transition-all">
                    <Play className="w-6 h-6 fill-current ml-0.5" />
                  </div>
                </div>

                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider bg-black/80 text-[#E5A93C] rounded">
                    {vid.category}
                  </span>
                </div>
              </div>

              <div className="p-6 space-y-2">
                <span className="text-xs font-mono text-[#71717A]">{vid.release_date}</span>
                <h3
                  onClick={() => setActiveVideo({ url: vid.youtube_url, title: vid.title })}
                  className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors cursor-pointer"
                >
                  {vid.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-2">
                  {vid.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Video Player Modal */}
        {activeVideo && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in"
          >
            <div className="relative w-full max-w-4xl aspect-[16/9] bg-black rounded-lg overflow-hidden border border-white/20 shadow-2xl">
              <button
                onClick={() => setActiveVideo(null)}
                className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 text-white/80 hover:text-white border border-white/10"
                aria-label="Close Video"
              >
                <X className="w-5 h-5" />
              </button>
              <iframe
                src={getYoutubeEmbedUrl(activeVideo.url, true)}
                title={activeVideo.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
