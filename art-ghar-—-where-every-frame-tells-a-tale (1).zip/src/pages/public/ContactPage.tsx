import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Send, CheckCircle2, MapPin, Mail, Phone, Clock } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const settings = store.getSiteSettings();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    project_type: 'Music Production',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const projectTypes = [
    'Music Production',
    'Video Production',
    'Artist Collaboration',
    'Film',
    'Brand Collaboration',
    'Original Project',
    'Other',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setErrorMessage('Please fill out all required fields.');
      return;
    }

    setErrorMessage('');
    setIsSubmitting(true);

    try {
      store.submitContactMessage({
        name: formData.name,
        email: formData.email,
        organization: formData.organization,
        project_type: formData.project_type,
        message: formData.message,
      });

      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        organization: '',
        project_type: 'Music Production',
        message: '',
      });
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage('Submission error. Please email directly.');
    }
  };

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-6xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-16 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Direct Inquiries
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight leading-[1.05]">
            LET'S CREATE<br />
            <span className="text-[#E5A93C]">SOMETHING.</span>
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Whether you are an independent director seeking a film score, an artist looking for recording sanctuary, or a collaborator with a vision.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Form */}
          <div className="lg:col-span-7">
            {submitted ? (
              <div className="bg-[#121212] border border-[#E5A93C]/40 rounded-xl p-8 sm:p-12 text-center space-y-4 animate-in fade-in">
                <CheckCircle2 className="w-12 h-12 text-[#E5A93C] mx-auto" />
                <h3 className="text-2xl font-display font-bold text-[#F4F1EA]">
                  Inquiry Dispatched
                </h3>
                <p className="text-sm text-[#A3A099] max-w-md mx-auto font-light leading-relaxed">
                  Your message has been registered in the Art Ghar database. Our executive producer will get back to you promptly.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-6 py-2 text-xs font-mono uppercase tracking-wider text-[#E5A93C] border border-[#E5A93C]/30 rounded hover:bg-[#E5A93C]/10 transition-colors"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="bg-[#121212] border border-white/5 rounded-xl p-6 sm:p-8 space-y-6"
              >
                {errorMessage && (
                  <div className="p-3 bg-red-900/30 border border-red-500/40 rounded text-red-200 text-xs font-mono">
                    {errorMessage}
                  </div>
                )}

                <div className="space-y-2">
                  <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Suman Shakya"
                    className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@example.com"
                      className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                      Organization / Studio
                    </label>
                    <input
                      type="text"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      placeholder="e.g. Cinema Collective"
                      className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                    Project Classification *
                  </label>
                  <select
                    value={formData.project_type}
                    onChange={(e) => setFormData({ ...formData, project_type: e.target.value })}
                    className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] focus:outline-none focus:border-[#E5A93C]"
                  >
                    {projectTypes.map((pt) => (
                      <option key={pt} value={pt} className="bg-[#181818] text-white">
                        {pt}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
                    Narrative Brief *
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about the emotional intent, scope, and timeline of your project..."
                    className="w-full bg-[#181818] border border-white/10 rounded px-4 py-3 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C] resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-all inline-flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span>Sending...</span>
                  ) : (
                    <>
                      <span>Transmit Message</span>
                      <Send className="w-4 h-4 ml-1" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Studio Coordinates & Information */}
          <div className="lg:col-span-5 space-y-8 bg-[#121212] border border-white/5 rounded-xl p-6 sm:p-8">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Studio Coordinates
            </h3>

            <div className="space-y-6 text-sm text-[#C8C5BC]">
              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-[#E5A93C] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs uppercase font-mono text-[#71717A] block">Physical House</span>
                  <p className="font-light leading-relaxed">
                    {settings.location || 'Jhamsikhel, Lalitpur, Kathmandu Valley, Nepal'}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Mail className="w-5 h-5 text-[#E5A93C] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs uppercase font-mono text-[#71717A] block">Direct Electronic Mail</span>
                  <a
                    href={`mailto:${settings.contact_email || 'artgharproject@gmail.com'}`}
                    className="text-white hover:text-[#E5A93C] transition-colors"
                  >
                    {settings.contact_email || 'artgharproject@gmail.com'}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-[#E5A93C] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs uppercase font-mono text-[#71717A] block">Telephone</span>
                  <p className="font-light">{settings.phone || '+977 1 552 4981'}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="w-5 h-5 text-[#E5A93C] shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs uppercase font-mono text-[#71717A] block">Session Hours</span>
                  <p className="font-light text-xs text-[#8E8B82]">
                    {settings.hours || 'Monday – Saturday: 10:00 AM – 7:00 PM NPT'}
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/5">
              <span className="text-xs font-mono uppercase text-[#71717A] block mb-2">
                Visiting Note
              </span>
              <p className="text-xs text-[#8E8B82] font-light leading-relaxed">
                To preserve uninterrupted studio tracking sessions, visits to the acoustic chamber and color grading suite are strictly by prior appointment.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
