import React, { useState } from 'react';
import { store } from '../../lib/store';
import { MediaLightbox } from '../../components/common/MediaLightbox';
import { Maximize2 } from 'lucide-react';

export const GalleryPage: React.FC = () => {
  const allItems = store.getGallery();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);

  const categories = ['all', ...Array.from(new Set(allItems.map((i) => i.category)))];

  const filteredItems = allItems.filter(
    (item) => selectedCategory === 'all' || item.category === selectedCategory
  );

  const handleOpenLightbox = (index: number) => {
    setActivePhotoIndex(index);
    setLightboxOpen(true);
  };

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Visual Moments
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            THE ART GHAR WALL
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Raw 35mm film stills, recording booth intimacy, mountain riggings, and quiet artistic camaraderie.
          </p>
        </div>

        {/* Filter categories */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 border-b border-white/10 scrollbar-none">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCategory(c)}
              className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                selectedCategory === c
                  ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                  : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
              }`}
            >
              {c === 'all' ? 'All Wall Moments' : c}
            </button>
          ))}
        </div>

        {/* Asymmetric Visual Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => handleOpenLightbox(idx)}
              className="group relative aspect-[4/3] rounded-lg overflow-hidden bg-[#141414] border border-white/5 cursor-pointer hover:border-[#E5A93C]/40 transition-all duration-300"
            >
              <img
                src={item.image_url}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6">
                <div className="flex justify-end">
                  <span className="p-2 rounded-full bg-black/70 text-white/90">
                    <Maximize2 className="w-4 h-4" />
                  </span>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#E5A93C]">
                    {item.category}
                  </span>
                  <h3 className="text-base font-display font-bold text-white">
                    {item.title}
                  </h3>
                  {item.caption && (
                    <p className="text-xs text-[#C8C5BC] font-light line-clamp-2">
                      {item.caption}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <MediaLightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        items={filteredItems}
        currentIndex={activePhotoIndex}
        onNavigate={(newIdx) => setActivePhotoIndex(newIdx)}
      />
    </div>
  );
};
