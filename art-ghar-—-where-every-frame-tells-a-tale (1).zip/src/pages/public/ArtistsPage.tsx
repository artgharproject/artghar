import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { Artist, ArtistCollaborationStatus } from '../../types/database';
import { ArrowUpRight, Search } from 'lucide-react';

export const ArtistsPage: React.FC = () => {
  const { navigate } = useRouter();
  const allArtists = store.getArtists();
  const [selectedStatus, setSelectedStatus] = useState<'all' | ArtistCollaborationStatus>('all');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const genres = ['all', ...Array.from(new Set(allArtists.map((a) => a.genre)))];

  const filteredArtists = allArtists.filter((a) => {
    const matchesStatus = selectedStatus === 'all' || a.collaboration_status === selectedStatus;
    const matchesGenre = selectedGenre === 'all' || a.genre === selectedGenre;
    const matchesQuery =
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.short_bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesGenre && matchesQuery;
  });

  const getStatusBadge = (status: ArtistCollaborationStatus) => {
    switch (status) {
      case 'worked':
        return { label: 'Worked With Us', color: 'bg-amber-950/70 text-amber-300 border-amber-600/30' };
      case 'upcoming':
        return { label: 'Working Soon', color: 'bg-blue-950/70 text-blue-300 border-blue-600/30' };
      default:
        return { label: 'Current Roster', color: 'bg-black/70 text-[#E5A93C] border-[#E5A93C]/30' };
    }
  };

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Page Header */}
        <div className="max-w-3xl mb-12 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Art Ghar Roster & Collaborations
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            THE ARTISTS
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            The visionary composers, vocalists, poets, and acoustic masters who have recorded with us, are in our active roster, or are preparing forthcoming works.
          </p>
        </div>

        {/* Primary Status Tabs: All, Current Roster, Worked With, Working Soon */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 border-b border-white/10 scrollbar-none">
          <button
            onClick={() => setSelectedStatus('all')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded-lg transition-colors whitespace-nowrap ${
              selectedStatus === 'all'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-bold shadow-md'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            All Artists ({allArtists.length})
          </button>

          <button
            onClick={() => setSelectedStatus('current')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded-lg transition-colors whitespace-nowrap ${
              selectedStatus === 'current'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-bold shadow-md'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Current Roster ({allArtists.filter((a) => a.collaboration_status === 'current').length})
          </button>

          <button
            onClick={() => setSelectedStatus('worked')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded-lg transition-colors whitespace-nowrap ${
              selectedStatus === 'worked'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-bold shadow-md'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Worked With Art Ghar ({allArtists.filter((a) => a.collaboration_status === 'worked').length})
          </button>

          <button
            onClick={() => setSelectedStatus('upcoming')}
            className={`px-4 py-2 text-xs font-mono uppercase tracking-wider rounded-lg transition-colors whitespace-nowrap ${
              selectedStatus === 'upcoming'
                ? 'bg-[#E5A93C] text-[#0A0A0A] font-bold shadow-md'
                : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
            }`}
          >
            Working Soon ({allArtists.filter((a) => a.collaboration_status === 'upcoming').length})
          </button>
        </div>

        {/* Secondary Genre Filter + Search */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-10 border-b border-white/5">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {genres.map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={`px-3 py-1 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                  selectedGenre === g
                    ? 'border border-[#E5A93C] text-[#E5A93C] font-semibold bg-[#E5A93C]/10'
                    : 'text-[#71717A] hover:text-[#A3A099]'
                }`}
              >
                {g === 'all' ? 'All Genres' : g}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#71717A]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search artist name or bio..."
              className="w-full bg-[#141414] border border-white/10 rounded pl-9 pr-4 py-2 text-xs text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
            />
          </div>
        </div>

        {/* Artist Grid */}
        {filteredArtists.length === 0 ? (
          <div className="py-20 text-center text-[#71717A] font-light">
            No artists match your criteria.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredArtists.map((artist) => {
              const badge = getStatusBadge(artist.collaboration_status);
              return (
                <div
                  key={artist.id}
                  onClick={() => navigate(`/artists/${artist.slug}`)}
                  className="group cursor-pointer flex flex-col justify-between"
                >
                  <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-[#141414] border border-white/5 group-hover:border-[#E5A93C]/40 transition-all duration-500 shadow-xl">
                    <img
                      src={artist.profile_image}
                      alt={artist.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent opacity-85 group-hover:opacity-60 transition-opacity" />

                    {/* Collaboration Status Pill */}
                    <div className="absolute top-4 left-4">
                      <span
                        className={`px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider rounded backdrop-blur-md border ${badge.color}`}
                      >
                        {badge.label}
                      </span>
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between z-10">
                      <span className="text-[11px] font-mono text-[#E5A93C] uppercase tracking-wider bg-black/70 backdrop-blur-md px-2.5 py-1 rounded">
                        {artist.genre}
                      </span>
                      <div className="w-8 h-8 rounded-full bg-[#E5A93C] text-[#0A0A0A] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 space-y-1.5">
                    <div className="flex items-baseline justify-between">
                      <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors">
                        {artist.name}
                      </h3>
                      <span className="text-xs text-[#71717A] font-mono">
                        {artist.location}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-2">
                      {artist.short_bio}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
