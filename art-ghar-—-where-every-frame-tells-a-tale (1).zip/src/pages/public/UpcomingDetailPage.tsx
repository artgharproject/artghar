import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowLeft, Bell, Calendar, Play } from 'lucide-react';

interface UpcomingDetailPageProps {
  slug: string;
}

export const UpcomingDetailPage: React.FC<UpcomingDetailPageProps> = ({ slug }) => {
  const { navigate } = useRouter();
  const project = store.getUpcomingBySlug(slug);

  if (!project) {
    return (
      <div className="pt-36 pb-24 text-center min-h-screen bg-[#0A0A0A]">
        <h1 className="text-2xl font-display text-white">Project not found</h1>
        <button
          onClick={() => navigate('/upcoming')}
          className="mt-4 text-xs font-mono uppercase text-[#E5A93C] underline"
        >
          Return to Upcoming Calendar
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        <button
          onClick={() => navigate('/upcoming')}
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#A3A099] hover:text-[#E5A93C] transition-colors mb-10"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>All Upcoming Projects</span>
        </button>

        {/* Hero Artwork */}
        <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-black/80 border border-white/10 shadow-2xl mb-12">
          <img
            src={project.artwork}
            alt={project.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
          <div className="absolute top-6 left-6">
            <span className="px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/30 rounded">
              Status: {project.status}
            </span>
          </div>
        </div>

        {/* Project Overview */}
        <div className="space-y-8">
          <div className="space-y-3">
            <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-wider text-[#E5A93C]">
              <span>{project.project_type}</span>
              <span>·</span>
              <span className="flex items-center gap-1 text-[#A3A099]">
                <Calendar className="w-3.5 h-3.5" />
                Expected {project.expected_release_date}
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-display font-extrabold uppercase text-[#F4F1EA]">
              {project.title}
            </h1>

            {project.artist && (
              <p className="text-base text-[#C8C5BC]">
                Artist Partner:{' '}
                <button
                  onClick={() => navigate(`/artists/${project.artist?.slug}`)}
                  className="text-[#E5A93C] hover:underline"
                >
                  {project.artist.name}
                </button>
              </p>
            )}
          </div>

          <div className="prose prose-invert max-w-none">
            <p className="text-lg text-[#C8C5BC] font-light leading-relaxed">
              {project.description}
            </p>
          </div>

          {project.announcement && (
            <div className="p-6 bg-[#141414] border border-[#E5A93C]/20 rounded-xl space-y-2">
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C]">
                Official Production Statement
              </h3>
              <p className="text-sm text-[#A3A099] leading-relaxed font-light">
                {project.announcement}
              </p>
            </div>
          )}

          {project.pre_save_url && (
            <div className="pt-4 flex items-center gap-4">
              <a
                href={project.pre_save_url}
                target="_blank"
                rel="noreferrer"
                className="px-8 py-3.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-all inline-flex items-center gap-2"
              >
                <Bell className="w-4 h-4" />
                <span>Pre-Save Notice</span>
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
