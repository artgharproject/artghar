import React, { useState } from 'react';
import { store } from '../../lib/store';
import { HeroSection } from '../../components/public/HeroSection';
import { IntroSection } from '../../components/public/IntroSection';
import { PremiumVideoSlider } from '../../components/public/PremiumVideoSlider';
import { UpcomingSection } from '../../components/public/UpcomingSection';
import { LatestReleasesSection } from '../../components/public/LatestReleasesSection';
import { ArtistsSection } from '../../components/public/ArtistsSection';
import { TeamSection } from '../../components/public/TeamSection';
import { SelectedWorkSection } from '../../components/public/SelectedWorkSection';
import { ArtGharWallSection } from '../../components/public/ArtGharWallSection';
import { JournalSection } from '../../components/public/JournalSection';
import { AboutStorySection } from '../../components/public/AboutStorySection';
import { ContactSection } from '../../components/public/ContactSection';
import { extractYoutubeId, getYoutubeEmbedUrl } from '../../lib/youtube';
import { X } from 'lucide-react';

export const HomePage: React.FC = () => {
  const artists = store.getArtists();
  const teamMembers = store.getTeamMembers();
  const releases = store.getReleases();
  const upcoming = store.getUpcomingProjects();
  const productions = store.getProductions();
  const videos = store.getVideos();
  const gallery = store.getGallery();
  const blogPosts = store.getBlogPosts();

  const [activeTrailer, setActiveTrailer] = useState<{ url: string; title: string } | null>(null);

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* 1. Fullscreen Cinematic Hero */}
      <HeroSection
        onWatchReel={() => {
          if (videos[0]) {
            setActiveTrailer({ url: videos[0].youtube_url, title: videos[0].title });
          }
        }}
      />

      {/* 2. Editorial Introduction */}
      <IntroSection />

      {/* 3. Premium Video Slide Bars with Released Videos */}
      <PremiumVideoSlider videos={videos} />

      {/* 4. Core Feature: Upcoming Projects */}
      <UpcomingSection
        projects={upcoming}
        onOpenTrailer={(url, title) => setActiveTrailer({ url, title })}
      />

      {/* 5. Latest Music Releases */}
      <LatestReleasesSection releases={releases} />

      {/* 6. The Artists Showcase (Featured / Worked With / Working Soon) */}
      <ArtistsSection artists={artists} />

      {/* 7. The Creative Team (Animated Portraits, Address, Contacts) */}
      <TeamSection members={teamMembers} />

      {/* 8. Selected Productions (Film, Music, Visual) */}
      <SelectedWorkSection productions={productions} />

      {/* 9. The Art Ghar Wall (Masonry Gallery) */}
      <ArtGharWallSection items={gallery} />

      {/* 10. Editorial Journal */}
      <JournalSection posts={blogPosts} />

      {/* 11. About House Story */}
      <AboutStorySection />

      {/* 12. Minimal Working Contact Form */}
      <ContactSection />

      {/* Global Modal Video Player for Trailers and Screenings */}
      {activeTrailer && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in"
        >
          <div className="relative w-full max-w-4xl aspect-[16/9] bg-black rounded-lg overflow-hidden border border-white/20 shadow-2xl">
            <button
              onClick={() => setActiveTrailer(null)}
              className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 text-white/80 hover:text-white border border-white/10"
              aria-label="Close Preview"
            >
              <X className="w-5 h-5" />
            </button>
            <iframe
              src={getYoutubeEmbedUrl(activeTrailer.url, true)}
              title={activeTrailer.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          </div>
        </div>
      )}
    </div>
  );
};
