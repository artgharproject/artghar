import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArrowRight, Search, Calendar, User } from 'lucide-react';

export const JournalPage: React.FC = () => {
  const { navigate } = useRouter();
  const allPosts = store.getBlogPosts();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = ['all', ...Array.from(new Set(allPosts.map((p) => p.category)))];

  const filteredPosts = allPosts.filter((post) => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredPost = filteredPosts.find((p) => p.featured) || filteredPosts[0];
  const gridPosts = filteredPosts.filter((p) => p.id !== featuredPost?.id);

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-12 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Art Ghar Editorial
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            THE JOURNAL
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Essays on cinematography, acoustic preservation, film direction, and the creative spirit of Nepal.
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-12 border-b border-white/10">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setSelectedCategory(c)}
                className={`px-3.5 py-1.5 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                  selectedCategory === c
                    ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                    : 'text-[#A3A099] hover:text-[#F4F1EA] bg-white/5'
                }`}
              >
                {c === 'all' ? 'All Dispatches' : c}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#71717A]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search essays..."
              className="w-full bg-[#141414] border border-white/10 rounded pl-9 pr-4 py-1.5 text-xs text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
            />
          </div>
        </div>

        {/* Featured Editorial Post */}
        {featuredPost && (
          <div
            onClick={() => navigate(`/journal/${featuredPost.slug}`)}
            className="group cursor-pointer bg-[#121212] border border-white/5 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 mb-16 hover:border-[#E5A93C]/40 transition-all duration-300"
          >
            <div className="lg:col-span-7 relative aspect-[16/10] rounded-lg overflow-hidden bg-black/60">
              <img
                src={featuredPost.cover_image}
                alt={featuredPost.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>

            <div className="lg:col-span-5 space-y-4">
              <div className="flex items-center gap-3 text-xs text-[#A3A099]">
                <span className="text-[#E5A93C] font-mono uppercase tracking-wider">
                  {featuredPost.category}
                </span>
                <span>·</span>
                <span>{new Date(featuredPost.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors leading-snug">
                {featuredPost.title}
              </h2>

              <p className="text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-3">
                {featuredPost.excerpt}
              </p>

              <div className="pt-2">
                <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#E5A93C] group-hover:text-[#F3C065]">
                  <span>Read Dispatch</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Secondary Article Grid */}
        {gridPosts.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {gridPosts.map((post) => (
              <article
                key={post.id}
                onClick={() => navigate(`/journal/${post.slug}`)}
                className="group cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="relative aspect-[16/10] overflow-hidden rounded-lg bg-[#141414] border border-white/5 group-hover:border-[#E5A93C]/40 transition-colors">
                    <img
                      src={post.cover_image}
                      alt={post.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>

                  <div className="flex items-center gap-2 text-xs text-[#A3A099]">
                    <span className="text-[#E5A93C] font-mono uppercase tracking-wider">{post.category}</span>
                    <span>·</span>
                    <span>{new Date(post.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                  </div>

                  <h3 className="text-xl font-display font-bold text-[#F4F1EA] group-hover:text-[#E5A93C] transition-colors leading-snug">
                    {post.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-white/5">
                  <span className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#E5A93C] group-hover:text-[#F3C065]">
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
