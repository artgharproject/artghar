import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { Bell, ArrowRight, Play, X } from 'lucide-react';

export const UpcomingPage: React.FC = () => {
  const { navigate } = useRouter();
  const upcoming = store.getUpcomingProjects();
  const [activeTrailer, setActiveTrailer] = useState<{ url: string; title: string } | null>(null);

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-14 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            Forward Production Calendar
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            UPCOMING WORKS
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            Audio-visual odysseys, feature motion pictures, and studio vinyl editions currently inside the Art Ghar pipeline.
          </p>
        </div>

        {/* Projects List */}
        {upcoming.length === 0 ? (
          <div className="py-20 text-center text-[#71717A] font-light">
            No upcoming projects announced yet.
          </div>
        ) : (
          <div className="space-y-12">
            {upcoming.map((project, idx) => (
              <div
                key={project.id}
                className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-8 hover:border-[#E5A93C]/40 transition-all duration-300"
              >
                <div className="lg:col-span-5 relative aspect-[16/10] rounded-lg overflow-hidden bg-black/60">
                  <img
                    src={project.artwork}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                      {project.status}
                    </span>
                  </div>

                  {project.trailer_url && (
                    <button
                      onClick={() => setActiveTrailer({ url: project.trailer_url!, title: project.title })}
                      className="absolute bottom-3 right-3 p-3 rounded-full bg-[#E5A93C] text-[#0A0A0A] hover:bg-[#F3C065] transition-transform active:scale-95 shadow-xl"
                      title="Play Teaser"
                    >
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </button>
                  )}
                </div>

                <div className="lg:col-span-7 space-y-4">
                  <div className="flex items-center gap-3 text-xs text-[#A3A099]">
                    <span className="text-[#E5A93C] font-mono uppercase tracking-wider">
                      {project.project_type}
                    </span>
                    <span>·</span>
                    <span>Expected {project.expected_release_date}</span>
                  </div>

                  <h2
                    onClick={() => navigate(`/upcoming/${project.slug}`)}
                    className="text-2xl sm:text-3xl font-display font-bold text-[#F4F1EA] hover:text-[#E5A93C] transition-colors cursor-pointer"
                  >
                    {project.title}
                  </h2>

                  {project.artist && (
                    <p className="text-sm text-[#C8C5BC]">
                      In collaboration with{' '}
                      <button
                        onClick={() => navigate(`/artists/${project.artist?.slug}`)}
                        className="text-[#E5A93C] hover:underline"
                      >
                        {project.artist.name}
                      </button>
                    </p>
                  )}

                  <p className="text-sm text-[#8E8B82] font-light leading-relaxed">
                    {project.description}
                  </p>

                  {project.announcement && (
                    <div className="p-3.5 bg-black/40 border border-white/5 rounded text-xs text-[#C8C5BC] font-mono">
                      <span className="text-[#E5A93C] uppercase block mb-1">Production Bulletin:</span>
                      {project.announcement}
                    </div>
                  )}

                  <div className="pt-2 flex items-center gap-4">
                    <button
                      onClick={() => navigate(`/upcoming/${project.slug}`)}
                      className="px-5 py-2.5 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-1.5"
                    >
                      <span>Full Case File</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    {project.pre_save_url && (
                      <a
                        href={project.pre_save_url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2.5 border border-white/10 hover:border-[#E5A93C] text-xs font-mono uppercase tracking-wider text-[#A3A099] hover:text-white rounded transition-colors inline-flex items-center gap-1.5"
                      >
                        <Bell className="w-3.5 h-3.5 text-[#E5A93C]" />
                        <span>Pre-Save Notice</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal for Teaser Player */}
        {activeTrailer && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in"
          >
            <div className="relative w-full max-w-4xl aspect-[16/9] bg-black rounded-lg overflow-hidden border border-white/20 shadow-2xl">
              <button
                onClick={() => setActiveTrailer(null)}
                className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 text-white/80 hover:text-white border border-white/10"
                aria-label="Close Preview"
              >
                <X className="w-5 h-5" />
              </button>
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${
                  activeTrailer.url.includes('v=')
                    ? activeTrailer.url.split('v=')[1]?.split('&')[0]
                    : 'dQw4w9WgXcQ'
                }?autoplay=1`}
                title={activeTrailer.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
