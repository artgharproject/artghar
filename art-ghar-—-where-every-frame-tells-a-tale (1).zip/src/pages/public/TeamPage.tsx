import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { TeamMember } from '../../types/database';
import { Mail, Phone, MapPin, ArrowLeft, Instagram, Linkedin, X } from 'lucide-react';

export const TeamPage: React.FC = () => {
  const { navigate } = useRouter();
  const teamMembers = store.getTeamMembers();
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  return (
    <div className="pt-32 pb-24 min-h-screen bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-16 space-y-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-[#E5A93C]">
            The Creative Collective
          </span>
          <h1 className="text-4xl sm:text-6xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-tight">
            OUR TEAM
          </h1>
          <p className="text-base sm:text-lg text-[#8E8B82] font-light leading-relaxed">
            The producers, visual storytellers, audio engineers, and art directors who bring each frame to life.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              onClick={() => setSelectedMember(member)}
              className="group cursor-pointer bg-[#121212] border border-white/5 rounded-2xl overflow-hidden flex flex-col justify-between hover:border-[#E5A93C]/40 transition-all duration-300 shadow-xl"
            >
              {/* Animated Image Container */}
              <div className="relative aspect-[4/3] overflow-hidden bg-black/80">
                <img
                  src={member.image}
                  alt={member.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover grayscale contrast-105 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-85 group-hover:opacity-50 transition-opacity" />

                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#E5A93C] border border-[#E5A93C]/20 rounded">
                    Art Ghar Ensemble
                  </span>
                </div>
              </div>

              {/* Profile Details */}
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h3 className="text-xl font-display font-bold text-white group-hover:text-[#E5A93C] transition-colors">
                    {member.name}
                  </h3>
                  <span className="text-xs text-[#E5A93C] font-mono block font-medium">
                    {member.role}
                  </span>
                  <p className="text-xs sm:text-sm text-[#8E8B82] font-light leading-relaxed line-clamp-3 pt-1">
                    {member.bio}
                  </p>
                </div>

                {/* Address & Contact Information */}
                <div className="pt-4 border-t border-white/5 space-y-2 text-xs text-[#C8C5BC] font-mono">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                    <span className="truncate">{member.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                    <span className="truncate text-white">{member.email}</span>
                  </div>
                  {member.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                      <span>{member.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact Strip */}
        <div className="mt-20 p-8 sm:p-10 bg-[#121212] border border-white/10 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="text-xl font-display font-bold text-white">Join Our Creative House</h3>
            <p className="text-xs sm:text-sm text-[#8E8B82] font-light">
              We are constantly seeking cinematographers, sound mixers, and folk instrument researchers in Nepal.
            </p>
          </div>
          <button
            onClick={() => navigate('/contact')}
            className="px-6 py-3 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors self-start sm:self-auto shrink-0"
          >
            Reach Out
          </button>
        </div>
      </div>

      {/* Modal Profile Dialog */}
      {selectedMember && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-lg p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="space-y-0.5">
                <span className="text-[10px] font-mono uppercase text-[#E5A93C]">
                  Team Profile
                </span>
                <h3 className="text-2xl font-display font-bold text-white">
                  {selectedMember.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedMember(null)}
                className="p-1 text-[#71717A] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-4">
              <img
                src={selectedMember.image}
                alt={selectedMember.name}
                referrerPolicy="no-referrer"
                className="w-20 h-20 rounded-xl object-cover border border-[#E5A93C]/40 shrink-0"
              />
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase text-[#E5A93C] font-semibold">
                  {selectedMember.role}
                </span>
                <p className="text-xs text-[#8E8B82] flex items-center gap-1.5 font-mono">
                  <MapPin className="w-3 h-3 text-[#E5A93C]" />
                  <span>{selectedMember.address}</span>
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-mono uppercase text-[#71717A] block">
                Artistic Statement & Responsibilities
              </span>
              <p className="text-sm text-[#C8C5BC] font-light leading-relaxed">
                {selectedMember.bio}
              </p>
            </div>

            <div className="p-4 bg-[#181818] rounded-xl border border-white/5 space-y-2 text-xs font-mono">
              <span className="text-[#E5A93C] uppercase block mb-1">Direct Contact Coordinates</span>
              <div className="flex items-center justify-between">
                <span className="text-[#71717A]">Email:</span>
                <a href={`mailto:${selectedMember.email}`} className="text-white hover:underline">
                  {selectedMember.email}
                </a>
              </div>
              {selectedMember.phone && (
                <div className="flex items-center justify-between">
                  <span className="text-[#71717A]">Telephone:</span>
                  <span className="text-white">{selectedMember.phone}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
