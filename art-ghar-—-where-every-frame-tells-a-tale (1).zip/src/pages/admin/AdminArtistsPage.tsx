import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Artist } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Check, Star, ExternalLink, X } from 'lucide-react';

export const AdminArtistsPage: React.FC = () => {
  const artists = store.getArtists(true);
  const [editingArtist, setEditingArtist] = useState<Partial<Artist> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingArtist({
      name: '',
      slug: '',
      short_bio: '',
      biography: '',
      genre: 'Contemporary Folk',
      location: 'Kathmandu, Nepal',
      featured: false,
      published: true,
      profile_image: '/src/assets/images/featured_artist_portrait_1790823200594.jpg',
      cover_image: '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      sort_order: artists.length + 1,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (artist: Artist) => {
    setEditingArtist({ ...artist });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArtist?.name) return;

    store.saveArtist(editingArtist as any);
    setIsModalOpen(false);
    setEditingArtist(null);
  };

  const handleDelete = (id: string) => {
    store.deleteArtist(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (artist: Artist) => {
    store.saveArtist({ ...artist, published: !artist.published });
  };

  const toggleFeatured = (artist: Artist) => {
    store.saveArtist({ ...artist, featured: !artist.featured });
  };

  return (
    <AdminLayout title="Artists Roster Management">
      <div className="space-y-6">
        {/* Header Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-mono text-[#8E8B82]">
              Manage musician profiles, vocalists, composers, biographies, and imagery.
            </p>
          </div>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Add Artist</span>
          </button>
        </div>

        {/* Artists Table */}
        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Artist</th>
                  <th className="py-3.5 px-4">Genre</th>
                  <th className="py-3.5 px-4">Location</th>
                  <th className="py-3.5 px-4 text-center">Collaboration</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {artists.map((artist) => (
                  <tr key={artist.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={artist.profile_image}
                        alt={artist.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-md object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{artist.name}</span>
                        <span className="text-xs text-[#71717A] font-mono">/artists/{artist.slug}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">{artist.genre}</td>
                    <td className="py-3.5 px-4 text-xs text-[#8E8B82]">{artist.location}</td>

                    <td className="py-3.5 px-4 text-center">
                      <span className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                        artist.collaboration_status === 'worked'
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-600/30'
                          : artist.collaboration_status === 'upcoming'
                          ? 'bg-blue-950/60 text-blue-300 border border-blue-600/30'
                          : 'bg-zinc-800 text-[#E5A93C] border border-[#E5A93C]/20'
                      }`}>
                        {artist.collaboration_status === 'worked'
                          ? 'Worked With'
                          : artist.collaboration_status === 'upcoming'
                          ? 'Working Soon'
                          : 'Current Roster'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(artist)}
                        title="Toggle Featured"
                        className={`p-1 rounded transition-colors ${
                          artist.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'
                        }`}
                      >
                        <Star className={`w-4 h-4 ${artist.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(artist)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          artist.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {artist.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(artist)}
                        className="p-1.5 text-[#A3A099] hover:text-white transition-colors"
                        title="Edit Artist"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(artist.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400 transition-colors"
                        title="Delete Artist"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Editor */}
        {isModalOpen && editingArtist && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingArtist.id ? 'Edit Artist Profile' : 'Add New Artist'}
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-[#71717A] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Name *</label>
                    <input
                      type="text"
                      required
                      value={editingArtist.name || ''}
                      onChange={(e) => setEditingArtist({ ...editingArtist, name: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Genre *</label>
                    <input
                      type="text"
                      required
                      value={editingArtist.genre || ''}
                      onChange={(e) => setEditingArtist({ ...editingArtist, genre: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Location</label>
                  <input
                    type="text"
                    value={editingArtist.location || ''}
                    onChange={(e) => setEditingArtist({ ...editingArtist, location: e.target.value })}
                    placeholder="Kathmandu, Nepal"
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Short Bio</label>
                  <textarea
                    rows={2}
                    value={editingArtist.short_bio || ''}
                    onChange={(e) => setEditingArtist({ ...editingArtist, short_bio: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Complete Biography</label>
                  <textarea
                    rows={5}
                    value={editingArtist.biography || ''}
                    onChange={(e) => setEditingArtist({ ...editingArtist, biography: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <ImageUploadField
                    label="Profile Portrait"
                    value={editingArtist.profile_image || ''}
                    onChange={(val) => setEditingArtist({ ...editingArtist, profile_image: val })}
                    aspectRatio="portrait"
                    required
                    helperText="Upload artist headshot from your computer."
                  />

                  <ImageUploadField
                    label="Cinematic Cover Poster"
                    value={editingArtist.cover_image || ''}
                    onChange={(val) => setEditingArtist({ ...editingArtist, cover_image: val })}
                    aspectRatio="video"
                    helperText="Upload widescreen backdrop or studio poster."
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Collaboration Status *</label>
                  <select
                    value={editingArtist.collaboration_status || 'current'}
                    onChange={(e) => setEditingArtist({ ...editingArtist, collaboration_status: e.target.value as any })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  >
                    <option value="current">Current Roster (Active Art Ghar Artist)</option>
                    <option value="worked">Worked With Us (Previous Collaboration / Featured Guest)</option>
                    <option value="upcoming">Working Soon (Forthcoming Project / Upcoming Talent)</option>
                  </select>
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingArtist.published ?? true}
                      onChange={(e) => setEditingArtist({ ...editingArtist, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published On Website</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingArtist.featured ?? false}
                      onChange={(e) => setEditingArtist({ ...editingArtist, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Feature on Homepage</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Artist
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation Alert */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this artist? Associated releases will remain in the database.
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
