import React, { useState } from 'react';
import { store } from '../../lib/store';
import { BlogPost } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Star, Eye, X, BookOpen, Quote, Heading, List } from 'lucide-react';

export const AdminJournalPage: React.FC = () => {
  const posts = store.getBlogPosts(true);
  const profiles = store.getProfiles();
  const [editingPost, setEditingPost] = useState<Partial<BlogPost> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingPost({
      title: '',
      slug: '',
      category: 'Sound Architecture',
      excerpt: '',
      content: '',
      cover_image: '/src/assets/images/art_ghar_studio_session_1790823237699.jpg',
      author_id: profiles[0]?.id || 'prof-1',
      published: true,
      featured: false,
      seo_title: '',
      seo_description: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (post: BlogPost) => {
    setEditingPost({ ...post });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPost?.title) return;

    store.saveBlogPost(editingPost as any);
    setIsModalOpen(false);
    setEditingPost(null);
  };

  const handleDelete = (id: string) => {
    store.deleteBlogPost(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (post: BlogPost) => {
    store.saveBlogPost({ ...post, published: !post.published });
  };

  const toggleFeatured = (post: BlogPost) => {
    store.saveBlogPost({ ...post, featured: !post.featured });
  };

  // Quick insertion helpers for editor
  const insertFormatting = (syntax: string) => {
    if (!editingPost) return;
    const current = editingPost.content || '';
    setEditingPost({
      ...editingPost,
      content: current ? `${current}\n\n${syntax}` : syntax,
    });
  };

  return (
    <AdminLayout title="Journal CMS & Essays">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Author editorial essays, production diaries, and sound architecture manifestos.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>New Dispatch</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Article Title</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Author</th>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {posts.map((post) => (
                  <tr key={post.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={post.cover_image}
                        alt={post.title}
                        referrerPolicy="no-referrer"
                        className="w-12 h-8 rounded object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{post.title}</span>
                        <span className="text-xs text-[#71717A] font-mono">/journal/{post.slug}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs font-mono text-[#E5A93C]">{post.category}</td>
                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">{post.author?.full_name || 'Staff'}</td>
                    <td className="py-3.5 px-4 text-xs text-[#8E8B82]">
                      {new Date(post.created_at).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(post)}
                        className={`p-1 rounded ${post.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'}`}
                      >
                        <Star className={`w-4 h-4 ${post.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(post)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          post.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {post.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(post)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                        title="Edit Article"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(post.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400"
                        title="Delete Article"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Editor */}
        {isModalOpen && editingPost && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingPost.id ? 'Edit Journal Entry' : 'Compose New Journal Dispatch'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Article Title *</label>
                    <input
                      type="text"
                      required
                      value={editingPost.title || ''}
                      onChange={(e) => setEditingPost({ ...editingPost, title: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Category</label>
                    <input
                      type="text"
                      value={editingPost.category || ''}
                      onChange={(e) => setEditingPost({ ...editingPost, category: e.target.value })}
                      placeholder="e.g. Sound Architecture"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <ImageUploadField
                    label="Article Cover Poster / Visual (Upload from Computer)"
                    value={editingPost.cover_image || ''}
                    onChange={(val) => setEditingPost({ ...editingPost, cover_image: val })}
                    aspectRatio="video"
                    required
                    helperText="Upload editorial photography or journal cover art directly from your computer."
                  />

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Article Author</label>
                    <select
                      value={editingPost.author_id || ''}
                      onChange={(e) => setEditingPost({ ...editingPost, author_id: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {profiles.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.full_name} ({p.role})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Excerpt / Abstract *</label>
                  <textarea
                    rows={2}
                    required
                    value={editingPost.excerpt || ''}
                    onChange={(e) => setEditingPost({ ...editingPost, excerpt: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                {/* Content Toolbar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Article Body Content</label>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => insertFormatting('### New Section Header')}
                        className="px-2 py-0.5 text-[10px] bg-white/5 hover:bg-white/10 text-white rounded font-mono"
                      >
                        + Heading
                      </button>
                      <button
                        type="button"
                        onClick={() => insertFormatting('> "A notable quote on cinema and sound architecture."')}
                        className="px-2 py-0.5 text-[10px] bg-white/5 hover:bg-white/10 text-white rounded font-mono"
                      >
                        + Quote
                      </button>
                    </div>
                  </div>
                  <textarea
                    rows={8}
                    required
                    value={editingPost.content || ''}
                    onChange={(e) => setEditingPost({ ...editingPost, content: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C] font-mono text-xs leading-relaxed"
                  />
                </div>

                {/* SEO Metadata Fields */}
                <div className="p-4 bg-black/40 border border-white/5 rounded-lg space-y-3">
                  <span className="text-[11px] font-mono text-[#E5A93C] uppercase tracking-wider block">
                    Search Engine Optimization (SEO Metadata)
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <input
                      type="text"
                      value={editingPost.seo_title || ''}
                      onChange={(e) => setEditingPost({ ...editingPost, seo_title: e.target.value })}
                      placeholder="Custom SEO Title"
                      className="w-full bg-[#141414] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                    />
                    <input
                      type="text"
                      value={editingPost.seo_description || ''}
                      onChange={(e) => setEditingPost({ ...editingPost, seo_description: e.target.value })}
                      placeholder="Custom Meta Description"
                      className="w-full bg-[#141414] border border-white/10 rounded px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingPost.published ?? true}
                      onChange={(e) => setEditingPost({ ...editingPost, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Publish Immediately</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingPost.featured ?? false}
                      onChange={(e) => setEditingPost({ ...editingPost, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Feature on Homepage Journal</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Dispatch
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this journal article?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button onClick={() => setDeleteConfirmId(null)} className="px-4 py-1.5 text-xs text-[#A3A099]">
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
