import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Profile, UserRole } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Plus, Shield, User, Trash2, Edit2, X } from 'lucide-react';

export const AdminUsersPage: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const profiles = store.getProfiles();
  const [editingProfile, setEditingProfile] = useState<Partial<Profile> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (currentUser?.role !== 'admin') {
    return (
      <AdminLayout title="Access Restricted">
        <div className="p-8 text-center bg-[#121212] border border-white/5 rounded-xl space-y-2">
          <Shield className="w-8 h-8 text-[#E5A93C] mx-auto" />
          <h2 className="text-lg font-display text-white">Administrator Clearance Required</h2>
          <p className="text-xs text-[#8E8B82]">
            Only accounts with 'admin' privilege can view or configure studio profile roles.
          </p>
        </div>
      </AdminLayout>
    );
  }

  const handleOpenCreate = () => {
    setErrorMessage('');
    setEditingProfile({
      full_name: '',
      email: '',
      role: 'editor',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Profile) => {
    setErrorMessage('');
    setEditingProfile({ ...p });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProfile?.full_name || !editingProfile?.email) return;

    try {
      store.saveProfile(editingProfile as any);
      setIsModalOpen(false);
      setEditingProfile(null);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error saving user profile');
    }
  };

  const handleDelete = (id: string) => {
    try {
      store.deleteProfile(id);
    } catch (err: any) {
      alert(err.message || 'Cannot delete profile');
    }
  };

  return (
    <AdminLayout title="User Accounts & Roles">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Manage staff credentials, administrator privileges, and editorial roles.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Add Staff Account</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">User</th>
                  <th className="py-3.5 px-4">Email</th>
                  <th className="py-3.5 px-4">Access Role</th>
                  <th className="py-3.5 px-4">Created Date</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {profiles.map((p) => (
                  <tr key={p.id} className="hover:bg-white/[0.02]">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold text-xs text-[#E5A93C]">
                        {p.full_name?.charAt(0) || 'U'}
                      </div>
                      <span className="font-semibold text-white">{p.full_name}</span>
                    </td>

                    <td className="py-3.5 px-4 text-xs font-mono text-[#C8C5BC]">{p.email}</td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-0.5 text-[10px] font-mono uppercase rounded font-bold ${
                          p.role === 'admin'
                            ? 'bg-amber-500/20 text-[#E5A93C] border border-amber-500/30'
                            : 'bg-white/5 text-zinc-300'
                        }`}
                      >
                        {p.role}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-xs font-mono text-[#71717A]">
                      {new Date(p.created_at).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {p.id !== currentUser.id && (
                        <button
                          onClick={() => handleDelete(p.id)}
                          className="p-1.5 text-[#A3A099] hover:text-red-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && editingProfile && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-md p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-base font-display font-bold text-white uppercase">
                  {editingProfile.id ? 'Edit Staff Profile' : 'Add New Staff Member'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {errorMessage && (
                <div className="p-2 bg-red-950/40 border border-red-500/40 text-red-200 text-xs font-mono rounded">
                  {errorMessage}
                </div>
              )}

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={editingProfile.full_name || ''}
                    onChange={(e) => setEditingProfile({ ...editingProfile, full_name: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={editingProfile.email || ''}
                    onChange={(e) => setEditingProfile({ ...editingProfile, email: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Authorization Role</label>
                  <select
                    value={editingProfile.role || 'editor'}
                    onChange={(e) =>
                      setEditingProfile({ ...editingProfile, role: e.target.value as UserRole })
                    }
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                  >
                    <option value="editor">Editor (Content Management)</option>
                    <option value="admin">Administrator (Full Access & User Control)</option>
                  </select>
                </div>

                <div className="pt-3 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
