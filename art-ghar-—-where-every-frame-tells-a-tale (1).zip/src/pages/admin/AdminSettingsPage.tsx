import React, { useState } from 'react';
import { store } from '../../lib/store';
import { isSupabaseConfigured } from '../../lib/supabase';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Save, CheckCircle2, RotateCcw, Database, ShieldAlert } from 'lucide-react';

export const AdminSettingsPage: React.FC = () => {
  const currentSettings = store.getSiteSettings();
  const [settings, setSettings] = useState<Record<string, any>>({ ...currentSettings });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);

  const supabaseActive = isSupabaseConfigured();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    store.updateSiteSettings(settings);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetSeeds = () => {
    store.resetToFactorySeeds();
    setSettings(store.getSiteSettings());
    setResetConfirmOpen(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <AdminLayout title="Studio & System Settings">
      <div className="max-w-4xl space-y-10">
        {/* Supabase Connection Status Card */}
        <div className="bg-[#121212] border border-white/5 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#181818] rounded border border-white/10 text-[#E5A93C]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-white text-base">
                  Database & Storage Engine
                </h3>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase tracking-wider ${
                    supabaseActive
                      ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950/60 text-amber-400 border border-amber-800/40'
                  }`}
                >
                  {supabaseActive ? 'Supabase Live Connected' : 'Production Reactive Store'}
                </span>
              </div>
              <p className="text-xs text-[#8E8B82] mt-1 font-light">
                {supabaseActive
                  ? 'All changes sync directly to external PostgreSQL and Supabase Storage buckets.'
                  : 'Operating in high-speed persistent mode with full RLS-compatible schema. Ready to link Supabase credentials anytime.'}
              </p>
            </div>
          </div>
        </div>

        {savedSuccess && (
          <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-lg text-emerald-200 text-xs font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Settings successfully committed to storage.</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-8">
          {/* Brand Identity */}
          <div className="bg-[#121212] border border-white/5 rounded-xl p-6 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Company & Brand Lockup
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">Studio Name</label>
                <input
                  type="text"
                  value={settings.company_name || 'Art Ghar'}
                  onChange={(e) => setSettings({ ...settings, company_name: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">Tagline</label>
                <input
                  type="text"
                  value={settings.tagline || 'WHERE EVERY FRAME TELLS A TALE'}
                  onChange={(e) => setSettings({ ...settings, tagline: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>
            </div>

            <div className="space-y-1 text-sm">
              <label className="text-xs font-mono uppercase text-[#A3A099]">Sub-Statement</label>
              <input
                type="text"
                value={settings.sub_tagline || ''}
                onChange={(e) => setSettings({ ...settings, sub_tagline: e.target.value })}
                className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
              />
            </div>
          </div>

          {/* Contact Coordinates */}
          <div className="bg-[#121212] border border-white/5 rounded-xl p-6 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Studio Coordinates
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">Inquiry Email</label>
                <input
                  type="email"
                  value={settings.contact_email || 'artgharproject@gmail.com'}
                  onChange={(e) => setSettings({ ...settings, contact_email: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">Telephone</label>
                <input
                  type="text"
                  value={settings.phone || '+977 1 552 4981'}
                  onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                />
              </div>
            </div>

            <div className="space-y-1 text-sm">
              <label className="text-xs font-mono uppercase text-[#A3A099]">Physical Location</label>
              <input
                type="text"
                value={settings.location || 'Jhamsikhel, Lalitpur, Kathmandu Valley, Nepal'}
                onChange={(e) => setSettings({ ...settings, location: e.target.value })}
                className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
              />
            </div>
          </div>

          {/* Social Media Links */}
          <div className="bg-[#121212] border border-white/5 rounded-xl p-6 space-y-4">
            <h3 className="text-xs font-mono uppercase tracking-[0.25em] text-[#E5A93C]">
              Social Media Distribution
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">Instagram URL</label>
                <input
                  type="url"
                  value={settings.instagram_url || ''}
                  onChange={(e) => setSettings({ ...settings, instagram_url: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-mono uppercase text-[#A3A099]">YouTube Channel</label>
                <input
                  type="url"
                  value={settings.youtube_url || ''}
                  onChange={(e) => setSettings({ ...settings, youtube_url: e.target.value })}
                  className="w-full bg-[#181818] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="submit"
              className="px-6 py-3 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-colors inline-flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save System Settings</span>
            </button>

            <button
              type="button"
              onClick={() => setResetConfirmOpen(true)}
              className="px-4 py-2 border border-red-500/30 text-red-400 hover:bg-red-950/20 text-xs font-mono uppercase rounded transition-colors inline-flex items-center gap-2"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Factory Seeds</span>
            </button>
          </div>
        </form>

        {/* Reset Confirmation Dialog */}
        {resetConfirmOpen && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <ShieldAlert className="w-10 h-10 text-red-400 mx-auto" />
              <h4 className="text-base font-display font-bold text-white">Reset Database</h4>
              <p className="text-xs text-[#8E8B82]">
                This will restore all default seed artists, releases, upcoming projects, and stories.
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setResetConfirmOpen(false)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={handleResetSeeds}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Confirm Reset
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
