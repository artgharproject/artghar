import React, { useState } from 'react';
import { store } from '../../lib/store';
import { TeamMember } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, MapPin, Mail, Phone, X, Check, Image as ImageIcon } from 'lucide-react';

export const AdminTeamPage: React.FC = () => {
  const teamMembers = store.getTeamMembers(true);
  const [editingMember, setEditingMember] = useState<Partial<TeamMember> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const sampleImages = [
    { label: 'Cinematic Producer', url: '/src/assets/images/featured_artist_portrait_1790823200594.jpg' },
    { label: 'Director of Photography', url: '/src/assets/images/hero_cinematic_production_1790823187023.jpg' },
    { label: 'Audio Architect', url: '/src/assets/images/art_ghar_studio_session_1790823237699.jpg' },
    { label: 'Production Manager', url: '/src/assets/images/production_showcase_film_1790823224467.jpg' },
    { label: 'Art Director', url: '/src/assets/images/release_cover_album_1790823212429.jpg' },
  ];

  const handleOpenCreate = () => {
    setEditingMember({
      name: '',
      role: '',
      bio: '',
      image: '/src/assets/images/featured_artist_portrait_1790823200594.jpg',
      address: 'Jhamsikhel, Lalitpur, Nepal',
      email: 'team@artghar.np',
      phone: '+977 1 552 4981',
      instagram_url: 'https://instagram.com/artghar',
      linkedin_url: '',
      sort_order: teamMembers.length + 1,
      published: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (member: TeamMember) => {
    setEditingMember({ ...member });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember?.name || !editingMember?.role) return;

    store.saveTeamMember(editingMember as any);
    setIsModalOpen(false);
    setEditingMember(null);
  };

  const handleDelete = (id: string) => {
    store.deleteTeamMember(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (member: TeamMember) => {
    store.saveTeamMember({ ...member, published: !member.published });
  };

  return (
    <AdminLayout title="Team & Creative Collective">
      <div className="space-y-6">
        {/* Top Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-mono text-[#8E8B82]">
              Manage creative directors, audio engineers, cinematographers, addresses, and contacts.
            </p>
          </div>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Add Team Member</span>
          </button>
        </div>

        {/* Team Table */}
        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Member</th>
                  <th className="py-3.5 px-4">Designation / Role</th>
                  <th className="py-3.5 px-4">Location & Address</th>
                  <th className="py-3.5 px-4">Contact Info</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {teamMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-white/[0.02] transition-colors">
                    {/* Animated Avatar / Thumbnail */}
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <div className="relative group/thumb w-12 h-12 rounded-lg overflow-hidden border border-white/10 shrink-0 bg-black">
                        <img
                          src={member.image}
                          alt={member.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover/thumb:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div>
                        <span className="font-semibold text-white block">{member.name}</span>
                        <span className="text-[11px] text-[#71717A] font-mono">Order: #{member.sort_order}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#E5A93C] font-mono font-medium">
                      {member.role}
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#E5A93C] shrink-0" />
                        <span className="truncate max-w-[200px]">{member.address}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#8E8B82] space-y-1">
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3 h-3 text-[#E5A93C]" />
                        <span className="truncate text-white">{member.email}</span>
                      </div>
                      {member.phone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3 h-3 text-[#E5A93C]" />
                          <span>{member.phone}</span>
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(member)}
                        className={`px-2.5 py-1 text-[10px] font-mono rounded uppercase tracking-wider ${
                          member.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {member.published ? 'Published' : 'Hidden'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(member)}
                        className="p-1.5 text-[#A3A099] hover:text-white transition-colors"
                        title="Edit Member"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(member.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400 transition-colors"
                        title="Delete Member"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Editor Form */}
        {isModalOpen && editingMember && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingMember.id ? 'Edit Team Member Profile' : 'Add New Team Member'}
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-[#71717A] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={editingMember.name || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                      placeholder="e.g. Nischal Shrestha"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Role / Title *</label>
                    <input
                      type="text"
                      required
                      value={editingMember.role || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value })}
                      placeholder="e.g. Director of Cinematography"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Address / Location *</label>
                    <input
                      type="text"
                      required
                      value={editingMember.address || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, address: e.target.value })}
                      placeholder="e.g. Jhamsikhel, Lalitpur, Nepal"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Display Sort Order</label>
                    <input
                      type="number"
                      value={editingMember.sort_order ?? 1}
                      onChange={(e) => setEditingMember({ ...editingMember, sort_order: parseInt(e.target.value, 10) || 1 })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Direct Contact Email *</label>
                    <input
                      type="email"
                      required
                      value={editingMember.email || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, email: e.target.value })}
                      placeholder="e.g. nischal@artghar.np"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Telephone / Mobile</label>
                    <input
                      type="text"
                      value={editingMember.phone || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, phone: e.target.value })}
                      placeholder="+977 980-1234567"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                {/* Direct Computer Upload for Team Animated Image / Portrait */}
                <ImageUploadField
                  label="Team Portrait / Animated Image (Upload from Computer)"
                  value={editingMember.image || ''}
                  onChange={(val) => setEditingMember({ ...editingMember, image: val })}
                  aspectRatio="portrait"
                  required
                  helperText="Upload any portrait photo from your computer. Supports animated GIF, PNG, JPG, or WEBP."
                />

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Biography & Responsibilities</label>
                  <textarea
                    rows={3}
                    value={editingMember.bio || ''}
                    onChange={(e) => setEditingMember({ ...editingMember, bio: e.target.value })}
                    placeholder="Describe their creative expertise, instruments, gear mastery, or film achievements..."
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Instagram Profile URL</label>
                    <input
                      type="text"
                      value={editingMember.instagram_url || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, instagram_url: e.target.value })}
                      placeholder="https://instagram.com/artghar"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">LinkedIn Profile URL</label>
                    <input
                      type="text"
                      value={editingMember.linkedin_url || ''}
                      onChange={(e) => setEditingMember({ ...editingMember, linkedin_url: e.target.value })}
                      placeholder="https://linkedin.com/in/..."
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingMember.published ?? true}
                      onChange={(e) => setEditingMember({ ...editingMember, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Visible On Public Website</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Team Member
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation Alert */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this team member from Art Ghar?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
