import React, { useState } from 'react';
import { store } from '../../lib/store';
import { UpcomingProject, UpcomingStatus } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Star, X } from 'lucide-react';

export const AdminUpcomingPage: React.FC = () => {
  const upcoming = store.getUpcomingProjects(true);
  const artists = store.getArtists(true);
  const [editingItem, setEditingItem] = useState<Partial<UpcomingProject> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const statuses: UpcomingStatus[] = ['Announced', 'Coming Soon', 'In Production', 'Post Production', 'Scheduled'];

  const handleOpenCreate = () => {
    setEditingItem({
      title: '',
      slug: '',
      artist_id: artists[0]?.id || '',
      project_type: 'Original Film & Score',
      artwork: '/src/assets/images/production_showcase_film_1790823224467.jpg',
      description: '',
      announcement: '',
      expected_release_date: 'Late 2026',
      status: 'In Production',
      featured: false,
      published: true,
      trailer_url: '',
      pre_save_url: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: UpcomingProject) => {
    setEditingItem({ ...item });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem?.title || !editingItem?.artist_id) return;

    store.saveUpcoming(editingItem as any);
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleDelete = (id: string) => {
    store.deleteUpcoming(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (item: UpcomingProject) => {
    store.saveUpcoming({ ...item, published: !item.published });
  };

  const toggleFeatured = (item: UpcomingProject) => {
    store.saveUpcoming({ ...item, featured: !item.featured });
  };

  return (
    <AdminLayout title="Upcoming Works & Calendar">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Controls the featured UPCOMING section on the homepage and calendar page.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>New Upcoming Work</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Project</th>
                  <th className="py-3.5 px-4">Artist Partner</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Expected Date</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">State</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {upcoming.map((item) => (
                  <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={item.artwork}
                        alt={item.title}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{item.title}</span>
                        <span className="text-xs text-[#71717A] font-mono">{item.project_type}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">
                      {item.artist?.name || 'Unassigned'}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 text-[10px] font-mono uppercase bg-black/60 text-[#E5A93C] border border-[#E5A93C]/30 rounded">
                        {item.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#8E8B82]">{item.expected_release_date}</td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(item)}
                        className={`p-1 rounded ${item.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'}`}
                      >
                        <Star className={`w-4 h-4 ${item.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(item)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          item.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {item.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(item)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                        title="Edit Project"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(item.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400"
                        title="Delete Project"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && editingItem && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingItem.id ? 'Edit Upcoming Record' : 'Announce Upcoming Odyssey'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Title *</label>
                    <input
                      type="text"
                      required
                      value={editingItem.title || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Artist Partner *</label>
                    <select
                      value={editingItem.artist_id || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, artist_id: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {artists.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Project Type</label>
                    <input
                      type="text"
                      value={editingItem.project_type || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, project_type: e.target.value })}
                      placeholder="e.g. Feature Film & Score"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Status</label>
                    <select
                      value={editingItem.status || 'Coming Soon'}
                      onChange={(e) =>
                        setEditingItem({ ...editingItem, status: e.target.value as UpcomingStatus })
                      }
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {statuses.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Target Delivery</label>
                    <input
                      type="text"
                      value={editingItem.expected_release_date || ''}
                      onChange={(e) =>
                        setEditingItem({ ...editingItem, expected_release_date: e.target.value })
                      }
                      placeholder="e.g. November 2026"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <ImageUploadField
                  label="Upcoming Project Poster / Key Visual (Upload from Computer)"
                  value={editingItem.artwork || ''}
                  onChange={(val) => setEditingItem({ ...editingItem, artwork: val })}
                  aspectRatio="video"
                  required
                  helperText="Upload official key visual or promotional poster directly from your computer."
                />

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Synopsis / Description</label>
                  <textarea
                    rows={3}
                    value={editingItem.description || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Production Announcement</label>
                  <input
                    type="text"
                    value={editingItem.announcement || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, announcement: e.target.value })}
                    placeholder="e.g. Principal filming wrapped in Humla. In final Dolby Atmos mix."
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Trailer Video URL</label>
                    <input
                      type="url"
                      value={editingItem.trailer_url || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, trailer_url: e.target.value })}
                      placeholder="https://youtube.com/..."
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Pre-Save URL</label>
                    <input
                      type="url"
                      value={editingItem.pre_save_url || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, pre_save_url: e.target.value })}
                      placeholder="https://spotify.com/..."
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingItem.published ?? true}
                      onChange={(e) => setEditingItem({ ...editingItem, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingItem.featured ?? false}
                      onChange={(e) => setEditingItem({ ...editingItem, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Feature at Top of Homepage</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Upcoming Record
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this upcoming project?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
