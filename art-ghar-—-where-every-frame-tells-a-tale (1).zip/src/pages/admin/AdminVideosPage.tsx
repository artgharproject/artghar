import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Video } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Star, Play, X, ExternalLink } from 'lucide-react';
import { extractYoutubeId, getYoutubeThumbnail } from '../../lib/youtube';

export const AdminVideosPage: React.FC = () => {
  const videos = store.getVideos(true);
  const [editingVideo, setEditingVideo] = useState<Partial<Video> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingVideo({
      title: '',
      slug: '',
      thumbnail: '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      youtube_url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      category: 'Music Video',
      description: '',
      release_date: new Date().toISOString().split('T')[0],
      featured: false,
      published: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (vid: Video) => {
    setEditingVideo({ ...vid });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVideo?.title || !editingVideo?.youtube_url) return;

    store.saveVideo(editingVideo as any);
    setIsModalOpen(false);
    setEditingVideo(null);
  };

  const handleDelete = (id: string) => {
    store.deleteVideo(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (vid: Video) => {
    store.saveVideo({ ...vid, published: !vid.published });
  };

  const toggleFeatured = (vid: Video) => {
    store.saveVideo({ ...vid, featured: !vid.featured });
  };

  return (
    <AdminLayout title="Video Vault & Screen">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Manage music videos, documentary reels, and YouTube/Vimeo embeds.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Add Video</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Video</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">URL</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {videos.map((vid) => (
                  <tr key={vid.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={vid.thumbnail}
                        alt={vid.title}
                        referrerPolicy="no-referrer"
                        className="w-12 h-8 rounded object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{vid.title}</span>
                        <span className="text-xs text-[#71717A] font-mono">{vid.release_date}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs font-mono text-[#E5A93C]">{vid.category}</td>
                    <td className="py-3.5 px-4 text-xs text-[#8E8B82] truncate max-w-xs">{vid.youtube_url}</td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(vid)}
                        className={`p-1 rounded ${vid.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'}`}
                      >
                        <Star className={`w-4 h-4 ${vid.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(vid)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          vid.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {vid.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(vid)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                        title="Edit Video"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(vid.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400"
                        title="Delete Video"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && editingVideo && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-lg p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingVideo.id ? 'Edit Video Entry' : 'Add New Video'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Title *</label>
                  <input
                    type="text"
                    required
                    value={editingVideo.title || ''}
                    onChange={(e) => setEditingVideo({ ...editingVideo, title: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">YouTube / Video URL *</label>
                  <input
                    type="url"
                    required
                    value={editingVideo.youtube_url || ''}
                    onChange={(e) => {
                      const url = e.target.value;
                      const thumb = getYoutubeThumbnail(url);
                      setEditingVideo({
                        ...editingVideo,
                        youtube_url: url,
                        thumbnail: thumb || editingVideo.thumbnail,
                      });
                    }}
                    placeholder="e.g. https://youtu.be/9ik9froFIHs or https://youtube.com/watch?v=..."
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                  <p className="text-[11px] font-mono text-[#71717A]">
                    Paste standard YouTube link or youtu.be shortlink. High-definition thumbnail is detected automatically.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Category</label>
                    <input
                      type="text"
                      value={editingVideo.category || ''}
                      onChange={(e) => setEditingVideo({ ...editingVideo, category: e.target.value })}
                      placeholder="e.g. Official Music Video"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Release Date</label>
                    <input
                      type="date"
                      value={editingVideo.release_date || ''}
                      onChange={(e) => setEditingVideo({ ...editingVideo, release_date: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <ImageUploadField
                  label="Video Thumbnail / Cinema Poster (Upload from Computer)"
                  value={editingVideo.thumbnail || ''}
                  onChange={(val) => setEditingVideo({ ...editingVideo, thumbnail: val })}
                  aspectRatio="video"
                  helperText="Auto-detected from YouTube or upload your own custom high-res cinema poster."
                />

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Description</label>
                  <textarea
                    rows={3}
                    value={editingVideo.description || ''}
                    onChange={(e) => setEditingVideo({ ...editingVideo, description: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingVideo.published ?? true}
                      onChange={(e) => setEditingVideo({ ...editingVideo, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingVideo.featured ?? false}
                      onChange={(e) => setEditingVideo({ ...editingVideo, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Feature on Homepage Screen</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Video
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this video entry?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button onClick={() => setDeleteConfirmId(null)} className="px-4 py-1.5 text-xs text-[#A3A099]">
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
