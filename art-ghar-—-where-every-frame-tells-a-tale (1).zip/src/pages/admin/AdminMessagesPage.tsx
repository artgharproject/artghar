import React, { useState } from 'react';
import { store } from '../../lib/store';
import { ContactMessage, MessageStatus } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Mail, CheckCircle, Clock, Trash2, X, ExternalLink } from 'lucide-react';

export const AdminMessagesPage: React.FC = () => {
  const messages = store.getContactMessages();
  const [activeMessage, setActiveMessage] = useState<ContactMessage | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredMessages = messages.filter((m) =>
    filterStatus === 'all' ? true : m.status === filterStatus
  );

  const handleUpdateStatus = (id: string, status: MessageStatus) => {
    store.updateMessageStatus(id, status);
    if (activeMessage && activeMessage.id === id) {
      setActiveMessage({ ...activeMessage, status });
    }
  };

  const handleDelete = (id: string) => {
    store.deleteContactMessage(id);
    if (activeMessage?.id === id) {
      setActiveMessage(null);
    }
  };

  return (
    <AdminLayout title="Inquiries & Project Requests">
      <div className="space-y-6">
        {/* Top Filter Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
            {['all', 'New', 'Read', 'In Progress', 'Resolved'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 text-xs font-mono uppercase tracking-wider rounded transition-colors whitespace-nowrap ${
                  filterStatus === st
                    ? 'bg-[#E5A93C] text-[#0A0A0A] font-semibold'
                    : 'text-[#A3A099] bg-white/5 hover:text-white'
                }`}
              >
                {st === 'all' ? 'All Inquiries' : st}
              </button>
            ))}
          </div>

          <span className="text-xs font-mono text-[#8E8B82]">
            Total {filteredMessages.length} Messages
          </span>
        </div>

        {/* Messages List Table */}
        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          {filteredMessages.length === 0 ? (
            <div className="p-12 text-center text-xs text-[#71717A] font-mono">
              No inquiries match this status filter.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                  <tr>
                    <th className="py-3.5 px-4">Contact</th>
                    <th className="py-3.5 px-4">Project Classification</th>
                    <th className="py-3.5 px-4">Organization</th>
                    <th className="py-3.5 px-4">Date Received</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredMessages.map((msg) => (
                    <tr
                      key={msg.id}
                      onClick={() => {
                        setActiveMessage(msg);
                        if (msg.status === 'New') {
                          handleUpdateStatus(msg.id, 'Read');
                        }
                      }}
                      className="hover:bg-white/[0.03] transition-colors cursor-pointer"
                    >
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-white block">{msg.name}</span>
                        <span className="text-xs text-[#71717A] font-mono">{msg.email}</span>
                      </td>

                      <td className="py-3.5 px-4 text-xs font-mono text-[#E5A93C]">
                        {msg.project_type}
                      </td>

                      <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">
                        {msg.organization || 'Individual'}
                      </td>

                      <td className="py-3.5 px-4 text-xs text-[#8E8B82] font-mono">
                        {new Date(msg.created_at).toLocaleDateString()}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                            msg.status === 'New'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : msg.status === 'In Progress'
                              ? 'bg-blue-950/40 text-blue-300 border border-blue-800/40'
                              : msg.status === 'Resolved'
                              ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                              : 'bg-zinc-800 text-zinc-400'
                          }`}
                        >
                          {msg.status}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(msg.id);
                          }}
                          className="p-1.5 text-[#71717A] hover:text-red-400"
                          title="Delete Message"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Message Inspection Dialog */}
        {activeMessage && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="space-y-0.5">
                  <span className="text-[10px] font-mono uppercase text-[#E5A93C]">
                    Project Inquiry Details
                  </span>
                  <h3 className="text-xl font-display font-bold text-white">
                    {activeMessage.name}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveMessage(null)}
                  className="p-1 text-[#71717A] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 text-xs font-mono">
                <div className="grid grid-cols-2 gap-4 p-4 bg-[#181818] rounded border border-white/5">
                  <div>
                    <span className="text-[#71717A] block">Email</span>
                    <a
                      href={`mailto:${activeMessage.email}`}
                      className="text-white hover:text-[#E5A93C] underline flex items-center gap-1 mt-0.5"
                    >
                      <span>{activeMessage.email}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Classification</span>
                    <span className="text-[#E5A93C] block mt-0.5">{activeMessage.project_type}</span>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Organization</span>
                    <span className="text-white block mt-0.5">{activeMessage.organization || 'None'}</span>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Timestamp</span>
                    <span className="text-white block mt-0.5">
                      {new Date(activeMessage.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-[#A3A099] uppercase tracking-wider block">
                    Message Narrative
                  </span>
                  <div className="p-4 bg-[#181818] rounded border border-white/5 text-sm text-[#F4F1EA] font-sans font-light leading-relaxed whitespace-pre-wrap">
                    {activeMessage.message}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-[#A3A099]">Update Status:</span>
                  <div className="flex items-center gap-2">
                    {(['New', 'Read', 'In Progress', 'Resolved'] as MessageStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => handleUpdateStatus(activeMessage.id, st)}
                        className={`px-2.5 py-1 rounded text-[10px] uppercase font-mono ${
                          activeMessage.status === st
                            ? 'bg-[#E5A93C] text-black font-bold'
                            : 'bg-white/5 text-[#A3A099] hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
