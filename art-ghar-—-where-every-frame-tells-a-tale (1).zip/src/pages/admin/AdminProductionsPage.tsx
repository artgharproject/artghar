import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Production, ProductionCategory } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Star, X } from 'lucide-react';

export const AdminProductionsPage: React.FC = () => {
  const productions = store.getProductions(true);
  const [editingProd, setEditingProd] = useState<Partial<Production> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const categories: ProductionCategory[] = ['Music', 'Film', 'Commercial', 'Visual', 'Documentary', 'Original', 'Other'];

  const handleOpenCreate = () => {
    setEditingProd({
      title: '',
      slug: '',
      category: 'Film',
      cover_image: '/src/assets/images/production_showcase_film_1790823224467.jpg',
      hero_image: '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      description: '',
      content: '',
      client_name: '',
      production_date: new Date().toISOString().split('T')[0],
      featured: false,
      published: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (prod: Production) => {
    setEditingProd({ ...prod });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProd?.title) return;

    store.saveProduction(editingProd as any);
    setIsModalOpen(false);
    setEditingProd(null);
  };

  const handleDelete = (id: string) => {
    store.deleteProduction(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (prod: Production) => {
    store.saveProduction({ ...prod, published: !prod.published });
  };

  const toggleFeatured = (prod: Production) => {
    store.saveProduction({ ...prod, featured: !prod.featured });
  };

  return (
    <AdminLayout title="Productions & Film Works">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Manage motion pictures, visual art poems, commercials, and documentaries.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>New Production</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Production Title</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Client / Commission</th>
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {productions.map((prod) => (
                  <tr key={prod.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={prod.cover_image}
                        alt={prod.title}
                        referrerPolicy="no-referrer"
                        className="w-12 h-8 rounded object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{prod.title}</span>
                        <span className="text-xs text-[#71717A] font-mono">/productions/{prod.slug}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs font-mono text-[#E5A93C]">{prod.category}</td>
                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">{prod.client_name || 'Art Ghar Originals'}</td>
                    <td className="py-3.5 px-4 text-xs text-[#8E8B82]">{prod.production_date}</td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(prod)}
                        className={`p-1 rounded ${prod.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'}`}
                      >
                        <Star className={`w-4 h-4 ${prod.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(prod)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          prod.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {prod.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(prod)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                        title="Edit Production"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(prod.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400"
                        title="Delete Production"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && editingProd && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingProd.id ? 'Edit Production Case' : 'New Production'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Title *</label>
                    <input
                      type="text"
                      required
                      value={editingProd.title || ''}
                      onChange={(e) => setEditingProd({ ...editingProd, title: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Category</label>
                    <select
                      value={editingProd.category || 'Film'}
                      onChange={(e) =>
                        setEditingProd({ ...editingProd, category: e.target.value as ProductionCategory })
                      }
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {categories.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Client / Commissioner</label>
                    <input
                      type="text"
                      value={editingProd.client_name || ''}
                      onChange={(e) => setEditingProd({ ...editingProd, client_name: e.target.value })}
                      placeholder="e.g. Himalayan Cinema Collective"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Production Date</label>
                    <input
                      type="date"
                      value={editingProd.production_date || ''}
                      onChange={(e) => setEditingProd({ ...editingProd, production_date: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <ImageUploadField
                    label="Production Thumbnail Poster (Upload from Computer)"
                    value={editingProd.cover_image || ''}
                    onChange={(val) => setEditingProd({ ...editingProd, cover_image: val })}
                    aspectRatio="video"
                    required
                    helperText="Upload official production poster or key frame."
                  />

                  <ImageUploadField
                    label="Hero Anamorphic Banner (Upload from Computer)"
                    value={editingProd.hero_image || ''}
                    onChange={(val) => setEditingProd({ ...editingProd, hero_image: val })}
                    aspectRatio="wide"
                    helperText="Upload cinematic wide aspect banner."
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Brief Synopsis</label>
                  <textarea
                    rows={2}
                    value={editingProd.description || ''}
                    onChange={(e) => setEditingProd({ ...editingProd, description: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Narrative Case Study Content</label>
                  <textarea
                    rows={6}
                    value={editingProd.content || ''}
                    onChange={(e) => setEditingProd({ ...editingProd, content: e.target.value })}
                    placeholder="Describe cinematography techniques, location challenges, acoustic score..."
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingProd.published ?? true}
                      onChange={(e) => setEditingProd({ ...editingProd, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingProd.featured ?? false}
                      onChange={(e) => setEditingProd({ ...editingProd, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Featured in Selected Work</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Production
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this production case?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
