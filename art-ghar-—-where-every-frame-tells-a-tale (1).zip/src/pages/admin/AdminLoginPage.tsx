import React, { useState } from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { ArtGharLogo } from '../../components/common/ArtGharLogo';
import { Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';

export const AdminLoginPage: React.FC = () => {
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await store.login(email, password);
      setLoading(false);
      if (res.success) {
        navigate('/admin');
      } else {
        setError(res.error || 'Authentication rejected. Verify credentials.');
      }
    } catch (err: any) {
      setLoading(false);
      setError('System login error. Please retry.');
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] flex flex-col justify-center items-center p-6 relative">
      <div className="absolute inset-0 bg-radial from-transparent via-[#0A0A0A]/80 to-[#0A0A0A]" />

      <div className="relative z-10 w-full max-w-md bg-[#121212] border border-white/10 rounded-2xl p-8 sm:p-10 shadow-2xl space-y-8">
        <div className="text-center space-y-3">
          <div className="flex justify-center mb-2">
            <ArtGharLogo variant="icon-only" size="lg" withGlow />
          </div>
          <h1 className="text-2xl font-display font-extrabold uppercase text-[#F4F1EA] tracking-wider">
            ART GHAR <span className="text-[#E5A93C]">CMS</span>
          </h1>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-[#8E8B82]">
            Production Content Management System
          </p>
        </div>

        {error && (
          <div className="p-3 bg-red-950/40 border border-red-500/50 rounded text-red-200 text-xs font-mono">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
          <div className="space-y-1.5">
            <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
              Authorized Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#71717A]" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="artgharproject@gmail.com"
                className="w-full bg-[#181818] border border-white/10 rounded pl-10 pr-4 py-2.5 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-mono uppercase tracking-wider text-[#A3A099] block">
              Passcode
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#71717A]" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-[#181818] border border-white/10 rounded pl-10 pr-4 py-2.5 text-sm text-[#F4F1EA] placeholder-[#555] focus:outline-none focus:border-[#E5A93C]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-[0.2em] rounded transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
          >
            {loading ? (
              <span>Authorizing...</span>
            ) : (
              <>
                <span>Access CMS Console</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="pt-4 border-t border-white/5 text-center space-y-2">
          <div className="p-3 bg-black/40 rounded border border-white/5 text-[11px] font-mono text-[#8E8B82] space-y-1">
            <div className="flex items-center justify-center gap-1.5 text-[#E5A93C]">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span className="font-semibold uppercase">Client Production Access</span>
            </div>
            <p>Email: <span className="text-white font-mono">artgharproject@gmail.com</span></p>
            <p>Password: <span className="text-white font-mono">artghar2026!</span></p>
          </div>
          <button
            onClick={() => navigate('/')}
            className="text-xs text-[#71717A] hover:text-[#A3A099] transition-colors"
          >
            ← Return to Art Ghar Homepage
          </button>
        </div>
      </div>
    </div>
  );
};
