import React from 'react';
import { useRouter } from '../../lib/router';
import { store } from '../../lib/store';
import { AdminLayout } from '../../components/admin/AdminLayout';
import {
  Users,
  Disc,
  Clock,
  BookOpen,
  Film,
  Mail,
  ArrowRight,
  PlusCircle,
  ExternalLink,
} from 'lucide-react';

export const AdminDashboardPage: React.FC = () => {
  const { navigate } = useRouter();

  const artists = store.getArtists(true);
  const team = store.getTeamMembers(true);
  const releases = store.getReleases(true);
  const upcoming = store.getUpcomingProjects(true);
  const productions = store.getProductions(true);
  const posts = store.getBlogPosts(true);
  const messages = store.getContactMessages();

  interface MetricItem {
    label: string;
    value: number;
    href: string;
    icon: any;
    sub: string;
    highlight?: boolean;
  }

  const metrics: MetricItem[] = [
    {
      label: 'Total Artists',
      value: artists.length,
      href: '/admin/artists',
      icon: Users,
      sub: `${artists.filter((a) => a.published).length} Published`,
    },
    {
      label: 'Creative Team',
      value: team.length,
      href: '/admin/team',
      icon: Users,
      sub: `${team.filter((t) => t.published).length} Published Members`,
    },
    {
      label: 'Total Releases',
      value: releases.length,
      href: '/admin/releases',
      icon: Disc,
      sub: `${releases.filter((r) => r.published).length} Published`,
    },
    {
      label: 'Upcoming Odysseys',
      value: upcoming.length,
      href: '/admin/upcoming',
      icon: Clock,
      sub: `${upcoming.filter((u) => u.status === 'In Production').length} In Production`,
    },
    {
      label: 'Productions',
      value: productions.length,
      href: '/admin/productions',
      icon: Film,
      sub: `${productions.filter((p) => p.featured).length} Featured`,
    },
    {
      label: 'Journal Articles',
      value: posts.length,
      href: '/admin/journal',
      icon: BookOpen,
      sub: `${posts.filter((p) => p.published).length} Published`,
    },
  ];

  return (
    <AdminLayout title="System Overview">
      <div className="space-y-10">
        {/* Welcome Banner & Quick Shortcuts */}
        <div className="bg-[#141414] border border-white/5 rounded-xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-display font-bold text-white">
              Studio Content Management Console
            </h2>
            <p className="text-xs sm:text-sm text-[#8E8B82] font-light">
              Connected to Art Ghar PostgreSQL database. Dynamic updates reflect immediately on the public website.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => navigate('/admin/artists')}
              className="px-3.5 py-2 text-xs font-mono uppercase bg-[#E5A93C] text-[#0A0A0A] font-bold rounded hover:bg-[#F3C065] transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New Artist</span>
            </button>
            <button
              onClick={() => navigate('/admin/team')}
              className="px-3.5 py-2 text-xs font-mono uppercase bg-white/5 hover:bg-white/10 text-white rounded border border-white/10 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New Team Member</span>
            </button>
            <button
              onClick={() => navigate('/admin/releases')}
              className="px-3.5 py-2 text-xs font-mono uppercase bg-white/5 hover:bg-white/10 text-white rounded border border-white/10 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New Release</span>
            </button>
            <button
              onClick={() => navigate('/admin/upcoming')}
              className="px-3.5 py-2 text-xs font-mono uppercase bg-white/5 hover:bg-white/10 text-white rounded border border-white/10 transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>New Upcoming</span>
            </button>
          </div>
        </div>

        {/* 6 Real Database Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {metrics.map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.label}
                onClick={() => navigate(m.href)}
                className={`group cursor-pointer bg-[#121212] border rounded-xl p-6 flex items-start justify-between transition-all duration-200 hover:border-[#E5A93C]/50 ${
                  m.highlight ? 'border-[#E5A93C]/40 bg-[#161410]' : 'border-white/5'
                }`}
              >
                <div className="space-y-2">
                  <span className="text-xs font-mono uppercase tracking-wider text-[#8E8B82] block">
                    {m.label}
                  </span>
                  <div className="text-3xl font-display font-extrabold text-[#F4F1EA] tabular-nums">
                    {m.value}
                  </div>
                  <span className="text-[11px] text-[#A3A099] block font-mono">
                    {m.sub}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white/5 text-[#E5A93C] group-hover:bg-[#E5A93C] group-hover:text-black transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Two-Column Recent Activity Feed */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Inquiries */}
          <div className="bg-[#121212] border border-white/5 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C]">
                Recent Inquiries ({messages.length})
              </h3>
              <button
                onClick={() => navigate('/admin/messages')}
                className="text-xs text-[#8E8B82] hover:text-[#E5A93C] flex items-center gap-1 font-mono"
              >
                <span>View Inbox</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {messages.length === 0 ? (
              <p className="text-xs text-[#71717A] py-6 text-center">No inquiry messages yet.</p>
            ) : (
              <div className="space-y-3">
                {messages.slice(0, 4).map((msg) => (
                  <div
                    key={msg.id}
                    onClick={() => navigate('/admin/messages')}
                    className="p-3 bg-[#161616] hover:bg-[#1a1a1a] rounded cursor-pointer transition-colors space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-white">{msg.name}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          msg.status === 'New'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-white/5 text-[#888]'
                        }`}
                      >
                        {msg.status}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#E5A93C] font-mono block">
                      {msg.project_type}
                    </span>
                    <p className="text-xs text-[#8E8B82] line-clamp-1">{msg.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Releases */}
          <div className="bg-[#121212] border border-white/5 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#E5A93C]">
                Recent Releases ({releases.length})
              </h3>
              <button
                onClick={() => navigate('/admin/releases')}
                className="text-xs text-[#8E8B82] hover:text-[#E5A93C] flex items-center gap-1 font-mono"
              >
                <span>Manage</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-3">
              {releases.slice(0, 4).map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => navigate('/admin/releases')}
                  className="p-3 bg-[#161616] hover:bg-[#1a1a1a] rounded cursor-pointer transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={rel.cover_image}
                      alt={rel.title}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded object-cover"
                    />
                    <div>
                      <h4 className="text-sm font-semibold text-white">{rel.title}</h4>
                      <span className="text-[11px] text-[#A3A099] font-mono">
                        {rel.release_type} · {rel.release_date}
                      </span>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      rel.published ? 'text-emerald-400 bg-emerald-950/40' : 'text-zinc-400 bg-zinc-800'
                    }`}
                  >
                    {rel.published ? 'Published' : 'Draft'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};
