import React, { useState } from 'react';
import { store } from '../../lib/store';
import { TimelineItem } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { Plus, Edit2, Trash2, X } from 'lucide-react';

export const AdminTimelinePage: React.FC = () => {
  const timeline = store.getTimeline(true);
  const [editingItem, setEditingItem] = useState<Partial<TimelineItem> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingItem({
      year: new Date().getFullYear().toString(),
      title: '',
      description: '',
      sort_order: timeline.length + 1,
      published: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: TimelineItem) => {
    setEditingItem({ ...item });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem?.year || !editingItem?.title) return;

    store.saveTimelineItem(editingItem as any);
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleDelete = (id: string) => {
    store.deleteTimelineItem(id);
    setDeleteConfirmId(null);
  };

  return (
    <AdminLayout title="Timeline Chronology">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Controls the chronological journey milestones showcased on the About House page.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Add Milestone</span>
          </button>
        </div>

        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="divide-y divide-white/5">
            {timeline.map((item) => (
              <div key={item.id} className="p-4 sm:p-5 flex items-start justify-between gap-4 hover:bg-white/[0.02]">
                <div className="flex items-start gap-4">
                  <span className="px-3 py-1 text-xs font-mono font-bold bg-[#E5A93C]/10 text-[#E5A93C] border border-[#E5A93C]/20 rounded">
                    {item.year}
                  </span>
                  <div className="space-y-1">
                    <h4 className="font-display font-bold text-white text-base">{item.title}</h4>
                    <p className="text-xs sm:text-sm text-[#8E8B82] font-light max-w-2xl">{item.description}</p>
                    <span className="text-[10px] font-mono text-[#71717A] block">Sequence Order: #{item.sort_order}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleOpenEdit(item)}
                    className="p-1.5 text-[#A3A099] hover:text-white"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(item.id)}
                    className="p-1.5 text-[#A3A099] hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal */}
        {isModalOpen && editingItem && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-md p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-base font-display font-bold text-white uppercase">
                  {editingItem.id ? 'Edit Milestone' : 'Add Milestone'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Year / Era *</label>
                    <input
                      type="text"
                      required
                      value={editingItem.year || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, year: e.target.value })}
                      placeholder="e.g. 2024"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Sort Order</label>
                    <input
                      type="number"
                      value={editingItem.sort_order || 1}
                      onChange={(e) => setEditingItem({ ...editingItem, sort_order: parseInt(e.target.value) || 1 })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Milestone Title *</label>
                  <input
                    type="text"
                    required
                    value={editingItem.title || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                    placeholder="e.g. Debut Feature Film Soundtrack"
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Description</label>
                  <textarea
                    rows={3}
                    value={editingItem.description || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white"
                  />
                </div>

                <div className="pt-3 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Delete Milestone</h4>
              <p className="text-xs text-[#8E8B82]">Are you sure you wish to delete this timeline entry?</p>
              <div className="flex justify-center gap-3 pt-2">
                <button onClick={() => setDeleteConfirmId(null)} className="px-4 py-1.5 text-xs text-[#A3A099]">
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
