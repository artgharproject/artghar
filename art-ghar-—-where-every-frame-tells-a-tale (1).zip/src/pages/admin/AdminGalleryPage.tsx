import React, { useState } from 'react';
import { store } from '../../lib/store';
import { GalleryItem } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Trash2, Edit2, Upload, Star, X } from 'lucide-react';

export const AdminGalleryPage: React.FC = () => {
  const items = store.getGallery(true);
  const [editingItem, setEditingItem] = useState<Partial<GalleryItem> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const handleOpenCreate = () => {
    setEditingItem({
      title: '',
      image_url: '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      caption: '',
      category: 'Studio',
      featured: false,
      published: true,
      sort_order: items.length + 1,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: GalleryItem) => {
    setEditingItem({ ...item });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem?.title || !editingItem?.image_url) return;

    store.saveGalleryItem(editingItem as any);
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleDelete = (id: string) => {
    store.deleteGalleryItem(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (item: GalleryItem) => {
    store.saveGalleryItem({ ...item, published: !item.published });
  };

  const toggleFeatured = (item: GalleryItem) => {
    store.saveGalleryItem({ ...item, featured: !item.featured });
  };

  return (
    <AdminLayout title="The Art Ghar Wall & Gallery">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Curate visual moments, behind-the-scenes 35mm stills, and studio sessions.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Wall Item</span>
          </button>
        </div>

        {/* Gallery Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item) => (
            <div
              key={item.id}
              className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden flex flex-col justify-between group hover:border-[#E5A93C]/40 transition-all"
            >
              <div className="relative aspect-[4/3] bg-black">
                <img
                  src={item.image_url}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-2 py-0.5 text-[9px] font-mono uppercase bg-black/80 text-[#E5A93C] rounded">
                    {item.category}
                  </span>
                </div>

                <div className="absolute top-3 right-3 flex items-center gap-1.5">
                  <button
                    onClick={() => toggleFeatured(item)}
                    className={`p-1.5 rounded-full bg-black/70 ${item.featured ? 'text-[#E5A93C]' : 'text-zinc-500 hover:text-white'}`}
                  >
                    <Star className={`w-3.5 h-3.5 ${item.featured ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => togglePublished(item)}
                    className={`px-2 py-0.5 text-[9px] font-mono rounded ${
                      item.published ? 'bg-emerald-900/60 text-emerald-300' : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {item.published ? 'Live' : 'Draft'}
                  </button>
                </div>
              </div>

              <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-display font-bold text-white text-base">{item.title}</h4>
                  {item.caption && (
                    <p className="text-xs text-[#8E8B82] line-clamp-2 mt-1">{item.caption}</p>
                  )}
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                  <span className="text-[10px] font-mono text-[#71717A]">
                    Order #{item.sort_order}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenEdit(item)}
                      className="p-1 text-[#A3A099] hover:text-white"
                      title="Edit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(item.id)}
                      className="p-1 text-[#A3A099] hover:text-red-400"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {isModalOpen && editingItem && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-lg p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingItem.id ? 'Edit Wall Asset' : 'Add Image to Wall'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Title / Subject *</label>
                  <input
                    type="text"
                    required
                    value={editingItem.title || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <ImageUploadField
                  label="Art Ghar Wall Photograph / Still (Upload from Computer)"
                  value={editingItem.image_url || ''}
                  onChange={(val) => setEditingItem({ ...editingItem, image_url: val })}
                  aspectRatio="auto"
                  required
                  helperText="Upload 35mm film stills, behind-the-scenes moments, or studio photography from your computer."
                />

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Category</label>
                    <input
                      type="text"
                      value={editingItem.category || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                      placeholder="e.g. Behind The Scenes"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Sort Sequence</label>
                    <input
                      type="number"
                      value={editingItem.sort_order || 1}
                      onChange={(e) =>
                        setEditingItem({ ...editingItem, sort_order: parseInt(e.target.value) || 1 })
                      }
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Caption & Notes</label>
                  <textarea
                    rows={3}
                    value={editingItem.caption || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, caption: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingItem.published ?? true}
                      onChange={(e) => setEditingItem({ ...editingItem, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingItem.featured ?? false}
                      onChange={(e) => setEditingItem({ ...editingItem, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Feature in Homepage Masonry</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Asset
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this wall item?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button onClick={() => setDeleteConfirmId(null)} className="px-4 py-1.5 text-xs text-[#A3A099]">
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
