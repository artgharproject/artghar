import React, { useState } from 'react';
import { store } from '../../lib/store';
import { Release, ReleaseType } from '../../types/database';
import { AdminLayout } from '../../components/admin/AdminLayout';
import { ImageUploadField } from '../../components/admin/ImageUploadField';
import { Plus, Edit2, Trash2, Star, X } from 'lucide-react';

export const AdminReleasesPage: React.FC = () => {
  const releases = store.getReleases(true);
  const artists = store.getArtists(true);
  const [editingRelease, setEditingRelease] = useState<Partial<Release> | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const releaseTypes: ReleaseType[] = ['Single', 'EP', 'Album', 'Soundtrack', 'Original', 'Collaboration'];

  const handleOpenCreate = () => {
    setEditingRelease({
      title: '',
      slug: '',
      artist_id: artists[0]?.id || '',
      release_type: 'Single',
      cover_image: '/src/assets/images/release_cover_album_1790823212429.jpg',
      description: '',
      release_date: new Date().toISOString().split('T')[0],
      featured: false,
      published: true,
      spotify_url: '',
      apple_music_url: '',
      youtube_url: '',
      credits: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (release: Release) => {
    setEditingRelease({ ...release });
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRelease?.title || !editingRelease?.artist_id) return;

    store.saveRelease(editingRelease as any);
    setIsModalOpen(false);
    setEditingRelease(null);
  };

  const handleDelete = (id: string) => {
    store.deleteRelease(id);
    setDeleteConfirmId(null);
  };

  const togglePublished = (release: Release) => {
    store.saveRelease({ ...release, published: !release.published });
  };

  const toggleFeatured = (release: Release) => {
    store.saveRelease({ ...release, featured: !release.featured });
  };

  return (
    <AdminLayout title="Music Releases & Soundtracks">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs font-mono text-[#8E8B82]">
            Control music albums, EPs, original motion picture scores, and credits.
          </p>

          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 bg-[#E5A93C] hover:bg-[#F3C065] text-[#0A0A0A] text-xs font-bold uppercase tracking-wider rounded transition-colors inline-flex items-center gap-2 self-start"
          >
            <Plus className="w-4 h-4" />
            <span>New Release</span>
          </button>
        </div>

        {/* Table */}
        <div className="bg-[#121212] border border-white/5 rounded-xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#181818] border-b border-white/5 text-[11px] font-mono uppercase tracking-wider text-[#A3A099]">
                <tr>
                  <th className="py-3.5 px-4">Release Title</th>
                  <th className="py-3.5 px-4">Artist</th>
                  <th className="py-3.5 px-4">Type</th>
                  <th className="py-3.5 px-4">Release Date</th>
                  <th className="py-3.5 px-4 text-center">Featured</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {releases.map((rel) => (
                  <tr key={rel.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 flex items-center gap-3">
                      <img
                        src={rel.cover_image}
                        alt={rel.title}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded object-cover border border-white/10 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block">{rel.title}</span>
                        <span className="text-xs text-[#71717A] font-mono">/releases/{rel.slug}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-[#C8C5BC]">
                      {rel.artist?.name || 'Unassigned'}
                    </td>
                    <td className="py-3.5 px-4 text-xs font-mono text-[#E5A93C]">{rel.release_type}</td>
                    <td className="py-3.5 px-4 text-xs text-[#8E8B82]">{rel.release_date}</td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => toggleFeatured(rel)}
                        title="Toggle Featured"
                        className={`p-1 rounded transition-colors ${
                          rel.featured ? 'text-[#E5A93C]' : 'text-[#444] hover:text-white'
                        }`}
                      >
                        <Star className={`w-4 h-4 ${rel.featured ? 'fill-current' : ''}`} />
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => togglePublished(rel)}
                        className={`px-2 py-0.5 text-[10px] font-mono rounded uppercase tracking-wider ${
                          rel.published
                            ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-800/40'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {rel.published ? 'Published' : 'Draft'}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(rel)}
                        className="p-1.5 text-[#A3A099] hover:text-white"
                        title="Edit Release"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(rel.id)}
                        className="p-1.5 text-[#A3A099] hover:text-red-400"
                        title="Delete Release"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Editor */}
        {isModalOpen && editingRelease && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-lg font-display font-bold text-white uppercase">
                  {editingRelease.id ? 'Edit Release Record' : 'Create New Release'}
                </h3>
                <button onClick={() => setIsModalOpen(false)} className="p-1 text-[#71717A] hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Title *</label>
                    <input
                      type="text"
                      required
                      value={editingRelease.title || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, title: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Artist *</label>
                    <select
                      value={editingRelease.artist_id || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, artist_id: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {artists.map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Format / Type</label>
                    <select
                      value={editingRelease.release_type || 'Single'}
                      onChange={(e) =>
                        setEditingRelease({ ...editingRelease, release_type: e.target.value as ReleaseType })
                      }
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    >
                      {releaseTypes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Release Date</label>
                    <input
                      type="date"
                      value={editingRelease.release_date || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, release_date: e.target.value })}
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <ImageUploadField
                  label="Release Cover Art / Vinyl Poster (Upload from Computer)"
                  value={editingRelease.cover_image || ''}
                  onChange={(val) => setEditingRelease({ ...editingRelease, cover_image: val })}
                  aspectRatio="square"
                  required
                  helperText="Upload album artwork or single cover directly from your computer."
                />

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Description</label>
                  <textarea
                    rows={3}
                    value={editingRelease.description || ''}
                    onChange={(e) => setEditingRelease({ ...editingRelease, description: e.target.value })}
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-mono uppercase text-[#A3A099]">Credits (Separate by ·)</label>
                  <textarea
                    rows={2}
                    value={editingRelease.credits || ''}
                    onChange={(e) => setEditingRelease({ ...editingRelease, credits: e.target.value })}
                    placeholder="Vocals: Aarav · Sarangi: Aarav · Mixed by Art Ghar"
                    className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white focus:outline-none focus:border-[#E5A93C]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Spotify Link</label>
                    <input
                      type="url"
                      value={editingRelease.spotify_url || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, spotify_url: e.target.value })}
                      placeholder="https://open.spotify.com"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">Apple Music</label>
                    <input
                      type="url"
                      value={editingRelease.apple_music_url || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, apple_music_url: e.target.value })}
                      placeholder="https://music.apple.com"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-mono uppercase text-[#A3A099]">YouTube</label>
                    <input
                      type="url"
                      value={editingRelease.youtube_url || ''}
                      onChange={(e) => setEditingRelease({ ...editingRelease, youtube_url: e.target.value })}
                      placeholder="https://youtube.com"
                      className="w-full bg-[#1A1A1A] border border-white/10 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-[#E5A93C]"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-6 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingRelease.published ?? true}
                      onChange={(e) => setEditingRelease({ ...editingRelease, published: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Published</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-mono uppercase text-[#C8C5BC]">
                    <input
                      type="checkbox"
                      checked={editingRelease.featured ?? false}
                      onChange={(e) => setEditingRelease({ ...editingRelease, featured: e.target.checked })}
                      className="rounded accent-[#E5A93C]"
                    />
                    <span>Featured On Homepage</span>
                  </label>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 text-xs font-mono uppercase text-[#A3A099] hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-mono uppercase font-bold bg-[#E5A93C] text-black rounded hover:bg-[#F3C065]"
                  >
                    Save Release
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Confirmation Alert */}
        {deleteConfirmId && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          >
            <div className="bg-[#141414] border border-red-500/40 rounded-xl p-6 max-w-sm w-full space-y-4 text-center">
              <h4 className="text-base font-display font-bold text-white">Confirm Removal</h4>
              <p className="text-xs text-[#8E8B82]">
                Are you sure you wish to delete this release from the discography?
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="px-4 py-1.5 text-xs text-[#A3A099]"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="px-4 py-1.5 text-xs bg-red-600 text-white rounded font-mono uppercase font-bold"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
};
