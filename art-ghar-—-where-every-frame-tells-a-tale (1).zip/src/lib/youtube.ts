/**
 * YouTube Utility Helper for Art Ghar
 * Handles video ID extraction, high-res thumbnail derivation, and privacy-enhanced embeds
 */

export function extractYoutubeId(url: string): string {
  if (!url) return '';
  const trimmed = url.trim();
  
  // Handles youtu.be/ID?si=..., youtube.com/watch?v=ID, youtube.com/embed/ID, etc.
  const match = trimmed.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
  if (match && match[1]) {
    return match[1];
  }
  
  // If the string is already a raw 11-character video ID
  if (/^[\w-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  
  return '';
}

export function getYoutubeThumbnail(url: string, quality: 'maxres' | 'hq' | 'mq' = 'maxres'): string {
  const id = extractYoutubeId(url);
  if (!id) return '/src/assets/images/hero_cinematic_production_1790823187023.jpg';
  
  if (quality === 'hq') return `https://img.youtube.com/vi/${id}/hqdefault.jpg`;
  if (quality === 'mq') return `https://img.youtube.com/vi/${id}/mqdefault.jpg`;
  return `https://img.youtube.com/vi/${id}/maxresdefault.jpg`;
}

export function getYoutubeEmbedUrl(url: string, autoplay = true): string {
  const id = extractYoutubeId(url);
  if (!id) return '';
  
  const params = new URLSearchParams({
    rel: '0',
    modestbranding: '1',
    playsinline: '1',
  });
  
  if (autoplay) {
    params.set('autoplay', '1');
  }
  
  return `https://www.youtube-nocookie.com/embed/${id}?${params.toString()}`;
}
