import {
  Artist,
  TeamMember,
  Release,
  UpcomingProject,
  Production,
  Video,
  Collaboration,
  TheaterShow,
  GalleryItem,
  BlogPost,
  TimelineItem,
  ContactMessage,
  Profile,
  UserRole,
} from '../types/database';
import {
  initialArtists,
  initialTeamMembers,
  initialReleases,
  initialUpcoming,
  initialProductions,
  initialVideos,
  initialCollaborations,
  initialTheaterShows,
  initialGallery,
  initialBlogPosts,
  initialTimeline,
  initialProfiles,
  initialSiteSettings,
} from './seedData';
import { supabase } from './supabase';

const STORAGE_KEY = 'art_ghar_database_v5';
const AUTH_KEY = 'art_ghar_session_user';

interface StorageSchema {
  artists: Artist[];
  team_members: TeamMember[];
  releases: Release[];
  upcoming_projects: UpcomingProject[];
  productions: Production[];
  videos: Video[];
  collaborations: Collaboration[];
  theater_shows: TheaterShow[];
  gallery: GalleryItem[];
  blog_posts: BlogPost[];
  timeline: TimelineItem[];
  contact_messages: ContactMessage[];
  profiles: Profile[];
  site_settings: Record<string, any>;
}

class Store {
  private data: StorageSchema;
  private listeners: Set<() => void> = new Set();
  private currentUser: Profile | null = null;

  constructor() {
    this.data = this.loadInitialData();
    this.currentUser = this.loadSession();
  }

  private loadInitialData(): StorageSchema {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          artists: parsed.artists?.length ? parsed.artists : initialArtists,
          team_members: parsed.team_members?.length ? parsed.team_members : initialTeamMembers,
          releases: parsed.releases?.length ? parsed.releases : initialReleases,
          upcoming_projects: parsed.upcoming_projects?.length ? parsed.upcoming_projects : initialUpcoming,
          productions: parsed.productions?.length ? parsed.productions : initialProductions,
          videos: parsed.videos?.length ? parsed.videos : initialVideos,
          collaborations: parsed.collaborations?.length ? parsed.collaborations : initialCollaborations,
          theater_shows: parsed.theater_shows?.length ? parsed.theater_shows : initialTheaterShows,
          gallery: parsed.gallery?.length ? parsed.gallery : initialGallery,
          blog_posts: parsed.blog_posts?.length ? parsed.blog_posts : initialBlogPosts,
          timeline: parsed.timeline?.length ? parsed.timeline : initialTimeline,
          contact_messages: parsed.contact_messages || [],
          profiles: parsed.profiles?.length ? parsed.profiles : initialProfiles,
          site_settings: { ...initialSiteSettings, ...(parsed.site_settings || {}) },
        };
      }
    } catch (e) {
      console.warn('Failed to load stored data, initializing seeds', e);
    }

    const initial: StorageSchema = {
      artists: initialArtists,
      team_members: initialTeamMembers,
      releases: initialReleases,
      upcoming_projects: initialUpcoming,
      productions: initialProductions,
      videos: initialVideos,
      collaborations: initialCollaborations,
      theater_shows: initialTheaterShows,
      gallery: initialGallery,
      blog_posts: initialBlogPosts,
      timeline: initialTimeline,
      contact_messages: [
        {
          id: 'msg-1',
          name: 'Suman Rai',
          email: 'suman@himalayanfilms.np',
          organization: 'Himalayan Indie Cinema',
          project_type: 'Music Production',
          message: 'We are directing an upcoming feature documentary on high-altitude shepherds and would love to collaborate with Art Ghar for the complete cinematic score and Sarangi arrangements.',
          status: 'New',
          created_at: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
        },
      ],
      profiles: initialProfiles,
      site_settings: initialSiteSettings,
    };

    this.saveData(initial);
    return initial;
  }

  private saveData(data: StorageSchema) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      this.data = data;
      this.notify();
    } catch (e) {
      console.error('Storage write error', e);
    }
  }

  private notify() {
    this.listeners.forEach((listener) => listener());
  }

  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  // --- AUTH METHODS ---
  private loadSession(): Profile | null {
    try {
      const stored = localStorage.getItem(AUTH_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to load auth session', e);
    }
    return null;
  }

  public getCurrentUser(): Profile | null {
    return this.currentUser;
  }

  public async login(email: string, pass: string): Promise<{ success: boolean; error?: string; user?: Profile }> {
    // If Supabase is active, attempt Supabase Auth
    if (supabase) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password: pass });
        if (error) {
          return { success: false, error: error.message };
        }
        if (data.user) {
          // Find matching profile
          const { data: prof } = await supabase
            .from('profiles')
            .select('*')
            .eq('auth_user_id', data.user.id)
            .single();

          const profileUser: Profile = prof || {
            id: 'prof-supabase',
            auth_user_id: data.user.id,
            email: data.user.email || email,
            full_name: data.user.user_metadata?.full_name || 'Art Ghar Staff',
            role: (data.user.user_metadata?.role as UserRole) || 'admin',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };

          this.currentUser = profileUser;
          localStorage.setItem(AUTH_KEY, JSON.stringify(profileUser));
          this.notify();
          return { success: true, user: profileUser };
        }
      } catch (err: any) {
        console.warn('Supabase auth attempt fell back to local credentials:', err);
      }
    }

    // Local authentication (Requires manual email & password)
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();

    if (!cleanEmail || !cleanPass) {
      return {
        success: false,
        error: 'Please enter both email and password.',
      };
    }

    // Authorized Art Ghar Director & Studio Administrators
    const isAuthorizedPassword =
      cleanPass === 'artghar2026!' || cleanPass === 'admin123' || cleanPass === 'artghar';

    if (
      (cleanEmail === 'artgharproject@gmail.com' || cleanEmail === 'admin@artghar.np') &&
      isAuthorizedPassword
    ) {
      const adminUser: Profile = {
        id: 'prof-admin',
        auth_user_id: 'auth-admin',
        full_name: 'Art Ghar Director',
        email: cleanEmail,
        role: 'admin',
        avatar_url: '/src/assets/images/featured_artist_portrait_1790823200594.jpg',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      this.currentUser = adminUser;
      localStorage.setItem(AUTH_KEY, JSON.stringify(adminUser));
      this.notify();
      return { success: true, user: adminUser };
    }

    // Existing profiles with authorized password
    const existing = this.data.profiles.find((p) => p.email.toLowerCase() === cleanEmail);
    if (existing && isAuthorizedPassword) {
      this.currentUser = existing;
      localStorage.setItem(AUTH_KEY, JSON.stringify(existing));
      this.notify();
      return { success: true, user: existing };
    }

    return {
      success: false,
      error: 'Invalid credentials. Access is restricted to authorized Art Ghar personnel.',
    };
  }

  public logout() {
    this.currentUser = null;
    localStorage.removeItem(AUTH_KEY);
    if (supabase) {
      supabase.auth.signOut().catch(() => {});
    }
    this.notify();
  }

  // --- ARTISTS ---
  public getArtists(includeDrafts = false): Artist[] {
    const list = includeDrafts ? this.data.artists : this.data.artists.filter((a) => a.published);
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }

  public getArtistBySlug(slug: string): Artist | undefined {
    return this.data.artists.find((a) => a.slug === slug);
  }

  public getArtistById(id: string): Artist | undefined {
    return this.data.artists.find((a) => a.id === id);
  }

  public saveArtist(artist: Partial<Artist> & { name: string }): Artist {
    const isNew = !artist.id;
    const slug = artist.slug || artist.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: Artist = {
      id: artist.id || `art-${Date.now()}`,
      name: artist.name,
      slug,
      short_bio: artist.short_bio || '',
      biography: artist.biography || '',
      profile_image: artist.profile_image || '/src/assets/images/featured_artist_portrait_1790823200594.jpg',
      cover_image: artist.cover_image || '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      genre: artist.genre || 'Cinematic Folk',
      location: artist.location || 'Kathmandu, Nepal',
      collaboration_status: artist.collaboration_status || 'current',
      featured: artist.featured ?? false,
      published: artist.published ?? true,
      sort_order: artist.sort_order ?? this.data.artists.length + 1,
      instagram_url: artist.instagram_url,
      youtube_url: artist.youtube_url,
      facebook_url: artist.facebook_url,
      tiktok_url: artist.tiktok_url,
      spotify_url: artist.spotify_url,
      website_url: artist.website_url,
      created_at: artist.created_at || now,
      updated_at: now,
    };

    const artists = isNew
      ? [record, ...this.data.artists]
      : this.data.artists.map((a) => (a.id === record.id ? record : a));

    this.saveData({ ...this.data, artists });
    return record;
  }

  public deleteArtist(id: string) {
    const artists = this.data.artists.filter((a) => a.id !== id);
    this.saveData({ ...this.data, artists });
  }

  // --- TEAM MEMBERS ---
  public getTeamMembers(includeDrafts = false): TeamMember[] {
    const list = this.data.team_members || [];
    const filtered = includeDrafts ? list : list.filter((m) => m.published);
    return [...filtered].sort((a, b) => a.sort_order - b.sort_order);
  }

  public saveTeamMember(member: Partial<TeamMember> & { name: string }): TeamMember {
    const isNew = !member.id;
    const now = new Date().toISOString();
    const currentList = this.data.team_members || [];

    const record: TeamMember = {
      id: member.id || `team-${Date.now()}`,
      name: member.name,
      role: member.role || 'Production Specialist',
      bio: member.bio || '',
      image: member.image || '/src/assets/images/featured_artist_portrait_1790823200594.jpg',
      address: member.address || 'Kathmandu, Nepal',
      email: member.email || 'artgharproject@gmail.com',
      phone: member.phone || '+977 1 552 4981',
      instagram_url: member.instagram_url,
      linkedin_url: member.linkedin_url,
      sort_order: member.sort_order ?? currentList.length + 1,
      published: member.published ?? true,
      created_at: member.created_at || now,
      updated_at: now,
    };

    const team_members = isNew
      ? [...currentList, record]
      : currentList.map((m) => (m.id === record.id ? record : m));

    this.saveData({ ...this.data, team_members });
    return record;
  }

  public deleteTeamMember(id: string) {
    const team_members = (this.data.team_members || []).filter((m) => m.id !== id);
    this.saveData({ ...this.data, team_members });
  }

  // --- RELEASES ---
  public getReleases(includeDrafts = false): Release[] {
    const list = includeDrafts ? this.data.releases : this.data.releases.filter((r) => r.published);
    return list.map((r) => ({
      ...r,
      artist: this.getArtistById(r.artist_id),
    })).sort((a, b) => new Date(b.release_date).getTime() - new Date(a.release_date).getTime());
  }

  public getReleaseBySlug(slug: string): Release | undefined {
    const rel = this.data.releases.find((r) => r.slug === slug);
    if (!rel) return undefined;
    return {
      ...rel,
      artist: this.getArtistById(rel.artist_id),
    };
  }

  public saveRelease(release: Partial<Release> & { title: string; artist_id: string }): Release {
    const isNew = !release.id;
    const slug = release.slug || release.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: Release = {
      id: release.id || `rel-${Date.now()}`,
      title: release.title,
      slug,
      artist_id: release.artist_id,
      release_type: release.release_type || 'Single',
      cover_image: release.cover_image || '/src/assets/images/release_cover_album_1790823212429.jpg',
      description: release.description || '',
      release_date: release.release_date || new Date().toISOString().split('T')[0],
      featured: release.featured ?? false,
      published: release.published ?? true,
      spotify_url: release.spotify_url,
      apple_music_url: release.apple_music_url,
      youtube_url: release.youtube_url,
      soundcloud_url: release.soundcloud_url,
      other_links: release.other_links,
      credits: release.credits,
      created_at: release.created_at || now,
      updated_at: now,
    };

    const releases = isNew
      ? [record, ...this.data.releases]
      : this.data.releases.map((r) => (r.id === record.id ? record : r));

    this.saveData({ ...this.data, releases });
    return record;
  }

  public deleteRelease(id: string) {
    const releases = this.data.releases.filter((r) => r.id !== id);
    this.saveData({ ...this.data, releases });
  }

  // --- UPCOMING PROJECTS ---
  public getUpcomingProjects(includeDrafts = false): UpcomingProject[] {
    const list = includeDrafts ? this.data.upcoming_projects : this.data.upcoming_projects.filter((u) => u.published);
    return list.map((u) => ({
      ...u,
      artist: this.getArtistById(u.artist_id),
    }));
  }

  public getUpcomingBySlug(slug: string): UpcomingProject | undefined {
    const item = this.data.upcoming_projects.find((u) => u.slug === slug);
    if (!item) return undefined;
    return {
      ...item,
      artist: this.getArtistById(item.artist_id),
    };
  }

  public saveUpcoming(upcoming: Partial<UpcomingProject> & { title: string; artist_id: string }): UpcomingProject {
    const isNew = !upcoming.id;
    const slug = upcoming.slug || upcoming.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: UpcomingProject = {
      id: upcoming.id || `up-${Date.now()}`,
      title: upcoming.title,
      slug,
      artist_id: upcoming.artist_id,
      project_type: upcoming.project_type || 'Original Film & Score',
      artwork: upcoming.artwork || '/src/assets/images/production_showcase_film_1790823224467.jpg',
      description: upcoming.description || '',
      announcement: upcoming.announcement || '',
      expected_release_date: upcoming.expected_release_date || 'Coming Soon',
      status: upcoming.status || 'Coming Soon',
      featured: upcoming.featured ?? false,
      published: upcoming.published ?? true,
      trailer_url: upcoming.trailer_url,
      pre_save_url: upcoming.pre_save_url,
      created_at: upcoming.created_at || now,
      updated_at: now,
    };

    const upcoming_projects = isNew
      ? [record, ...this.data.upcoming_projects]
      : this.data.upcoming_projects.map((u) => (u.id === record.id ? record : u));

    this.saveData({ ...this.data, upcoming_projects });
    return record;
  }

  public deleteUpcoming(id: string) {
    const upcoming_projects = this.data.upcoming_projects.filter((u) => u.id !== id);
    this.saveData({ ...this.data, upcoming_projects });
  }

  // --- PRODUCTIONS ---
  public getProductions(includeDrafts = false): Production[] {
    const list = includeDrafts ? this.data.productions : this.data.productions.filter((p) => p.published);
    return [...list].sort((a, b) => new Date(b.production_date).getTime() - new Date(a.production_date).getTime());
  }

  public getProductionBySlug(slug: string): Production | undefined {
    return this.data.productions.find((p) => p.slug === slug);
  }

  public saveProduction(prod: Partial<Production> & { title: string }): Production {
    const isNew = !prod.id;
    const slug = prod.slug || prod.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: Production = {
      id: prod.id || `prod-${Date.now()}`,
      title: prod.title,
      slug,
      category: prod.category || 'Film',
      cover_image: prod.cover_image || '/src/assets/images/production_showcase_film_1790823224467.jpg',
      hero_image: prod.hero_image || '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      description: prod.description || '',
      content: prod.content || '',
      client_name: prod.client_name,
      production_date: prod.production_date || new Date().toISOString().split('T')[0],
      featured: prod.featured ?? false,
      published: prod.published ?? true,
      created_at: prod.created_at || now,
      updated_at: now,
    };

    const productions = isNew
      ? [record, ...this.data.productions]
      : this.data.productions.map((p) => (p.id === record.id ? record : p));

    this.saveData({ ...this.data, productions });
    return record;
  }

  public deleteProduction(id: string) {
    const productions = this.data.productions.filter((p) => p.id !== id);
    this.saveData({ ...this.data, productions });
  }

  // --- VIDEOS ---
  public getVideos(includeDrafts = false): Video[] {
    const list = includeDrafts ? this.data.videos : this.data.videos.filter((v) => v.published);
    return [...list].sort((a, b) => new Date(b.release_date).getTime() - new Date(a.release_date).getTime());
  }

  public saveVideo(video: Partial<Video> & { title: string; youtube_url: string }): Video {
    const isNew = !video.id;
    const slug = video.slug || video.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: Video = {
      id: video.id || `vid-${Date.now()}`,
      title: video.title,
      slug,
      thumbnail: video.thumbnail || '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      video_url: video.video_url,
      youtube_url: video.youtube_url,
      category: video.category || 'Music Video',
      description: video.description || '',
      featured: video.featured ?? false,
      published: video.published ?? true,
      release_date: video.release_date || new Date().toISOString().split('T')[0],
      created_at: video.created_at || now,
      updated_at: now,
    };

    const videos = isNew
      ? [record, ...this.data.videos]
      : this.data.videos.map((v) => (v.id === record.id ? record : v));

    this.saveData({ ...this.data, videos });
    return record;
  }

  public deleteVideo(id: string) {
    const videos = this.data.videos.filter((v) => v.id !== id);
    this.saveData({ ...this.data, videos });
  }

  // --- COLLABORATIONS ---
  public getCollaborations(includeDrafts = false): Collaboration[] {
    const list = includeDrafts
      ? this.data.collaborations
      : this.data.collaborations.filter((c) => c.published);
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }

  public getCollaborationById(id: string): Collaboration | undefined {
    return this.data.collaborations.find((c) => c.id === id);
  }

  public saveCollaboration(
    collab: Partial<Collaboration> & { partner_name: string; program_name: string }
  ): Collaboration {
    const isNew = !collab.id;
    const now = new Date().toISOString();

    const record: Collaboration = {
      id: collab.id || `collab-${Date.now()}`,
      partner_name: collab.partner_name,
      program_name: collab.program_name,
      category: collab.category || 'Program & Festival',
      logo: collab.logo || '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      banner_image: collab.banner_image,
      year: collab.year || '2026',
      description: collab.description || '',
      outcomes: collab.outcomes,
      website_url: collab.website_url,
      featured: collab.featured ?? false,
      published: collab.published ?? true,
      sort_order: collab.sort_order || this.data.collaborations.length + 1,
      created_at: collab.created_at || now,
      updated_at: now,
    };

    const collaborations = isNew
      ? [...this.data.collaborations, record]
      : this.data.collaborations.map((c) => (c.id === record.id ? record : c));

    this.saveData({ ...this.data, collaborations });
    return record;
  }

  public deleteCollaboration(id: string) {
    const collaborations = this.data.collaborations.filter((c) => c.id !== id);
    this.saveData({ ...this.data, collaborations });
  }

  // --- THEATER SHOWS ---
  public getTheaterShows(includeDrafts = false): TheaterShow[] {
    const list = includeDrafts
      ? this.data.theater_shows
      : this.data.theater_shows.filter((t) => t.published);
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }

  public getTheaterShowById(id: string): TheaterShow | undefined {
    return this.data.theater_shows.find((t) => t.id === id);
  }

  public getTheaterShowBySlug(slug: string): TheaterShow | undefined {
    return this.data.theater_shows.find((t) => t.slug === slug);
  }

  public saveTheaterShow(
    show: Partial<TheaterShow> & { title: string; director: string; venue: string }
  ): TheaterShow {
    const isNew = !show.id;
    const slug =
      show.slug ||
      show.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: TheaterShow = {
      id: show.id || `th-${Date.now()}`,
      title: show.title,
      slug,
      playwright: show.playwright,
      director: show.director,
      venue: show.venue,
      city: show.city || 'Kathmandu, Nepal',
      dates_staged: show.dates_staged || '2026',
      year: show.year || '2026',
      status: show.status || 'Staged',
      poster_image: show.poster_image || '/src/assets/images/hero_cinematic_production_1790823187023.jpg',
      stage_photos: show.stage_photos,
      synopsis: show.synopsis || '',
      cast_and_crew: show.cast_and_crew,
      press_quote: show.press_quote,
      press_outlet: show.press_outlet,
      duration: show.duration,
      ticket_link: show.ticket_link,
      featured: show.featured ?? false,
      published: show.published ?? true,
      sort_order: show.sort_order || this.data.theater_shows.length + 1,
      created_at: show.created_at || now,
      updated_at: now,
    };

    const theater_shows = isNew
      ? [...this.data.theater_shows, record]
      : this.data.theater_shows.map((t) => (t.id === record.id ? record : t));

    this.saveData({ ...this.data, theater_shows });
    return record;
  }

  public deleteTheaterShow(id: string) {
    const theater_shows = this.data.theater_shows.filter((t) => t.id !== id);
    this.saveData({ ...this.data, theater_shows });
  }

  // --- GALLERY ---
  public getGallery(includeDrafts = false): GalleryItem[] {
    const list = includeDrafts ? this.data.gallery : this.data.gallery.filter((g) => g.published);
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }

  public saveGalleryItem(item: Partial<GalleryItem> & { title: string; image_url: string }): GalleryItem {
    const isNew = !item.id;
    const now = new Date().toISOString();

    const record: GalleryItem = {
      id: item.id || `gal-${Date.now()}`,
      title: item.title,
      image_url: item.image_url,
      caption: item.caption || '',
      category: item.category || 'Studio',
      featured: item.featured ?? false,
      published: item.published ?? true,
      sort_order: item.sort_order ?? this.data.gallery.length + 1,
      created_at: item.created_at || now,
      updated_at: now,
    };

    const gallery = isNew
      ? [record, ...this.data.gallery]
      : this.data.gallery.map((g) => (g.id === record.id ? record : g));

    this.saveData({ ...this.data, gallery });
    return record;
  }

  public deleteGalleryItem(id: string) {
    const gallery = this.data.gallery.filter((g) => g.id !== id);
    this.saveData({ ...this.data, gallery });
  }

  // --- BLOG POSTS (JOURNAL) ---
  public getBlogPosts(includeDrafts = false): BlogPost[] {
    const list = includeDrafts ? this.data.blog_posts : this.data.blog_posts.filter((b) => b.published);
    return list.map((b) => ({
      ...b,
      author: this.data.profiles.find((p) => p.id === b.author_id),
    })).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  public getBlogPostBySlug(slug: string): BlogPost | undefined {
    const post = this.data.blog_posts.find((b) => b.slug === slug);
    if (!post) return undefined;
    return {
      ...post,
      author: this.data.profiles.find((p) => p.id === post.author_id),
    };
  }

  public saveBlogPost(post: Partial<BlogPost> & { title: string }): BlogPost {
    const isNew = !post.id;
    const slug = post.slug || post.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const record: BlogPost = {
      id: post.id || `post-${Date.now()}`,
      title: post.title,
      slug,
      excerpt: post.excerpt || '',
      content: post.content || '',
      cover_image: post.cover_image || '/src/assets/images/art_ghar_studio_session_1790823237699.jpg',
      category: post.category || 'Sound Architecture',
      author_id: post.author_id || this.currentUser?.id || 'prof-1',
      published: post.published ?? true,
      featured: post.featured ?? false,
      published_at: post.published_at || (post.published ? now : undefined),
      seo_title: post.seo_title,
      seo_description: post.seo_description,
      created_at: post.created_at || now,
      updated_at: now,
    };

    const blog_posts = isNew
      ? [record, ...this.data.blog_posts]
      : this.data.blog_posts.map((b) => (b.id === record.id ? record : b));

    this.saveData({ ...this.data, blog_posts });
    return record;
  }

  public deleteBlogPost(id: string) {
    const blog_posts = this.data.blog_posts.filter((b) => b.id !== id);
    this.saveData({ ...this.data, blog_posts });
  }

  // --- TIMELINE ---
  public getTimeline(includeDrafts = false): TimelineItem[] {
    const list = includeDrafts ? this.data.timeline : this.data.timeline.filter((t) => t.published);
    return [...list].sort((a, b) => a.sort_order - b.sort_order);
  }

  public saveTimelineItem(item: Partial<TimelineItem> & { year: string; title: string }): TimelineItem {
    const isNew = !item.id;
    const now = new Date().toISOString();

    const record: TimelineItem = {
      id: item.id || `time-${Date.now()}`,
      year: item.year,
      title: item.title,
      description: item.description || '',
      image: item.image,
      sort_order: item.sort_order ?? this.data.timeline.length + 1,
      published: item.published ?? true,
      created_at: item.created_at || now,
      updated_at: now,
    };

    const timeline = isNew
      ? [record, ...this.data.timeline]
      : this.data.timeline.map((t) => (t.id === record.id ? record : t));

    this.saveData({ ...this.data, timeline });
    return record;
  }

  public deleteTimelineItem(id: string) {
    const timeline = this.data.timeline.filter((t) => t.id !== id);
    this.saveData({ ...this.data, timeline });
  }

  // --- CONTACT MESSAGES ---
  public getContactMessages(): ContactMessage[] {
    return [...this.data.contact_messages].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  public submitContactMessage(msg: {
    name: string;
    email: string;
    organization?: string;
    project_type: string;
    message: string;
  }): ContactMessage {
    const newMsg: ContactMessage = {
      id: `msg-${Date.now()}`,
      name: msg.name,
      email: msg.email,
      organization: msg.organization,
      project_type: msg.project_type,
      message: msg.message,
      status: 'New',
      created_at: new Date().toISOString(),
    };

    const contact_messages = [newMsg, ...this.data.contact_messages];
    this.saveData({ ...this.data, contact_messages });

    // Also push to Supabase if configured
    if (supabase) {
      supabase.from('contact_messages').insert([newMsg]).then();
    }

    return newMsg;
  }

  public updateMessageStatus(id: string, status: ContactMessage['status']) {
    const contact_messages = this.data.contact_messages.map((m) =>
      m.id === id ? { ...m, status } : m
    );
    this.saveData({ ...this.data, contact_messages });
  }

  public deleteContactMessage(id: string) {
    const contact_messages = this.data.contact_messages.filter((m) => m.id !== id);
    this.saveData({ ...this.data, contact_messages });
  }

  // --- SITE SETTINGS ---
  public getSiteSettings(): Record<string, any> {
    return this.data.site_settings;
  }

  public updateSiteSettings(settings: Record<string, any>) {
    const site_settings = { ...this.data.site_settings, ...settings };
    this.saveData({ ...this.data, site_settings });
  }

  // --- PROFILES / USERS ---
  public getProfiles(): Profile[] {
    return this.data.profiles;
  }

  public saveProfile(prof: Partial<Profile> & { full_name: string; email: string; role: UserRole }): Profile {
    const isNew = !prof.id;
    const now = new Date().toISOString();

    const record: Profile = {
      id: prof.id || `prof-${Date.now()}`,
      auth_user_id: prof.auth_user_id || `auth-${Date.now()}`,
      full_name: prof.full_name,
      email: prof.email,
      avatar_url: prof.avatar_url,
      role: prof.role,
      created_at: prof.created_at || now,
      updated_at: now,
    };

    const profiles = isNew
      ? [...this.data.profiles, record]
      : this.data.profiles.map((p) => (p.id === record.id ? record : p));

    this.saveData({ ...this.data, profiles });
    return record;
  }

  public deleteProfile(id: string) {
    // Cannot delete last admin
    const admins = this.data.profiles.filter((p) => p.role === 'admin');
    const target = this.data.profiles.find((p) => p.id === id);
    if (target?.role === 'admin' && admins.length <= 1) {
      throw new Error('Cannot delete the sole administrator account.');
    }
    const profiles = this.data.profiles.filter((p) => p.id !== id);
    this.saveData({ ...this.data, profiles });
  }

  // Reset database back to default factory seeds
  public resetToFactorySeeds() {
    localStorage.removeItem(STORAGE_KEY);
    this.data = this.loadInitialData();
    this.notify();
  }
}

export const store = new Store();
