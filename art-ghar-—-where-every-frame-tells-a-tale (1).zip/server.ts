import express from 'react';
import type { Request, Response } from 'express';
import expressApp from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const app = expressApp();
const PORT = process.env.PORT || 3000;

app.use(expressApp.json());

// API health endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'Art Ghar Digital Platform',
    tagline: 'WHERE EVERY FRAME TELLS A TALE',
    timestamp: new Date().toISOString(),
  });
});

// Production static assets serving if built
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.join(__dirname, 'dist');

app.use(expressApp.static(distPath));

// Fallback to index.html for SPA routing
app.get('*', (_req: Request, res: Response) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

if (process.env.NODE_ENV === 'production') {
  app.listen(PORT, () => {
    console.log(`Art Ghar Production Server running on port ${PORT}`);
  });
}

export default app;
